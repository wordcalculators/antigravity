<?php
// setup.php
// OnlineConvert.co V2.0 Installer

session_start();
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;

$error = '';
$success = '';

// Step 1: Database Setup
if ($step === 1 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['db_host'] ?? '';
    $db_name = $_POST['db_name'] ?? '';
    $db_user = $_POST['db_user'] ?? '';
    $db_pass = $_POST['db_pass'] ?? '';

    try {
        // Test connection and potentially create DB
        $pdo = new PDO("mysql:host={$db_host};charset=utf8mb4", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$db_name}`");
        
        $_SESSION['db_config'] = [
            'host' => $db_host,
            'name' => $db_name,
            'user' => $db_user,
            'pass' => $db_pass
        ];
        
        header("Location: setup.php?step=2");
        exit;
    } catch (PDOException $e) {
        $error = "Database Connection Failed: " . $e->getMessage();
    }
}

// Step 2: Admin Account & Config Writing & DB Execution
if ($step === 2 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $admin_name = $_POST['admin_name'] ?? '';
    $admin_email = $_POST['admin_email'] ?? '';
    $admin_pass = $_POST['admin_pass'] ?? '';

    if (empty($admin_name) || empty($admin_email) || empty($admin_pass)) {
        $error = "All fields are required.";
    } else {
        $db = $_SESSION['db_config'];
        
        // Write config.php
        $config_content = "<?php\n\n";
        $config_content .= "// Database Configuration\n";
        $config_content .= "define('DB_HOST', '{$db['host']}');\n";
        $config_content .= "define('DB_NAME', '{$db['name']}');\n";
        $config_content .= "define('DB_USER', '{$db['user']}');\n";
        $config_content .= "define('DB_PASS', '{$db['pass']}');\n\n";
        
        // Use a relative path to detect base URL dynamically or set a constant
        $config_content .= "// Site URL (Current Directory)\n";
        $config_content .= "\$protocol = isset(\$_SERVER['HTTPS']) && \$_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';\n";
        $config_content .= "\$domain = \$_SERVER['HTTP_HOST'];\n";
        $config_content .= "\$path = rtrim(dirname(\$_SERVER['SCRIPT_NAME']), '/\\\\');\n";
        $config_content .= "// In v2 we use .htaccess routing, ensure SITE_URL doesn't double stack paths\n";
        $config_content .= "define('SITE_URL', \$protocol . \$domain . \$path);\n";
        $config_content .= "define('SITE_NAME', 'OnlineConvert.co');\n\n";
        $config_content .= "define('SECRET_KEY', '" . bin2hex(random_bytes(32)) . "');\n";
        
        if (file_put_contents(__DIR__ . '/includes/config.php', $config_content) === false) {
            $error = "Failed to write includes/config.php. Check permissions.";
        } else {
            // Execute DB Schema
            try {
                $pdo = new PDO("mysql:host={$db['host']};dbname={$db['name']};charset=utf8mb4", $db['user'], $db['pass']);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                // --- SCHEMA DEFINITIONS ---
                $pdo->exec("CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    email VARCHAR(150) NOT NULL UNIQUE,
                    password_hash VARCHAR(255) NOT NULL,
                    api_key VARCHAR(64) DEFAULT NULL UNIQUE,
                    role ENUM('user', 'author', 'developer') DEFAULT 'user',
                    status ENUM('active', 'inactive', 'banned') DEFAULT 'active',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )");

                $pdo->exec("CREATE TABLE IF NOT EXISTS history (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT,
                    tool_name VARCHAR(100) NOT NULL,
                    file_name VARCHAR(255),
                    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
                )");

                $pdo->exec("CREATE TABLE IF NOT EXISTS favorites (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    tool_name VARCHAR(100) NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                )");

                $pdo->exec("CREATE TABLE IF NOT EXISTS plans (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(50) NOT NULL,
                    price DECIMAL(10,2) NOT NULL,
                    features TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )");

                $pdo->exec("CREATE TABLE IF NOT EXISTS subscriptions (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    plan_id INT NOT NULL,
                    status ENUM('active', 'expired', 'canceled') DEFAULT 'active',
                    start_date DATE NOT NULL,
                    end_date DATE NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE CASCADE
                )");

                $pdo->exec("CREATE TABLE IF NOT EXISTS api_keys (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    key_hash VARCHAR(255) NOT NULL,
                    label VARCHAR(100),
                    rate_limit INT DEFAULT 100,
                    calls_today INT DEFAULT 0,
                    last_used TIMESTAMP NULL,
                    is_active BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                )");

                $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    ip_hash VARCHAR(255) NOT NULL,
                    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX (ip_hash)
                )");

                $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
                    setting_key VARCHAR(100) PRIMARY KEY,
                    setting_value TEXT
                )");

                $pdo->exec("CREATE TABLE IF NOT EXISTS posts (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    author_id INT NOT NULL,
                    title VARCHAR(255) NOT NULL,
                    slug VARCHAR(255) NOT NULL UNIQUE,
                    meta_desc TEXT,
                    body TEXT,
                    featured_image VARCHAR(255),
                    status ENUM('draft', 'published') DEFAULT 'draft',
                    views INT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE
                )");

                // Defaults
                $pdo->exec("INSERT IGNORE INTO settings (setting_key, setting_value) VALUES 
                    ('logo_override', ''), ('analytics_id', '')");

                // Default Plans
                $stmt = $pdo->query("SELECT COUNT(*) FROM plans");
                if ($stmt->fetchColumn() == 0) {
                    $pdo->exec("INSERT INTO plans (name, price, features) VALUES 
                        ('Basic Premium', 9.99, 'Ad free experience, Batch conversion'),
                        ('Pro Premium', 19.99, 'Ad free experience, Batch conversion, Large file limits, Saved conversion history')");
                }

                // Default Admin
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$admin_email]);
                if (!$stmt->fetch()) {
                    $hash = password_hash($admin_pass, PASSWORD_DEFAULT);
                    $ins = $pdo->prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'developer')");
                    $ins->execute([$admin_name, $admin_email, $hash]);
                }
                
                header("Location: setup.php?step=3");
                exit;

            } catch (PDOException $e) {
                $error = "Schema Execution Failed: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>OnlineConvert.co Setup V2</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen p-4">

    <div class="max-w-md w-full bg-white rounded-xl shadow-lg overflow-hidden">
        <div class="bg-indigo-600 px-6 py-4">
            <h1 class="text-xl font-bold text-white tracking-wide">OnlineConvert Setup</h1>
            <p class="text-indigo-200 text-sm mt-1">Version 2.0 Installer</p>
        </div>
        
        <div class="p-6">
            <?php if ($error): ?>
                <div class="bg-red-50 text-red-600 p-3 rounded-lg mb-4 text-sm font-medium">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($step === 1): ?>
                <h2 class="text-lg font-semibold text-gray-800 mb-4">Step 1: Database Setup</h2>
                <form method="POST">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Database Host</label>
                            <input type="text" name="db_host" value="localhost" class="mt-1 w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Database Name</label>
                            <input type="text" name="db_name" value="onlineconvert" class="mt-1 w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Database User</label>
                            <input type="text" name="db_user" value="root" class="mt-1 w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Database Password</label>
                            <input type="password" name="db_pass" class="mt-1 w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                    </div>
                    <button type="submit" class="mt-6 w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg transition-colors">Test & Continue</button>
                </form>
            <?php elseif ($step === 2): ?>
                <h2 class="text-lg font-semibold text-gray-800 mb-4">Step 2: Admin Account</h2>
                <form method="POST">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Admin Name</label>
                            <input type="text" name="admin_name" value="System Admin" class="mt-1 w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Admin Email</label>
                            <input type="email" name="admin_email" value="admin@onlineconvert.co" class="mt-1 w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Admin Password</label>
                            <input type="text" name="admin_pass" value="admin123" class="mt-1 w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                    </div>
                    <button type="submit" class="mt-6 w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg transition-colors">Build Database & Finish</button>
                </form>
            <?php elseif ($step === 3): ?>
                <div class="text-center py-6">
                    <div class="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-6">
                        <svg class="h-8 w-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-2">Setup Complete!</h2>
                    <p class="text-sm text-gray-500 mb-8">The database has been configured, schemas executed, and admin account created.</p>
                    
                    <div class="space-y-3">
                        <a href="index.php" class="block w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg transition-colors">Go to Homepage</a>
                        <a href="admin/index.php" class="block w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-2 px-4 rounded-lg transition-colors">Go to Admin / Developer Panel</a>
                    </div>
                    <div class="mt-8 p-3 bg-red-50 rounded-lg text-xs text-red-600 font-medium">
                        IMPORTANT: Please delete or rename <code>setup.php</code> to prevent unauthorized access.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>
