<?php
// sitemap.php - Dynamic XML Sitemap Generator
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

header("Content-Type: text/xml;charset=iso-8859-1");
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

$base_url = rtrim(SITE_URL, '/');

function add_url($loc, $lastmod = '', $changefreq = 'monthly', $priority = '0.5') {
    global $base_url;
    echo "  <url>\n";
    echo "    <loc>" . htmlspecialchars($base_url . $loc) . "</loc>\n";
    if ($lastmod) {
        echo "    <lastmod>$lastmod</lastmod>\n";
    }
    echo "    <changefreq>$changefreq</changefreq>\n";
    echo "    <priority>$priority</priority>\n";
    echo "  </url>\n";
}

// Core Output
$today = date('Y-m-d');

add_url('/', $today, 'daily', '1.0');
add_url('/account/login', '', 'yearly', '0.3');
add_url('/account/register', '', 'yearly', '0.3');
add_url('/blog', $today, 'daily', '0.8');

// Array of all explicit tools we built
$tools = [
    // Image
    '/tools/images/png-to-jpg',
    '/tools/images/jpg-to-png',
    '/tools/images/image-compressor',
    '/tools/images/image-resizer',
    '/tools/images/webp-converter',
    '/tools/images/svg-to-png',
    '/tools/images/gif-maker',
    
    // PDF
    '/tools/pdf/pdf-compressor',
    '/tools/pdf/pdf-merger',
    '/tools/pdf/pdf-splitter',
    '/tools/pdf/pdf-to-word',
    '/tools/pdf/word-to-pdf',
    '/tools/pdf/image-to-pdf',
    
    // Video/Audio
    '/tools/video/mp4-to-mp3',
    '/tools/video/video-compressor',
    '/tools/video/video-to-gif',
    '/tools/audio/mp3-converter',
    '/tools/audio/audio-cutter',
    
    // Developer
    '/tools/developer/json-formatter',
    '/tools/developer/base64-encode',
    '/tools/developer/hash-generator',
    '/tools/developer/url-encode',
    '/tools/developer/html-minifier',
    '/tools/developer/css-minifier',
    '/tools/developer/color-converter',
    
    // Text
    '/tools/text/word-counter',
    '/tools/text/case-converter',
    '/tools/text/lorem-ipsum',
    '/tools/text/text-diff',
    
    // Math
    '/tools/math/length',
    '/tools/math/weight',
    '/tools/math/temperature',
    '/tools/math/currency'
];

foreach ($tools as $tool) {
    add_url($tool, $today, 'weekly', '0.7');
}

// Fetch published blog posts
global $pdo;
try {
    $stmt = $pdo->query("SELECT slug, updated_at, created_at FROM posts WHERE status = 'published' ORDER BY created_at DESC LIMIT 1000");
    while ($post = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $date = $post['updated_at'] ? date('Y-m-d', strtotime($post['updated_at'])) : date('Y-m-d', strtotime($post['created_at']));
        add_url('/blog/' . $post['slug'], $date, 'monthly', '0.6');
    }
} catch (PDOException $e) {
    // Ignore db err
}

echo '</urlset>';
?>
