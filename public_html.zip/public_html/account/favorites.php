<?php
// account/favorites.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

// Handle add/remove favorite usually done via AJAX, but keeping basic POST fallback here
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (verify_csrf_token($_POST['csrf_token'])) {
        global $pdo;
        $tool_name = sanitize_input($_POST['tool_name']);
        
        if ($_POST['action'] === 'remove') {
            $stmt = $pdo->prepare("DELETE FROM favorites WHERE tool_name = ? AND user_id = ?");
            $stmt->execute([$tool_name, $_SESSION['user_id']]);
        } elseif ($_POST['action'] === 'add') {
            // Check if exists
            $stmt = $pdo->prepare("SELECT id FROM favorites WHERE tool_name = ? AND user_id = ?");
            $stmt->execute([$tool_name, $_SESSION['user_id']]);
            if (!$stmt->fetch()) {
                $stmt_insert = $pdo->prepare("INSERT INTO favorites (user_id, tool_name) VALUES (?, ?)");
                $stmt_insert->execute([$_SESSION['user_id'], $tool_name]);
            }
        }
        redirect('/account/favorites.php');
    }
}

// Fetch user favorites
global $pdo;
$stmt_favs = $pdo->prepare("SELECT * FROM favorites WHERE user_id = ? ORDER BY id DESC");
$stmt_favs->execute([$_SESSION['user_id']]);
$favorites = $stmt_favs->fetchAll();

$page_title = "Saved Tools";
include __DIR__ . '/../includes/header.php';

// Helper associative array mapping generic tool_name strings to links and icons
$tool_catalog = [
    'PNG to JPG' => ['link' => '/tools/png-to-jpg.php', 'icon' => 'fa-image', 'color' => 'text-blue-500 bg-blue-100'],
    'Image Compressor' => ['link' => '/tools/image-compressor.php', 'icon' => 'fa-compress', 'color' => 'text-purple-500 bg-purple-100'],
    'JPG to PDF' => ['link' => '/tools/jpg-to-pdf.php', 'icon' => 'fa-file-pdf', 'color' => 'text-red-500 bg-red-100'],
    'Merge PDF' => ['link' => '/tools/merge-pdf.php', 'icon' => 'fa-layer-group', 'color' => 'text-orange-500 bg-orange-100'],
];

?>

<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 min-h-[60vh]">
    <div class="mb-8 flex items-center justify-between">
        <div>
            <h1 class="text-3xl font-bold text-gray-900">Saved Tools</h1>
            <p class="mt-1 text-sm text-gray-500">Your most frequently used converters.</p>
        </div>
        <a href="<?php echo SITE_URL; ?>/account/dashboard.php" class="text-sm font-medium text-primary hover:text-indigo-700">
            &larr; Back to Dashboard
        </a>
    </div>

    <?php if (empty($favorites)): ?>
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-pink-50 text-pink-500 mb-4 text-2xl">
                <i class="fa-regular fa-heart"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900">No saved tools</h3>
            <p class="mt-2 text-sm text-gray-500">Click the heart icon on any tool page to save it here for quick access.</p>
            <div class="mt-6">
                <a href="<?php echo SITE_URL; ?>/" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-indigo-700">
                    Browse Tools
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($favorites as $fav): ?>
                <?php 
                    $t_name = $fav['tool_name'];
                    // Default fallback if not in catalog
                    $info = isset($tool_catalog[$t_name]) ? $tool_catalog[$t_name] : ['link' => '/', 'icon' => 'fa-wrench', 'color' => 'text-gray-500 bg-gray-100'];
                ?>
                <div class="tool-card bg-white rounded-xl p-6 relative group flex flex-col items-center text-center">
                    <form action="" method="POST" class="absolute top-4 right-4">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        <input type="hidden" name="action" value="remove">
                        <input type="hidden" name="tool_name" value="<?php echo htmlspecialchars($t_name); ?>">
                        <button type="submit" class="text-pink-500 hover:text-gray-400 transition-colors" title="Remove from favorites">
                            <i class="fa-solid fa-heart"></i>
                        </button>
                    </form>

                    <div class="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl mb-4 <?php echo $info['color']; ?>">
                        <i class="fa-solid <?php echo $info['icon']; ?>"></i>
                    </div>
                    <h3 class="font-bold text-lg text-gray-900 mb-1"><?php echo htmlspecialchars($t_name); ?></h3>
                    <a href="<?php echo SITE_URL . $info['link']; ?>" class="mt-4 inline-flex items-center text-sm font-medium text-primary hover:text-indigo-800 transition-colors">
                        Use Tool <i class="fa-solid fa-arrow-right ml-1"></i>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
