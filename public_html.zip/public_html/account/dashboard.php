<?php
// account/dashboard.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

// Fetch fresh user data
global $pdo;
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Fetch recent history
$stmt_history = $pdo->prepare("SELECT * FROM history WHERE user_id = ? ORDER BY date DESC LIMIT 5");
$stmt_history->execute([$_SESSION['user_id']]);
$recent_history = $stmt_history->fetchAll();

// Fetch favorites count
$stmt_favs = $pdo->prepare("SELECT COUNT(*) FROM favorites WHERE user_id = ?");
$stmt_favs->execute([$_SESSION['user_id']]);
$fav_count = $stmt_favs->fetchColumn();

// Fetch subscription info
$stmt_sub = $pdo->prepare("
    SELECT s.*, p.name as plan_name 
    FROM subscriptions s 
    JOIN plans p ON s.plan_id = p.id 
    WHERE s.user_id = ? AND s.status = 'active'
");
$stmt_sub->execute([$_SESSION['user_id']]);
$subscription = $stmt_sub->fetch();

$page_title = "Dashboard";
include __DIR__ . '/../includes/header.php';
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
    <div class="mb-8 flex flex-col md:flex-row md:items-center justify-between">
        <div>
            <h1 class="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p class="mt-1 text-sm text-gray-500">Welcome back, <?php echo htmlspecialchars($user['name']); ?>!</p>
        </div>
        <div class="mt-4 md:mt-0">
            <a href="<?php echo SITE_URL; ?>/account/logout.php" class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                <i class="fa-solid fa-sign-out-alt mr-2 text-gray-400"></i> Log Out
            </a>
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Account Status -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex items-center">
            <div class="p-3 rounded-full bg-indigo-100 text-primary mr-4 text-xl">
                <i class="fa-solid fa-user-shield"></i>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Account Type</p>
                <div class="flex items-center gap-2 mt-1">
                    <p class="text-xl font-bold text-gray-900">
                        <?php echo $subscription ? htmlspecialchars($subscription['plan_name']) : 'Free Plan'; ?>
                    </p>
                    <?php if (!$subscription): ?>
                        <a href="<?php echo SITE_URL; ?>/#pricing" class="px-2 py-0.5 mt-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800 border border-amber-200 hover:bg-amber-200 transition-colors">
                            <i class="fa-solid fa-bolt mr-1"></i>Upgrade
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Favorites -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex items-center justify-between">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-pink-100 text-pink-600 mr-4 text-xl">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-500">Saved Tools</p>
                    <p class="text-2xl font-bold text-gray-900 mt-1"><?php echo $fav_count; ?></p>
                </div>
            </div>
            <a href="<?php echo SITE_URL; ?>/account/favorites.php" class="text-sm text-primary hover:text-indigo-800 font-medium">View &rarr;</a>
        </div>

        <!-- History -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex items-center justify-between">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-emerald-100 text-emerald-600 mr-4 text-xl">
                    <i class="fa-solid fa-clock-rotate-left"></i>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-500">Recent Conversions</p>
                    <p class="text-2xl font-bold text-gray-900 mt-1"><?php echo count($recent_history); ?></p>
                </div>
            </div>
            <a href="<?php echo SITE_URL; ?>/account/history.php" class="text-sm text-primary hover:text-indigo-800 font-medium">View &rarr;</a>
        </div>
    </div>

    <!-- Recent History Section -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
            <h3 class="text-lg font-medium text-gray-900">Recent Activity</h3>
        </div>
        
        <?php if (empty($recent_history)): ?>
            <div class="p-10 text-center">
                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4 text-gray-400 text-2xl">
                    <i class="fa-solid fa-folder-open"></i>
                </div>
                <h3 class="text-sm font-medium text-gray-900">No conversions yet</h3>
                <p class="mt-1 text-sm text-gray-500">Go converting some files to see your history here.</p>
                <div class="mt-6">
                    <a href="<?php echo SITE_URL; ?>/" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-indigo-700">
                        <i class="fa-solid fa-plus mr-2 -ml-1"></i> Start Converting
                    </a>
                </div>
            </div>
        <?php else: ?>
            <ul class="divide-y divide-gray-100">
                <?php foreach ($recent_history as $item): ?>
                <li class="px-6 py-4 hover:bg-gray-50 transition-colors">
                    <div class="flex items-center justify-between space-x-4">
                        <div class="flex items-center space-x-4 truncate">
                            <span class="p-2 bg-gray-100 rounded text-gray-500 text-sm">
                                <i class="fa-solid fa-file"></i>
                            </span>
                            <div class="text-sm truncate">
                                <p class="text-gray-900 font-medium truncate"><?php echo htmlspecialchars($item['file_name'] ?: 'Unknown File'); ?></p>
                                <p class="text-gray-500 truncate mt-0.5">Used: <?php echo htmlspecialchars($item['tool_name']); ?></p>
                            </div>
                        </div>
                        <div class="text-sm text-gray-400 whitespace-nowrap">
                            <?php echo date('M j, Y g:i A', strtotime($item['date'])); ?>
                        </div>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
