<?php
// account/upgrade.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();

global $pdo;

// Fetch Plans
$stmt = $pdo->query("SELECT * FROM plans ORDER BY price ASC");
$plans = $stmt->fetchAll();

// Fetch current subscription
$stmt_sub = $pdo->prepare("SELECT plan_id FROM subscriptions WHERE user_id = ? AND status = 'active'");
$stmt_sub->execute([$_SESSION['user_id']]);
$current_plan_id = $stmt_sub->fetchColumn();

// Process Mock Payment
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['plan_id'])) {
    if (verify_csrf_token($_POST['csrf_token'])) {
        $plan_id = (int)$_POST['plan_id'];
        
        // Mocking a successful payment
        // Cancel old sub
        $pdo->prepare("UPDATE subscriptions SET status = 'canceled' WHERE user_id = ?")->execute([$_SESSION['user_id']]);
        
        // Create new sub
        $start_date = date('Y-m-d');
        $end_date = date('Y-m-d', strtotime('+1 month'));
        $stmt_insert = $pdo->prepare("INSERT INTO subscriptions (user_id, plan_id, status, start_date, end_date) VALUES (?, ?, 'active', ?, ?)");
        $stmt_insert->execute([$_SESSION['user_id'], $plan_id, $start_date, $end_date]);
        
        $message = "Payment successful! You are now subscribed to Premium.";
        $current_plan_id = $plan_id; // Update display
    }
}

$page_title = "Upgrade to Premium";
include __DIR__ . '/../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-12">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-12">
            <h1 class="text-4xl font-extrabold text-gray-900 tracking-tight">Upgrade Your Account</h1>
            <p class="mt-4 text-xl text-gray-600">Unlock the full potential of <?php echo SITE_NAME; ?> with our premium plans.</p>
        </div>

        <?php if ($message): ?>
            <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-8 text-green-700 mx-auto max-w-2xl rounded-r-lg shadow-sm flex items-center">
                <i class="fa-solid fa-circle-check text-2xl mr-3"></i>
                <span class="font-medium text-lg"><?php echo htmlspecialchars($message); ?></span>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <?php foreach($plans as $index => $plan): 
                $is_current = ($current_plan_id == $plan['id']);
                $features = explode(',', $plan['features']);
            ?>
            <div class="bg-white rounded-2xl shadow-xl border <?php echo $is_current ? 'border-indigo-500 ring-2 ring-indigo-500' : 'border-gray-200'; ?> p-8 relative flex flex-col">
                <?php if($is_current): ?>
                    <span class="absolute top-0 right-0 bg-indigo-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-xl uppercase tracking-wider">Current Plan</span>
                <?php elseif($index === array_key_last($plans)): ?>
                    <span class="absolute top-0 right-0 bg-amber-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-xl uppercase tracking-wider">Best Value</span>
                <?php endif; ?>
                
                <h3 class="text-2xl font-bold text-gray-900 mb-2"><?php echo htmlspecialchars($plan['name']); ?></h3>
                <div class="text-4xl font-extrabold text-gray-900 mb-6">$<?php echo htmlspecialchars($plan['price']); ?><span class="text-xl text-gray-500 font-medium">/mo</span></div>
                
                <ul class="space-y-4 mb-8 flex-1">
                    <?php foreach($features as $f): ?>
                    <li class="flex items-start text-gray-600">
                        <i class="fa-solid fa-check text-green-500 mt-1 mr-3 flex-shrink-0"></i> 
                        <span><?php echo htmlspecialchars(trim($f)); ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>

                <?php if($is_current): ?>
                    <button disabled class="w-full py-3 px-4 bg-gray-100 text-gray-500 font-bold text-center rounded-xl cursor-not-allowed">Active Subscription</button>
                <?php else: ?>
                    <button onclick="openPaymentModal(<?php echo $plan['id']; ?>, '<?php echo htmlspecialchars($plan['name']); ?>', '<?php echo $plan['price']; ?>')" class="w-full py-3 px-4 bg-primary hover:bg-indigo-700 text-white font-bold text-center rounded-xl transition-colors shadow">Subscribe Now</button>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>

    </div>
</div>

<!-- Mock Payment Modal -->
<div id="payment-modal" class="fixed inset-0 bg-gray-900 bg-opacity-75 z-50 hidden flex items-center justify-center">
    <div class="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl scale-95 transform transition-transform" id="modal-content">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-gray-900">Checkout</h3>
            <button onclick="closePaymentModal()" class="text-gray-400 hover:text-gray-600"><i class="fa-solid fa-times text-xl"></i></button>
        </div>
        
        <div class="bg-gray-50 rounded-lg p-4 mb-6 border border-gray-100 flex justify-between items-center">
            <div>
                <p class="text-sm text-gray-500">Selected Plan</p>
                <p class="font-bold text-gray-900" id="modal-plan-name">Pro Premium</p>
            </div>
            <div class="text-right">
                <p class="text-xs text-gray-500">Total Billed</p>
                <p class="font-bold text-lg text-primary">$<span id="modal-plan-price">19.99</span></p>
            </div>
        </div>

        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            <input type="hidden" name="plan_id" id="modal-plan-id" value="">
            
            <div class="space-y-4 mb-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Card Information</label>
                    <!-- Visual mock only -->
                    <div class="border border-gray-300 rounded-md px-3 py-2 bg-gray-50 flex items-center justify-between text-gray-400 pointer-events-none">
                        <span>**** **** **** 4242</span>
                        <div class="flex gap-1 text-lg">
                            <i class="fa-brands fa-cc-visa text-blue-800"></i>
                            <i class="fa-brands fa-cc-mastercard text-red-500"></i>
                        </div>
                    </div>
                    <p class="mt-1 text-xs text-green-600"><i class="fa-solid fa-lock text-green-600 mr-1"></i> SSL Encrypted Demo Payment</p>
                </div>
            </div>

            <button type="submit" class="w-full py-3 px-4 bg-green-600 hover:bg-green-700 text-white font-bold text-center rounded-xl transition-colors shadow flex items-center justify-center">
                <i class="fa-solid fa-shield-check mr-2"></i> Confirm Payment
            </button>
        </form>
    </div>
</div>

<script>
    function openPaymentModal(id, name, price) {
        document.getElementById('modal-plan-id').value = id;
        document.getElementById('modal-plan-name').innerText = name;
        document.getElementById('modal-plan-price').innerText = price;
        const modal = document.getElementById('payment-modal');
        modal.classList.remove('hidden');
        setTimeout(() => document.getElementById('modal-content').classList.remove('scale-95'), 10);
    }
    function closePaymentModal() {
        document.getElementById('modal-content').classList.add('scale-95');
        setTimeout(() => document.getElementById('payment-modal').classList.add('hidden'), 150);
    }
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
