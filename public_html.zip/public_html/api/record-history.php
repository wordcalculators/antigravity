<?php
// api/record-history.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

// Check logged in
if (!is_logged_in()) {
    echo json_encode(['status' => 'skipped', 'message' => 'User not logged in.']);
    exit;
}

$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE);

if (!isset($input['tool_name']) || !isset($input['file_name'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing parameters']);
    exit;
}

try {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO history (user_id, tool_name, file_name) VALUES (?, ?, ?)");
    $stmt->execute([
        $_SESSION['user_id'],
        sanitize_input($input['tool_name']),
        sanitize_input($input['file_name'])
    ]);
    
    echo json_encode(['status' => 'success']);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
