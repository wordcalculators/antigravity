<?php
// api/docs/index.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "API Documentation";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10 flex text-gray-800">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full flex flex-col md:flex-row gap-8">
        <!-- Sidebar Navigation -->
        <div class="w-full md:w-64 flex-shrink-0">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-24">
                <h3 class="font-bold text-gray-900 mb-4 uppercase text-sm tracking-wider">Developer API</h3>
                <nav class="space-y-2 text-sm">
                    <a href="#getting-started" class="block text-primary font-medium">Getting Started</a>
                    <a href="#authentication" class="block text-gray-600 hover:text-primary">Authentication</a>
                    <a href="#endpoints" class="block text-gray-600 hover:text-primary">Endpoints</a>
                    <a href="#errors" class="block text-gray-600 hover:text-primary">Errors</a>
                </nav>
            </div>
        </div>

        <!-- Doc Content -->
        <div class="flex-1 bg-white rounded-xl shadow-sm border border-gray-200 p-8 md:p-12 mb-10">
            <h1 class="text-3xl font-extrabold text-gray-900 mb-6 border-b border-gray-100 pb-4">API Documentation</h1>
            
            <section id="getting-started" class="mb-12">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">Getting Started</h2>
                <p class="mb-4">Integrate <?php echo SITE_NAME; ?>'s powerful file conversion tools directly into your own website or application. Our REST API is fast, predictable, and simple to use.</p>
                <div class="bg-blue-50 border-l-4 border-blue-500 p-4 text-sm text-blue-800 rounded-r-lg">
                    You can manage your API keys from your Dashboard under Account Settings.
                </div>
            </section>

            <section id="authentication" class="mb-12">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">Authentication</h2>
                <p class="mb-4">The API uses Bearer Tokens to authenticate requests. Send your API key in the Authorization header.</p>
                <div class="bg-gray-900 rounded-lg p-4 font-mono text-sm text-green-400 overflow-x-auto mb-4">
                    Authorization: Bearer YOUR_API_KEY
                </div>
                <p class="text-sm text-gray-500">Keep your API key secure. Do not share it publicly or expose it in client-side code.</p>
            </section>

            <section id="endpoints" class="mb-12">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">Endpoints</h2>
                
                <h3 class="text-lg font-bold text-gray-900 mt-6 mb-2">Convert File</h3>
                <div class="flex items-center gap-3 mb-4">
                    <span class="px-2 py-1 bg-green-100 text-green-800 rounded font-bold text-xs">POST</span>
                    <code class="font-mono text-gray-600">/api/v1/convert.php</code>
                </div>
                
                <p class="mb-4 text-sm">Upload a file to be processed. The file is uploaded as `multipart/form-data`.</p>

                <h4 class="font-semibold text-gray-700 mb-2">Parameters</h4>
                <table class="min-w-full text-sm text-left mb-6 border-collapse">
                    <thead>
                        <tr class="border-b border-gray-200 bg-gray-50">
                            <th class="py-2 px-4 font-semibold text-gray-600">Field</th>
                            <th class="py-2 px-4 font-semibold text-gray-600">Type</th>
                            <th class="py-2 px-4 font-semibold text-gray-600">Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="border-b border-gray-100">
                            <td class="py-2 px-4 font-mono font-bold">file</td>
                            <td class="py-2 px-4 text-gray-500">File</td>
                            <td class="py-2 px-4">The binary file to upload.</td>
                        </tr>
                        <tr class="border-b border-gray-100">
                            <td class="py-2 px-4 font-mono font-bold">tool</td>
                            <td class="py-2 px-4 text-gray-500">String</td>
                            <td class="py-2 px-4">The requested conversion operation (e.g. `JPG to PDF`).</td>
                        </tr>
                    </tbody>
                </table>

                <h4 class="font-semibold text-gray-700 mb-2">Example Request (cURL)</h4>
                <div class="bg-gray-900 rounded-lg p-4 font-mono text-sm text-gray-300 overflow-x-auto mb-6 leading-relaxed">
curl -X POST <?php echo SITE_URL; ?>/api/v1/convert.php \<br>
&nbsp;&nbsp;-H "Authorization: Bearer YOUR_API_KEY" \<br>
&nbsp;&nbsp;-F "file=@/path/to/image.jpg" \<br>
&nbsp;&nbsp;-F "tool=JPG to PDF"
                </div>

                <h4 class="font-semibold text-gray-700 mb-2">Response</h4>
                <div class="bg-gray-900 rounded-lg p-4 font-mono text-sm text-blue-300 overflow-x-auto mb-4">
{<br>
&nbsp;&nbsp;"success": true,<br>
&nbsp;&nbsp;"message": "File successfully processed via API.",<br>
&nbsp;&nbsp;"original_file": "image.jpg",<br>
&nbsp;&nbsp;"tool_applied": "JPG to PDF",<br>
&nbsp;&nbsp;"download_url": "http://yourdomain.com/api/v1/download-mock.php?id=...",<br>
&nbsp;&nbsp;"credits_remaining": "Unlimited (Mock)"<br>
}
                </div>
            </section>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
