<?php
// api/convert.php
// Document/backend conversion API endpoint (Skeleton for PDF/Doc processing)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

// In a real application, you would:
// 1. Verify CSRF
// 2. Check Plan Limits (File size, Batch quantity)
// 3. Process the physical file using tools like Ghostscript, TCPDF, ImageMagick
// 4. Return secure download link

// Skeleton Implementation
$tool = isset($_POST['tool']) ? sanitize_input($_POST['tool']) : '';

if (!isset($_FILES['file']) && !isset($_FILES['files'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'No files uploaded']);
    exit;
}

// MOCK PROCESSING: We pretend to do the heavy lifting here and immediately return success
// In production, instantiate required library classes here

sleep(2); // Simulate backend processing time

// Record history if logged in
if (is_logged_in() && isset($_FILES['file']['name'])) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO history (user_id, tool_name, file_name) VALUES (?, ?, ?)");
    $stmt->execute([
        $_SESSION['user_id'],
        $tool ?: 'Backend Tool',
        $_FILES['file']['name']
    ]);
}

// Return mock response indicating successful "processing"
echo json_encode([
    'success' => true,
    'message' => 'File successfully processed by backend engine.',
    // Returning dummy PDF data for demo purposes (a tiny base64 encoded valid PDF)
    'download_url' => 'data:application/pdf;base64,JVBERi0xLjEKJcKlwrHDqwoxIDAgb2JqCjw8IC9UeXBlIC9DYXRhbG9nIC9QYWdlcyAyIDAgUiA+PgplbmRvYmoKMiAwIG9iago8PCAvVHlwZSAvUGFnZXMgL0tpZHMgWzMgMCBSXSAvQ291bnQgMSA+PgplbmRvYmoKMyAwIG9iago8PCAvVHlwZSAvUGFnZSAvUGFyZW50IDIgMCBSIC9NZWRpYUJveCBbMCAwIDYxMiA3OTJdID4+CmVuZG9iagp0cmFpbGVyCjw8IC9Sb290IDEgMCBSIC9TaXplIDQgPj4KJSVFT0YK'
]);
