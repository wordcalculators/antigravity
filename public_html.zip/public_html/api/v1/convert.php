<?php
// api/v1/convert.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow external domains

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

// Api Key Validation
$headers = apache_request_headers();
$api_key = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!$api_key) {
    http_response_code(401);
    echo json_encode(['error' => 'API key required in Authorization header']);
    exit;
}

global $pdo;
$stmt = $pdo->prepare("SELECT id, status FROM users WHERE api_key = ?");
$stmt->execute([$api_key]);
$user = $stmt->fetch();

if (!$user || $user['status'] !== 'active') {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid or inactive API key']);
    exit;
}

$user_id = $user['id'];

// Check file
if (!isset($_FILES['file'])) {
    http_response_code(400);
    echo json_encode(['error' => 'No file uploaded']);
    exit;
}

$tool = isset($_POST['tool']) ? sanitize_input($_POST['tool']) : 'API Conversion';
$file = $_FILES['file'];

// Log request
$stmt_log = $pdo->prepare("INSERT INTO history (user_id, tool_name, file_name) VALUES (?, ?, ?)");
$stmt_log->execute([$user_id, $tool, $file['name']]);

// Return Mock Success for 3rd Party
echo json_encode([
    'success' => true,
    'message' => 'File successfully processed via API.',
    'original_file' => $file['name'],
    'tool_applied' => $tool,
    'download_url' => SITE_URL . '/api/v1/download-mock.php?id=' . uniqid(),
    'credits_remaining' => 'Unlimited (Mock)'
]);
