// assets/js/image-tools.js

class ImageProcessor {
    constructor() {
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('2d');
    }

    /**
     * Convert an Image object to a specific format
     * @param {HTMLImageElement} img 
     * @param {string} mimeType 'image/jpeg', 'image/png', 'image/webp'
     * @param {number} quality 0.0 to 1.0 (for jpeg/webp)
     * @returns {Promise<Blob>}
     */
    convertImage(img, mimeType, quality = 0.9) {
        return new Promise((resolve) => {
            this.canvas.width = img.width;
            this.canvas.height = img.height;
            
            // Fill background white for PNG to JPG conversion (to handle transparency)
            if (mimeType === 'image/jpeg') {
                this.ctx.fillStyle = '#FFFFFF';
                this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
            } else {
                this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
            }

            this.ctx.drawImage(img, 0, 0);

            this.canvas.toBlob((blob) => {
                resolve(blob);
            }, mimeType, quality);
        });
    }

    /**
     * Compress an image
     * @param {HTMLImageElement} img 
     * @param {number} quality 0.0 to 1.0
     * @returns {Promise<Blob>}
     */
    compressImage(img, quality = 0.7) {
        return this.convertImage(img, 'image/jpeg', quality);
    }
}

// Global UI handling for tool pages
document.addEventListener('DOMContentLoaded', () => {
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const previewContainer = document.getElementById('preview-container');
    const previewImg = document.getElementById('preview-img');
    const actionBtn = document.getElementById('action-btn');
    const downloadBtn = document.getElementById('download-btn');
    const loader = document.getElementById('processing-loader');

    let currentFile = null;
    let originalImage = null;
    let processedBlob = null;
    let outputFilename = '';
    
    // Config injected by the specific tool page
    const toolConfig = window.ImageToolConfig || {
        action: 'convert',
        targetMime: 'image/jpeg',
        targetExt: 'jpg'
    };

    if (!dropZone || !fileInput) return;

    // Trigger file selection
    dropZone.addEventListener('click', () => fileInput.click());

    // Drag and drop events
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.add('dragover'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.remove('dragover'), false);
    });

    dropZone.addEventListener('drop', handleDrop, false);
    fileInput.addEventListener('change', handleFileSelect, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }

    function handleFileSelect(e) {
        handleFiles(e.target.files);
    }

    function handleFiles(files) {
        if (files.length === 0) return;
        currentFile = files[0];
        
        // Basic validation
        if (!currentFile.type.startsWith('image/')) {
            showNotification('Please upload an image file.', 'error');
            return;
        }

        // Generate output filename
        const baseName = currentFile.name.substring(0, currentFile.name.lastIndexOf('.'));
        if (toolConfig.action === 'compress') {
            outputFilename = `${baseName}_compressed.${toolConfig.targetExt}`;
        } else {
            outputFilename = `${baseName}_converted.${toolConfig.targetExt}`;
        }

        // Preview image
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                originalImage = img;
                previewImg.src = e.target.result;
                dropZone.classList.add('hidden');
                previewContainer.classList.remove('hidden');
                resetActionState();
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(currentFile);
    }

    // Processing Flow
    if (actionBtn) {
        actionBtn.addEventListener('click', async () => {
            if (!originalImage) return;

            actionBtn.disabled = true;
            loader.classList.remove('hidden');
            
            // Gather extra params if needed
            const qualityInput = document.getElementById('quality-slider');
            const quality = qualityInput ? parseInt(qualityInput.value) / 100 : 0.9;

            const processor = new ImageProcessor();
            
            try {
                // Determine action based on config
                if (toolConfig.action === 'compress') {
                    processedBlob = await processor.compressImage(originalImage, quality);
                } else {
                    processedBlob = await processor.convertImage(originalImage, toolConfig.targetMime, quality);
                }

                // Prepare download
                const url = URL.createObjectURL(processedBlob);
                downloadBtn.href = url;
                downloadBtn.download = outputFilename;
                
                actionBtn.classList.add('hidden');
                downloadBtn.classList.remove('hidden');
                
                // Show success & Record history
                showNotification('Processing complete!', 'success');
                recordHistory(window.location.pathname.split('/').pop().replace('.php', ''), outputFilename);

            } catch (err) {
                console.error(err);
                showNotification('An error occurred during processing.', 'error');
                actionBtn.disabled = false;
            } finally {
                loader.classList.add('hidden');
            }
        });
    }

    // Reset UI
    document.getElementById('reset-btn')?.addEventListener('click', () => {
        currentFile = null;
        originalImage = null;
        processedBlob = null;
        fileInput.value = '';
        dropZone.classList.remove('hidden');
        previewContainer.classList.add('hidden');
        resetActionState();
    });

    function resetActionState() {
        if(actionBtn) {
            actionBtn.classList.remove('hidden');
            actionBtn.disabled = false;
        }
        if(downloadBtn) {
            downloadBtn.classList.add('hidden');
        }
    }

    function recordHistory(toolName, fileName) {
        // Send async request to save history to DB if user is logged in
        // Implemented using a simple fetch to an API endpoint
        fetch(`${window.location.origin}/api/record-history.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                tool_name: toolName,
                file_name: fileName
            })
        }).catch(e => console.log('History recording skipped or failed'));
    }
});
