// assets/js/main.js

document.addEventListener('DOMContentLoaded', () => {
    // Mobile menu toggle
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    }

    // Initialize global tool search
    const globalSearch = document.getElementById('global-search');
    if (globalSearch) {
        globalSearch.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            // In a real implementation, this would filter a list of tools or redirect to search page
            // Simple mockup behavior:
            console.log("Searching for:", query);
        });
    }
});

// Helper for showing notifications
function showNotification(message, type = 'success') {
    const notifyEle = document.createElement('div');
    notifyEle.className = `fixed bottom-4 right-4 px-6 py-3 rounded-md shadow-lg text-white font-medium z-50 transform transition-all duration-300 translate-y-10 opacity-0`;
    
    if (type === 'success') {
        notifyEle.classList.add('bg-green-500');
    } else if (type === 'error') {
        notifyEle.classList.add('bg-red-500');
    } else {
        notifyEle.classList.add('bg-blue-500');
    }

    notifyEle.innerText = message;
    document.body.appendChild(notifyEle);

    // Animate in
    setTimeout(() => {
        notifyEle.classList.remove('translate-y-10', 'opacity-0');
    }, 10);

    // Remove after 3 seconds
    setTimeout(() => {
        notifyEle.classList.add('translate-y-10', 'opacity-0');
        setTimeout(() => notifyEle.remove(), 300);
    }, 3000);
}
