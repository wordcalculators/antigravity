<?php
// blog/index.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

$page_title = "Blog - File Conversion Tips & Guides";
$meta_description = "Learn the best ways to convert, compress, and edit your digital files. Tips on image formats, PDF management, and productivity.";
include __DIR__ . '/../includes/header.php';

// Mock blog posts
$posts = [
    [
        'id' => 1,
        'title' => 'PNG vs JPG: Which Image Format Should You Use?',
        'slug' => 'png-vs-jpg-guide',
        'excerpt' => 'Understanding the difference between PNG and JPG is crucial for web performance and image quality. Here is the ultimate guide to choosing the right format.',
        'author' => 'Sarah Content',
        'date' => 'Oct 12, 2024',
        'category' => 'Image Tips',
        'image' => 'https://images.unsplash.com/photo-1542831371-29b0f74f9713?auto=format&fit=crop&w=800&q=80'
    ],
    [
        'id' => 2,
        'title' => 'How to Reduce PDF File Size for Email Attachments',
        'slug' => 'compress-pdf-for-email',
        'excerpt' => 'Tired of having your emails bounce because the PDF attachment is too large? Learn how to effectively compress PDF files without losing readability.',
        'author' => 'Mark Tech',
        'date' => 'Oct 05, 2024',
        'category' => 'PDF Guides',
        'image' => 'https://images.unsplash.com/photo-1618044736300-4af314840e60?auto=format&fit=crop&w=800&q=80'
    ],
    [
        'id' => 3,
        'title' => 'The Complete Guide to the WebP Format',
        'slug' => 'ultimate-webp-guide',
        'excerpt' => 'WebP is becoming the standard for modern web images. Find out how it compares to traditional formats and how to start using it today.',
        'author' => 'David Designer',
        'date' => 'Sep 28, 2024',
        'category' => 'Web Performance',
        'image' => 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?auto=format&fit=crop&w=800&q=80'
    ]
];
?>

<div class="bg-gray-50 min-h-screen py-10">
    <!-- Blog Header -->
    <div class="bg-primary text-white py-16 mb-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">The Conversion Blog</h1>
            <p class="text-xl text-indigo-100 max-w-2xl mx-auto">Tips, tutorials, and guides to help you manage your digital files like a pro.</p>
        </div>
    </div>

    <!-- Blog Grid -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            <?php foreach($posts as $post): ?>
            <article class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-lg transition-shadow flex flex-col">
                <a href="<?php echo SITE_URL; ?>/blog/post-template.php?slug=<?php echo urlencode($post['slug']); ?>" class="block relative h-48 overflow-hidden">
                    <img src="<?php echo $post['image']; ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" class="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500">
                    <span class="absolute top-4 left-4 bg-white/90 backdrop-blur text-primary text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                        <?php echo htmlspecialchars($post['category']); ?>
                    </span>
                </a>
                <div class="p-6 flex-1 flex flex-col">
                    <div class="text-sm text-gray-500 mb-2 flex items-center justify-between">
                        <span><i class="fa-regular fa-calendar mr-1"></i> <?php echo $post['date']; ?></span>
                        <span><?php echo htmlspecialchars($post['author']); ?></span>
                    </div>
                    <h2 class="text-xl font-bold text-gray-900 mb-3 line-clamp-2 hover:text-primary transition-colors">
                        <a href="<?php echo SITE_URL; ?>/blog/post-template.php?slug=<?php echo urlencode($post['slug']); ?>">
                            <?php echo htmlspecialchars($post['title']); ?>
                        </a>
                    </h2>
                    <p class="text-gray-600 mb-4 line-clamp-3 text-sm flex-1">
                        <?php echo htmlspecialchars($post['excerpt']); ?>
                    </p>
                    <a href="<?php echo SITE_URL; ?>/blog/post-template.php?slug=<?php echo urlencode($post['slug']); ?>" class="text-primary font-medium hover:text-indigo-800 flex items-center mt-auto">
                        Read Article <i class="fa-solid fa-arrow-right ml-2 text-xs"></i>
                    </a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
        
        <!-- Pagination -->
        <div class="flex justify-center mt-12 mb-8">
            <nav class="inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <a href="#" class="relative inline-flex items-center px-4 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    Previous
                </a>
                <a href="#" aria-current="page" class="z-10 bg-indigo-50 border-primary text-primary relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                    1
                </a>
                <a href="#" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                    2
                </a>
                <a href="#" class="relative inline-flex items-center px-4 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    Next
                </a>
            </nav>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
