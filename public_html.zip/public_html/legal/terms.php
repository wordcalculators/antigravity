<?php
// legal/terms.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

$page_title = "Terms of Service";
include __DIR__ . '/../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-12">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-white rounded-2xl shadow-sm border border-gray-100 p-8 md:p-12">
        <h1 class="text-4xl font-extrabold text-gray-900 mb-8 border-b border-gray-100 pb-6">Terms of Service</h1>
        
        <div class="prose max-w-none text-gray-600 space-y-6">
            <p>Last updated: <?php echo date('F j, Y'); ?></p>
            
            <p>By accessing the website at <?php echo SITE_URL; ?>, you are agreeing to be bound by these terms of service, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws.</p>
            
            <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">1. Use License</h2>
            <p>Permission is granted to temporarily use the materials and conversion tools on <?php echo SITE_NAME; ?>'s website for personal, non-commercial, or commercial transitory viewing only.</p>
            
            <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">2. Prohibited Uses</h2>
            <p>You may not use this website to process illegal, copyrighted (without permission), sexually explicit, or malicious (malware) files. Accounts found abusing the API or uploading harmful content will be instantly terminated.</p>

            <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">3. Premium Subscriptions</h2>
            <p>Premium users are billed according to the selected plan. Subscriptions auto-renew unless canceled prior to the billing cycle. Payments are non-refundable after the first 7 days of service.</p>

            <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">4. Disclaimer</h2>
            <p>The materials on <?php echo SITE_NAME; ?>'s website are provided on an 'as is' basis. We make no warranties, expressed or implied, regarding the continuous availability of the tools or the accuracy of conversions.</p>
            
            <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">5. Revisions and Errata</h2>
            <p>The materials appearing on the website could include technical, typographical, or photographic errors. We may make changes to the materials contained on its website at any time without notice.</p>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
