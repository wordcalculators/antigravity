<?php
// legal/privacy-policy.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

$page_title = "Privacy Policy";
include __DIR__ . '/../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-12">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-white rounded-2xl shadow-sm border border-gray-100 p-8 md:p-12">
        <h1 class="text-4xl font-extrabold text-gray-900 mb-8 border-b border-gray-100 pb-6">Privacy Policy</h1>
        
        <div class="prose max-w-none text-gray-600 space-y-6">
            <p>Last updated: <?php echo date('F j, Y'); ?></p>
            
            <p>At <?php echo SITE_NAME; ?>, accessible from <?php echo SITE_URL; ?>, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by <?php echo SITE_NAME; ?> and how we use it.</p>
            
            <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">1. Data Processing and File Uploads</h2>
            <p><strong>Browser-Based Tools (Images):</strong> For tools like image converters and compressors, we utilize HTML5 Canvas and JavaScript to process your files locally on your device. <b>These files are never uploaded to our servers.</b></p>
            <p><strong>Server-Based Tools (PDFs, Documents):</strong> For complex files that require server-side rendering, your files are securely uploaded via HTTPS. Once the conversion process finishes, the original file and the newly converted file are automatically and permanently deleted from our servers within 1 hour.</p>

            <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">2. Information We Collect</h2>
            <p>If you choose to create an account, we collect your name, email address, and hashed password. We also record your conversion history and saved tool preferences strictly for delivering features within your dashboard.</p>
            
            <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">3. Log Files</h2>
            <p><?php echo SITE_NAME; ?> follows a standard procedure of using log files. These files log visitors when they visit websites. The information collected by log files include internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages.</p>

            <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">4. Cookies</h2>
            <p>Like any other website, <?php echo SITE_NAME; ?> uses 'cookies'. These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited to optimize users' experience.</p>
            
            <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">5. Contact Information</h2>
            <p>If you have any questions or concerns regarding our privacy policy, please contact us at support@onlineconvert.co.</p>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
