<?php
// index.php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

$page_title = "Free Online File Converter";
$meta_description = "Convert images, documents, and utilities online for free. Fast, secure, and fully browser-based conversions.";
include __DIR__ . '/includes/header.php';
?>

<!-- Hero Section -->
<section class="relative bg-gradient-to-br from-indigo-900 to-indigo-800 text-white overflow-hidden pt-20 pb-24 lg:pt-32 lg:pb-40">
    <div class="absolute inset-0 z-0">
        <svg class="absolute top-0 right-0 w-1/2 h-full opacity-10 transform translate-x-1/3" viewBox="0 0 100 100" preserveAspectRatio="none">
            <polygon fill="currentColor" points="0,100 100,0 100,100"/>
        </svg>
    </div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <h1 class="text-4xl md:text-6xl font-extrabold tracking-tight mb-6 mt-10">
            Convert Files <span class="text-secondary bg-clip-text">Instantly.</span>
        </h1>
        <p class="max-w-2xl mx-auto text-xl text-indigo-200 mb-10">
            Free, fast, and secure online file conversion. Images, documents, and utility tools at your fingertips. No installation required.
        </p>
        
        <!-- Quick Converter Selection -->
        <div class="max-w-3xl mx-auto bg-white rounded-2xl p-4 shadow-2xl flex flex-col md:flex-row items-center gap-4">
            <div class="w-full md:w-5/12 text-gray-800 text-left">
                <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 ml-1" for="convert_from">Convert from</label>
                <select id="convert_from" class="w-full bg-gray-50 border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent font-medium">
                    <option value="png">PNG Image</option>
                    <option value="jpg">JPG Image</option>
                    <option value="webp">WebP Image</option>
                    <option value="pdf">PDF Document</option>
                </select>
            </div>
            <div class="hidden md:flex flex-shrink-0 text-gray-400 mt-5">
                <i class="fa-solid fa-arrow-right-long text-xl"></i>
            </div>
            <div class="w-full md:w-5/12 text-gray-800 text-left">
                <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 ml-1" for="convert_to">To</label>
                <select id="convert_to" class="w-full bg-gray-50 border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent font-medium">
                    <option value="jpg">JPG Image</option>
                    <option value="png">PNG Image</option>
                    <option value="webp">WebP Image</option>
                    <option value="pdf">PDF Document</option>
                </select>
            </div>
            <div class="w-full md:w-2/12 mt-5 md:mt-5">
                <button type="button" onclick="document.location='<?php echo SITE_URL; ?>/tools/images/png-to-jpg'" class="w-full bg-primary hover:bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg shadow-md transition-all duration-200 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
                    GO <i class="fa-solid fa-bolt ml-1"></i>
                </button>
            </div>
        </div>
    </div>
</section>

<!-- Popular Tools Section -->
<section class="py-20 bg-gray-50 bg-opacity-50" id="image-tools">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-3xl mx-auto mb-16">
            <span class="text-primary font-semibold tracking-wider uppercase text-sm">Most Used</span>
            <h2 class="text-3xl font-extrabold text-gray-900 sm:text-4xl mt-2">Popular Image Tools</h2>
            <p class="mt-4 text-lg text-gray-500">Fast, secure image conversions tailored for developers and everyday users alike.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <!-- Tool Card 1 -->
            <a href="<?php echo SITE_URL; ?>/tools/images/png-to-jpg" class="tool-card group bg-white rounded-2xl p-6 relative overflow-hidden flex flex-col items-center text-center">
                <div class="w-16 h-16 rounded-2xl bg-blue-50 text-blue-500 flex items-center justify-center text-3xl mb-5 group-hover:scale-110 transition-transform duration-300 group-hover:bg-blue-500 group-hover:text-white">
                    <i class="fa-regular fa-image"></i>
                </div>
                <h3 class="text-lg font-bold text-gray-900 mb-2">PNG to JPG</h3>
                <p class="text-sm text-gray-500">Convert transparent PNGs to compressed JPG files instantly.</p>
            </a>
            
            <!-- Tool Card 2 -->
            <a href="<?php echo SITE_URL; ?>/tools/images/image-compressor" class="tool-card group bg-white rounded-2xl p-6 relative overflow-hidden flex flex-col items-center text-center">
                <div class="w-16 h-16 rounded-2xl bg-purple-50 text-purple-500 flex items-center justify-center text-3xl mb-5 group-hover:scale-110 transition-transform duration-300 group-hover:bg-purple-500 group-hover:text-white">
                    <i class="fa-solid fa-compress-arrows-alt"></i>
                </div>
                <h3 class="text-lg font-bold text-gray-900 mb-2">Compress Image</h3>
                <p class="text-sm text-gray-500">Reduce file size without losing quality using smart compression.</p>
            </a>

            <!-- Tool Card 3 -->
            <a href="<?php echo SITE_URL; ?>/tools/images/jpg-to-png" class="tool-card group bg-white rounded-2xl p-6 relative overflow-hidden flex flex-col items-center text-center">
                <div class="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-500 flex items-center justify-center text-3xl mb-5 group-hover:scale-110 transition-transform duration-300 group-hover:bg-emerald-500 group-hover:text-white">
                    <i class="fa-solid fa-file-image"></i>
                </div>
                <h3 class="text-lg font-bold text-gray-900 mb-2">JPG to PNG</h3>
                <p class="text-sm text-gray-500">Convert photos into PNG formatting for transparency support.</p>
            </a>

            <!-- Tool Card 4 -->
            <a href="<?php echo SITE_URL; ?>/tools/images/image-cropper" class="tool-card group bg-white rounded-2xl p-6 relative overflow-hidden flex flex-col items-center text-center">
                <div class="w-16 h-16 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center text-3xl mb-5 group-hover:scale-110 transition-transform duration-300 group-hover:bg-amber-500 group-hover:text-white">
                    <i class="fa-solid fa-crop-simple"></i>
                </div>
                <h3 class="text-lg font-bold text-gray-900 mb-2">Crop Image</h3>
                <p class="text-sm text-gray-500">Precisely crop your images to perfect dimensions.</p>
            </a>
        </div>
    </div>
</section>

<!-- PDF Tools -->
<section class="py-20 bg-white" id="pdf-tools">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-3xl mx-auto mb-16">
            <span class="text-primary font-semibold tracking-wider uppercase text-sm">Document Management</span>
            <h2 class="text-3xl font-extrabold text-gray-900 sm:text-4xl mt-2">PDF Tools</h2>
            <p class="mt-4 text-lg text-gray-500">Easily split, merge, and convert PDF documents.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <a href="<?php echo SITE_URL; ?>/tools/pdf/jpg-to-pdf" class="tool-card flex bg-gray-50 rounded-xl p-6 items-center">
                <div class="bg-red-100 text-red-500 p-4 rounded-xl text-2xl mr-4"><i class="fa-solid fa-file-pdf"></i></div>
                <div>
                    <h3 class="font-bold text-gray-900">JPG to PDF</h3>
                    <p class="text-sm text-gray-500 mt-1">Combine images into a single PDF.</p>
                </div>
            </a>
            <a href="<?php echo SITE_URL; ?>/tools/pdf/pdf-to-jpg" class="tool-card flex bg-gray-50 rounded-xl p-6 items-center">
                <div class="bg-indigo-100 text-indigo-500 p-4 rounded-xl text-2xl mr-4"><i class="fa-solid fa-images"></i></div>
                <div>
                    <h3 class="font-bold text-gray-900">PDF to JPG</h3>
                    <p class="text-sm text-gray-500 mt-1">Extract pages from PDF to JPGs.</p>
                </div>
            </a>
            <a href="<?php echo SITE_URL; ?>/tools/pdf/merge-pdf" class="tool-card flex bg-gray-50 rounded-xl p-6 items-center">
                <div class="bg-orange-100 text-orange-500 p-4 rounded-xl text-2xl mr-4"><i class="fa-solid fa-layer-group"></i></div>
                <div>
                    <h3 class="font-bold text-gray-900">Merge PDF</h3>
                    <p class="text-sm text-gray-500 mt-1">Join multiple PDFs into one.</p>
                </div>
            </a>
        </div>
    </div>
</section>

<!-- Utility Tools -->
<section class="py-20 bg-gray-50" id="utility-tools">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <h2 class="text-2xl font-bold text-gray-900 mb-8 border-b border-gray-200 pb-4">Utility Tools</h2>
        
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <!-- Utility Links -->
            <a href="<?php echo SITE_URL; ?>/tools/developer/qr-generator" class="bg-white p-4 rounded-xl border border-gray-100 shadow-sm hover:shadow-md hover:border-primary transition-all text-center group">
                <i class="fa-solid fa-qrcode text-2xl text-gray-400 group-hover:text-primary mb-2 transition-colors"></i>
                <div class="text-sm font-medium text-gray-700">QR Generator</div>
            </a>
            <a href="<?php echo SITE_URL; ?>/tools/developer/json-formatter" class="bg-white p-4 rounded-xl border border-gray-100 shadow-sm hover:shadow-md hover:border-primary transition-all text-center group">
                <i class="fa-solid fa-code text-2xl text-gray-400 group-hover:text-primary mb-2 transition-colors"></i>
                <div class="text-sm font-medium text-gray-700">JSON Format</div>
            </a>
            <a href="<?php echo SITE_URL; ?>/tools/developer/base64-encode" class="bg-white p-4 rounded-xl border border-gray-100 shadow-sm hover:shadow-md hover:border-primary transition-all text-center group">
                <i class="fa-solid fa-bolt text-2xl text-gray-400 group-hover:text-primary mb-2 transition-colors"></i>
                <div class="text-sm font-medium text-gray-700">Base64 Enc</div>
            </a>
            <a href="<?php echo SITE_URL; ?>/tools/developer/url-encode" class="bg-white p-4 rounded-xl border border-gray-100 shadow-sm hover:shadow-md hover:border-primary transition-all text-center group">
                <i class="fa-solid fa-link text-2xl text-gray-400 group-hover:text-primary mb-2 transition-colors"></i>
                <div class="text-sm font-medium text-gray-700">URL Encode</div>
            </a>
            <a href="<?php echo SITE_URL; ?>/tools/developer/color-converter" class="bg-white p-4 rounded-xl border border-gray-100 shadow-sm hover:shadow-md hover:border-primary transition-all text-center group">
                <i class="fa-solid fa-palette text-2xl text-gray-400 group-hover:text-primary mb-2 transition-colors"></i>
                <div class="text-sm font-medium text-gray-700">Color Convert</div>
            </a>
            <a href="<?php echo SITE_URL; ?>/tools/developer/html-minifier" class="bg-white p-4 rounded-xl border border-gray-100 shadow-sm hover:shadow-md hover:border-primary transition-all text-center group">
                <i class="fa-brands fa-html5 text-2xl text-gray-400 group-hover:text-primary mb-2 transition-colors"></i>
                <div class="text-sm font-medium text-gray-700">HTML Minify</div>
            </a>
        </div>
    </div>
</section>

<!-- Benefits Section -->
<section class="py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div>
                <h2 class="text-3xl font-extrabold text-gray-900 mb-6">Why Choose OnlineConvert.co?</h2>
                <div class="space-y-8">
                    <div class="flex">
                        <div class="flex-shrink-0 mt-1">
                            <i class="fa-solid fa-shield-halved text-2xl text-secondary"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-bold text-gray-900">100% Secure & Private</h3>
                            <p class="mt-2 text-gray-500">Most of our image tools process files directly in your browser. Files never leave your device unless backend processing is explicitly required.</p>
                        </div>
                    </div>
                    <div class="flex">
                        <div class="flex-shrink-0 mt-1">
                            <i class="fa-solid fa-gauge-high text-2xl text-primary"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-bold text-gray-900">Lightning Fast</h3>
                            <p class="mt-2 text-gray-500">Since we utilize your device's processing power with HTML5 canvas, conversions happen instantly without wait times.</p>
                        </div>
                    </div>
                    <div class="flex">
                        <div class="flex-shrink-0 mt-1">
                            <i class="fa-solid fa-mobile-screen-button text-2xl text-indigo-500"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-bold text-gray-900">Mobile Responsive</h3>
                            <p class="mt-2 text-gray-500">Whether you're on a desktop or an iPhone, the platform flawlessly adapts to your screen size for optimal usage everywhere.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-gradient-to-tr from-indigo-100 to-blue-50 p-8 rounded-3xl relative">
                <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80" alt="Dashboard Preview" class="rounded-xl shadow-2xl relative z-10" />
                <div class="absolute -bottom-6 -right-6 w-32 h-32 bg-secondary rounded-full filter blur-3xl opacity-50 z-0"></div>
            </div>
        </div>
    </div>
</section>

<!-- Pricing Placeholder -->
<section id="pricing" class="py-20 bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <span class="text-primary font-semibold tracking-wider uppercase text-sm">Pricing</span>
        <h2 class="text-3xl font-extrabold text-gray-900 sm:text-4xl mt-2 mb-16">Simple Plans for Professionals</h2>
        
        <div class="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Free Plan -->
            <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 text-left relative">
                <h3 class="text-2xl font-bold text-gray-900 mb-2">Free Version</h3>
                <p class="text-gray-500 mb-6">Perfect for quick, occasional tasks.</p>
                <div class="text-4xl font-extrabold text-gray-900 mb-6">$0</div>
                <ul class="space-y-4 mb-8">
                    <li class="flex items-center text-gray-600"><i class="fa-solid fa-check text-secondary mr-3"></i> Access to all basic tools</li>
                    <li class="flex items-center text-gray-600"><i class="fa-solid fa-check text-secondary mr-3"></i> File size limits applied</li>
                    <li class="flex items-center text-gray-600"><i class="fa-solid fa-check text-secondary mr-3"></i> Supported by ads</li>
                </ul>
                <a href="<?php echo SITE_URL; ?>/account/register.php" class="block w-full py-3 px-4 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold text-center rounded-xl transition-colors">Get Started</a>
            </div>
            
            <!-- Premium Plan -->
            <div class="bg-primary rounded-2xl shadow-xl border border-indigo-500 p-8 text-left relative transform md:-translate-y-4">
                <div class="absolute top-0 right-0 bg-secondary text-white text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-xl uppercase tracking-wider">Most Popular</div>
                <h3 class="text-2xl font-bold text-white mb-2">Pro Premium</h3>
                <p class="text-indigo-200 mb-6">For power users who need no limits.</p>
                <div class="text-4xl font-extrabold text-white mb-6">$19<span class="text-xl text-indigo-200 font-medium">.99</span></div>
                <ul class="space-y-4 mb-8">
                    <li class="flex items-center text-indigo-100"><i class="fa-solid fa-check text-secondary mr-3"></i> <b>Ad-free</b> experience</li>
                    <li class="flex items-center text-indigo-100"><i class="fa-solid fa-check text-secondary mr-3"></i> <b>Batch conversion</b> support</li>
                    <li class="flex items-center text-indigo-100"><i class="fa-solid fa-check text-secondary mr-3"></i> Unlimited file sizes</li>
                    <li class="flex items-center text-indigo-100"><i class="fa-solid fa-check text-secondary mr-3"></i> Complete conversion history</li>
                </ul>
                <a href="<?php echo SITE_URL; ?>/account/upgrade.php" class="block w-full py-3 px-4 bg-white hover:bg-gray-50 text-primary font-bold text-center rounded-xl transition-colors shadow-sm">Upgrade Now</a>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
