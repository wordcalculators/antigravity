<?php
// includes/auth.php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

function login_user($email, $password) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        if ($user['status'] !== 'active') {
            return ['success' => false, 'message' => 'Account is ' . $user['status'] . '.'];
        }
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role'];
        return ['success' => true];
    }
    return ['success' => false, 'message' => 'Invalid email or password.'];
}

function register_user($name, $email, $password) {
    global $pdo;

    // Check if email exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        return ['success' => false, 'message' => 'Email already registered.'];
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    
    try {
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)");
        $stmt->execute([$name, $email, $hash]);
        
        $user_id = $pdo->lastInsertId();
        $_SESSION['user_id'] = $user_id;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_role'] = 'user';
        
        return ['success' => true];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Registration failed. Try again later.'];
    }
}

function is_developer() {
    return is_logged_in() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'developer';
}

function is_author() {
    return is_logged_in() && isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['author', 'developer']);
}

function require_developer() {
    if (!is_developer()) {
        header("Location: " . SITE_URL . "/");
        exit;
    }
}

function require_author() {
    if (!is_author()) {
        header("Location: " . SITE_URL . "/");
        exit;
    }
}

function require_login() {
    if (!is_logged_in()) {
        redirect('/account/login.php');
    }
}

function require_admin() {
    if (!is_admin()) {
        redirect('/');
    }
}
