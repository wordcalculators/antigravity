<?php
// includes/header.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title . ' - ' . SITE_NAME) : SITE_NAME; ?></title>
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo isset($meta_description) ? htmlspecialchars($meta_description) : 'Free online file conversion tools for images, PDFs, and more.'; ?>">
    <meta name="robots" content="index, follow">

    <!-- OpenGraph Tags -->
    <meta property="og:title" content="<?php echo isset($page_title) ? htmlspecialchars($page_title) : SITE_NAME; ?>" />
    <meta property="og:description" content="<?php echo isset($meta_description) ? htmlspecialchars($meta_description) : 'Free online file conversion tools.'; ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo SITE_URL . $_SERVER['REQUEST_URI']; ?>" />

    <!-- Tailwind CSS (CDN for Shared Hosting Compatibility) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#4F46E5', // Indigo-600
                        secondary: '#10B981', // Emerald-500
                        dark: '#1F2937', // Gray-800
                        light: '#F3F4F6' // Gray-100
                    }
                }
            }
        }
    </script>

    <!-- Google Search Console Verification (Placeholder) -->
    <!-- <meta name="google-site-verification" content="YOUR_GSC_CODE_HERE" /> -->

    <!-- Google Analytics (Placeholder) -->
    <!--
    <script async src="https://www.googletagmanager.com/gtag/js?id=YOUR_GA_CODE_HERE"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'YOUR_GA_CODE_HERE');
    </script>
    -->

    <link rel="icon" type="image/png" href="<?php echo SITE_URL; ?>/assets/images/favicon.png">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">

    <!-- FontAwesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-gray-50 text-gray-800 font-sans flex flex-col min-h-screen">

    <!-- Header Navigation -->
    <header class="bg-white shadow-sm sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <!-- Logo -->
                <div class="flex-shrink-0 flex items-center">
                    <a href="<?php echo SITE_URL; ?>/" class="flex items-center gap-2 group">
                        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-indigo-800 text-white flex items-center justify-center font-black text-2xl shadow-lg group-hover:shadow-indigo-500/50 transition-all duration-300">
                            <?php echo strtoupper(substr(SITE_NAME, 0, 1)); ?>
                        </div>
                        <span class="font-black text-2xl text-dark tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-gray-900 to-gray-600"><?php echo SITE_NAME; ?></span>
                    </a>
                </div>

                <!-- Desktop Menu -->
                <nav class="hidden md:flex space-x-8">
                    <div class="relative group">
                        <button class="text-gray-600 hover:text-primary font-medium flex items-center gap-1">
                            Tools <i class="fa-solid fa-chevron-down text-xs"></i>
                        </button>
                        <!-- Dropdown -->
                        <div class="absolute left-0 mt-2 w-48 bg-white border border-gray-100 rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                            <a href="<?php echo SITE_URL; ?>/#image-tools" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-primary">Image Tools</a>
                            <a href="<?php echo SITE_URL; ?>/#pdf-tools" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-primary">PDF Tools</a>
                            <a href="<?php echo SITE_URL; ?>/#utility-tools" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-primary">Utility Tools</a>
                        </div>
                    </div>
                    <a href="<?php echo SITE_URL; ?>/blog" class="text-gray-600 hover:text-primary font-medium">Blog</a>
                    <a href="<?php echo SITE_URL; ?>/#pricing" class="text-gray-600 hover:text-primary font-medium text-amber-500"><i class="fa-solid fa-crown mr-1"></i>Premium</a>
                </nav>

                <!-- Search and Auth -->
                <div class="hidden md:flex items-center space-x-4">
                    <div class="relative">
                        <input type="text" id="global-search" placeholder="Search tools..." class="w-48 pl-8 pr-3 py-1.5 border border-gray-300 rounded-full text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary">
                        <i class="fa-solid fa-search absolute left-3 top-2.5 text-gray-400 text-xs"></i>
                    </div>

                    <?php if (is_logged_in()): ?>
                        <a href="<?php echo SITE_URL; ?>/account/dashboard.php" class="text-gray-600 hover:text-primary font-medium">Dashboard</a>
                        <?php if (is_developer()): ?>
                            <a href="<?php echo SITE_URL; ?>/admin/index.php" class="text-red-600 hover:text-red-800 font-medium whitespace-nowrap">Developer Panel</a>
                        <?php elseif (is_author()): ?>
                            <a href="<?php echo SITE_URL; ?>/author/index.php" class="text-indigo-600 hover:text-indigo-800 font-medium whitespace-nowrap">Author Panel</a>
                        <?php endif; ?>
                        
                        <div class="relative group ml-4">
                            <a href="<?php echo SITE_URL; ?>/account/dashboard.php">
                                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_name'] ?? 'U'); ?>&background=4F46E5&color=fff" class="w-10 h-10 rounded-full border-2 border-indigo-100 cursor-pointer">
                            </a>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo SITE_URL; ?>/account/login.php" class="text-gray-600 hover:text-primary font-medium">Log in</a>
                        <a href="<?php echo SITE_URL; ?>/account/register.php" class="bg-primary hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors">Sign up</a>
                    <?php endif; ?>
                </div>

                <!-- Mobile menu button -->
                <div class="flex items-center md:hidden">
                    <button id="mobile-menu-btn" class="text-gray-600 hover:text-gray-900 focus:outline-none">
                        <i class="fa-solid fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Menu (hidden by default) -->
        <div id="mobile-menu" class="hidden md:hidden bg-white border-t border-gray-100">
            <div class="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                <a href="<?php echo SITE_URL; ?>/#image-tools" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Image Tools</a>
                <a href="<?php echo SITE_URL; ?>/#pdf-tools" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">PDF Tools</a>
                <a href="<?php echo SITE_URL; ?>/blog" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Blog</a>
                <?php if (is_logged_in()): ?>
                    <a href="<?php echo SITE_URL; ?>/account/dashboard.php" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Dashboard</a>
                            <?php if(is_developer()): ?>
                            <a href="<?php echo SITE_URL; ?>/admin/index.php" class="block px-3 py-2 text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Developer Panel</a>
                            <?php elseif(is_author()): ?>
                            <a href="<?php echo SITE_URL; ?>/author/index.php" class="block px-3 py-2 text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Author Panel</a>
                            <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo SITE_URL; ?>/account/login.php" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-primary hover:bg-gray-50">Log in</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- Top Global Ad Slot (Non-Intrusive) -->
    <div class="w-full bg-gray-50 border-b border-gray-100 py-3 hidden md:flex justify-center">
        <div class="text-center">
            <!-- Replace with actual AdSense/Network Code later -->
            <div class="w-[728px] h-[90px] bg-gray-200 border border-gray-300 flex items-center justify-center rounded text-gray-400 font-medium text-sm">
                ADVERTISEMENT PLACEHOLDER (728x90)
            </div>
            <span class="text-[10px] text-gray-400 uppercase tracking-widest mt-1 block">Advertisement</span>
        </div>
    </div>

    <!-- Main Content Area -->
    <main class="flex-grow">
