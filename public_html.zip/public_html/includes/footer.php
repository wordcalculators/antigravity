    </main>

    <!-- Footer -->
    <footer class="bg-dark text-gray-300 mt-12 py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <!-- Branding -->
                <div class="col-span-1 md:col-span-1 border-r border-gray-700 pr-4">
                    <a href="<?php echo SITE_URL; ?>/" class="flex items-center gap-2 mb-4 group">
                        <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-indigo-800 text-white flex items-center justify-center font-black text-xl shadow-lg">
                            <?php echo strtoupper(substr(SITE_NAME, 0, 1)); ?>
                        </div>
                        <span class="font-bold text-xl text-white tracking-tight"><?php echo SITE_NAME; ?></span>
                    </a>
                    <p class="text-sm text-gray-400 mb-4">Fast, free, and secure online file conversion tools for everyone.</p>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-white transition-colors"><i class="fa-brands fa-twitter"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors"><i class="fa-brands fa-github"></i></a>
                    </div>
                </div>

                <!-- Tools Links -->
                <div>
                    <h3 class="text-sm font-semibold tracking-wider text-gray-400 uppercase mb-4">Popular Tools</h3>
                    <ul class="space-y-2 text-sm">
                        <li><a href="<?php echo SITE_URL; ?>/tools/images/png-to-jpg" class="hover:text-primary transition-colors">PNG to JPG</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/tools/images/image-compressor" class="hover:text-primary transition-colors">Image Compressor</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/tools/pdf/jpg-to-pdf" class="hover:text-primary transition-colors">JPG to PDF</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/tools/pdf/merge-pdf" class="hover:text-primary transition-colors">Merge PDF</a></li>
                    </ul>
                </div>

                <!-- Resources Links -->
                <div>
                    <h3 class="text-sm font-semibold tracking-wider text-gray-400 uppercase mb-4">Resources</h3>
                    <ul class="space-y-2 text-sm">
                        <li><a href="<?php echo SITE_URL; ?>/blog" class="hover:text-primary transition-colors">Blog & Articles</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/api/docs" class="hover:text-primary transition-colors">API Documentation</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/#pricing" class="hover:text-primary transition-colors">Premium Plans</a></li>
                    </ul>
                </div>

                <!-- Legal Links -->
                <div>
                    <h3 class="text-sm font-semibold tracking-wider text-gray-400 uppercase mb-4">Company</h3>
                    <ul class="space-y-2 text-sm">
                        <li><a href="<?php echo SITE_URL; ?>/legal/about.php" class="hover:text-primary transition-colors">About Us</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/legal/contact.php" class="hover:text-primary transition-colors">Contact</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/legal/privacy-policy.php" class="hover:text-primary transition-colors">Privacy Policy</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/legal/terms.php" class="hover:text-primary transition-colors">Terms of Service</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="border-t border-gray-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
                <p class="text-sm text-gray-400">
                    &copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.
                </p>
                <!-- Payment methods visual (mock) -->
                <div class="mt-4 md:mt-0 flex space-x-2 text-2xl text-gray-500">
                    <i class="fa-brands fa-cc-visa"></i>
                    <i class="fa-brands fa-cc-mastercard"></i>
                    <i class="fa-brands fa-cc-paypal"></i>
                </div>
            </div>
        </div>
    </footer>

    <!-- Global Scripts -->
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
