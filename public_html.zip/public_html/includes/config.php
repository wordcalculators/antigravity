<?php
// includes/config.php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'onlineconvert_db');

// Website config
define('SITE_URL', 'http://localhost/public_html');
define('SITE_NAME', 'OnlineConvert.co');

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
