<?php
// author/index.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
require_author();

$page_title = "Author Dashboard";

global $pdo;
$stmt = $pdo->prepare("SELECT * FROM posts WHERE author_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$posts = $stmt->fetchAll();

// Custom Layout for Dashboard Panels
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Author Dashboard - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#4F46E5', // Indigo-600
                        secondary: '#10B981', // Emerald-500
                        dark: '#1F2937', // Gray-800
                        light: '#F3F4F6' // Gray-100
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden text-sm">

    <!-- Sidebar -->
    <aside class="w-64 bg-slate-900 text-white flex flex-col hidden md:flex h-full">
        <div class="h-16 flex items-center px-6 border-b border-slate-800 relative">
            <a href="<?php echo SITE_URL; ?>" class="flex items-center gap-2 text-white">
                <div class="w-8 h-8 rounded bg-gradient-to-br from-primary to-indigo-800 text-white flex items-center justify-center font-black">
                    <?php echo strtoupper(substr(SITE_NAME, 0, 1)); ?>
                </div>
                <span class="font-bold text-lg tracking-tight"><?php echo SITE_NAME; ?></span>
            </a>
            <span class="absolute right-4 top-5 text-[10px] font-bold tracking-widest uppercase text-slate-400 bg-slate-800 px-2 py-0.5 rounded">Author</span>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-2">
            <a href="<?php echo SITE_URL; ?>/author/index.php" class="flex items-center gap-3 px-3 py-2 bg-indigo-600 text-white rounded-lg">
                <i class="fa-solid fa-pen-nib w-5 text-center"></i> Blog Posts
            </a>
            <a href="#" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors">
                <i class="fa-solid fa-chart-line w-5 text-center"></i> Post Analytics
            </a>
            <?php if(is_developer()): ?>
            <div class="pt-4 mt-4 border-t border-slate-800">
                <a href="<?php echo SITE_URL; ?>/admin/index.php" class="flex items-center gap-3 px-3 py-2 text-amber-500 hover:text-amber-400 rounded-lg transition-colors">
                    <i class="fa-solid fa-code w-5 text-center"></i> Dev Panel
                </a>
            </div>
            <?php endif; ?>
        </nav>
        <div class="p-4 border-t border-slate-800">
            <a href="<?php echo SITE_URL; ?>/account/logout.php" class="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-white transition-colors">
                <i class="fa-solid fa-sign-out-alt w-5 text-center"></i> Logout
            </a>
        </div>
    </aside>

    <main class="flex-1 flex flex-col overflow-y-auto">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8">
            <h1 class="text-xl font-semibold text-gray-800">Manage Content</h1>
            <div class="flex items-center gap-4 text-sm font-medium text-gray-600">
                <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_name']); ?>&background=4F46E5&color=fff" class="w-8 h-8 rounded-full">
            </div>
        </header>

        <div class="p-8">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-bold text-gray-900">Your Articles</h2>
                <a href="editor.php" class="bg-primary hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium shadow-sm flex items-center transition-colors">
                    <i class="fa-solid fa-plus mr-2"></i> Write New Post
                </a>>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <!-- Mock Table for Author Dashboard -->
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Title</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Category</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
                            <th class="px-6 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if(empty($posts)): ?>
                            <tr><td colspan="5" class="px-6 py-4 text-center text-gray-500">You haven't written any articles yet.</td></tr>
                        <?php else: ?>
                            <?php foreach($posts as $p): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900"><?php echo htmlspecialchars(strlen($p['title']) > 50 ? substr($p['title'],0,50).'...' : $p['title']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-gray-500 font-mono text-xs"><?php echo htmlspecialchars($p['slug']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php if($p['status'] === 'published'): ?>
                                        <span class="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800 font-medium tracking-wide uppercase">Published</span>
                                    <?php else: ?>
                                        <span class="px-2 py-1 text-xs rounded-full bg-amber-100 text-amber-800 font-medium tracking-wide uppercase">Draft</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-gray-400"><?php echo date('M j, Y', strtotime($p['created_at'])); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-right font-medium">
                                    <a href="editor.php?id=<?php echo $p['id']; ?>" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                                    <!-- Delete functionality can be added here or in editor -->
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-8 bg-blue-50 border-l-4 border-blue-500 p-4 text-blue-800 rounded-r-lg shadow-sm">
                <div class="flex">
                    <i class="fa-solid fa-circle-info text-xl mr-3 mt-0.5"></i>
                    <div>
                        <h4 class="font-bold">SEO Best Practices Reminder</h4>
                        <p class="mt-1 text-sm text-blue-700">Remember to include your focus keyword in the title, URL slug, and at least once in the first 100 words of your article body. Ensure your meta-descriptions are between 150-160 characters for optimal display in SERPs.</p>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
