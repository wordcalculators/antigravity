<?php
// author/editor.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
require_author();

global $pdo;
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$post = [
    'title' => '', 'slug' => '', 'meta_desc' => '', 
    'body' => '', 'status' => 'draft', 'featured_image' => ''
];
$error = '';
$success = '';

if ($id > 0) {
    if (is_developer()) {
        $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
        $stmt->execute([$id]);
    } else {
        $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ? AND author_id = ?");
        $stmt->execute([$id, $_SESSION['user_id']]);
    }
    $fetched = $stmt->fetch();
    if ($fetched) {
        $post = $fetched;
    } else {
        die("Post not found or access denied.");
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $post['title'] = trim($_POST['title'] ?? '');
    $post['slug'] = trim($_POST['slug'] ?? '');
    $post['meta_desc'] = trim($_POST['meta_desc'] ?? '');
    $post['body'] = $_POST['body'] ?? '';
    $post['status'] = $_POST['status'] ?? 'draft';
    $post['featured_image'] = trim($_POST['featured_image'] ?? '');
    
    // Auto-generate slug if empty
    if (empty($post['slug']) && !empty($post['title'])) {
        $post['slug'] = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $post['title'])));
    }

    if (empty($post['title']) || empty($post['slug'])) {
        $error = "Title and Slug are required.";
    } else {
        try {
            if ($id > 0) {
                $stmt = $pdo->prepare("UPDATE posts SET title=?, slug=?, meta_desc=?, body=?, featured_image=?, status=? WHERE id=?");
                $stmt->execute([
                    $post['title'], $post['slug'], $post['meta_desc'], 
                    $post['body'], $post['featured_image'], $post['status'], $id
                ]);
                $success = "Post updated successfully.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO posts (author_id, title, slug, meta_desc, body, featured_image, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $_SESSION['user_id'], $post['title'], $post['slug'], 
                    $post['meta_desc'], $post['body'], $post['featured_image'], $post['status']
                ]);
                $id = $pdo->lastInsertId();
                $success = "Post created successfully.";
            }
        } catch (PDOException $e) {
            $error = "Save failed: " . $e->getMessage() . " (Slug must be unique)";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $id > 0 ? 'Edit' : 'New'; ?> Post - Author</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden text-sm">
    <aside class="w-64 bg-slate-900 text-white flex flex-col hidden md:flex h-full">
        <div class="h-16 flex items-center px-6 border-b border-slate-800 relative">
            <span class="font-bold text-lg tracking-tight"><?php echo SITE_NAME; ?></span>
            <span class="absolute right-4 top-5 text-[10px] font-bold tracking-widest uppercase text-slate-400 bg-slate-800 px-2 py-0.5 rounded">Author</span>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-2">
            <a href="index.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg"><i class="fa-solid fa-pen-nib w-5"></i> Blog Posts</a>
        </nav>
    </aside>

    <main class="flex-1 flex flex-col overflow-y-auto w-full">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 shrink-0">
            <div class="flex items-center gap-4">
                <a href="index.php" class="text-gray-400 hover:text-gray-600"><i class="fa-solid fa-arrow-left"></i> Back</a>
                <h1 class="text-xl font-semibold text-gray-800"><?php echo $id > 0 ? 'Edit Article' : 'Write New Article'; ?></h1>
            </div>
        </header>

        <div class="p-8 max-w-5xl mx-auto w-full">
            <?php if($error): ?><div class="bg-red-50 text-red-600 p-4 rounded mb-6 font-medium"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
            <?php if($success): ?><div class="bg-green-50 text-green-700 p-4 rounded mb-6 font-medium"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

            <form method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="md:col-span-2 space-y-6">
                    <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                        <label class="block text-sm font-semibold text-gray-700 mb-1">Article Title *</label>
                        <input type="text" name="title" value="<?php echo htmlspecialchars($post['title']); ?>" class="w-full border border-gray-300 rounded px-3 py-2 text-lg font-bold text-gray-900 focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Catchy Headline Here..." required>
                        
                        <div class="mt-4">
                            <label class="block text-sm font-semibold text-gray-700 mb-1">Body Content (HTML/Markdown support)</label>
                            <!-- In a production app, use TinyMCE or similar here -->
                            <textarea name="body" rows="16" class="w-full border border-gray-300 rounded px-3 py-2 text-gray-800 font-mono text-sm focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="<p>Start writing your article HTML</p>"><?php echo htmlspecialchars($post['body']); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="space-y-6">
                    <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 space-y-4">
                        <h3 class="font-bold text-gray-800 border-b pb-2">Publish Settings</h3>
                        
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Status</label>
                            <select name="status" class="w-full border border-gray-300 rounded px-3 py-2 text-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none">
                                <option value="draft" <?php echo $post['status'] === 'draft' ? 'selected' : ''; ?>>Draft</option>
                                <option value="published" <?php echo $post['status'] === 'published' ? 'selected' : ''; ?>>Published</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">URL Slug</label>
                            <input type="text" name="slug" value="<?php echo htmlspecialchars($post['slug']); ?>" class="w-full border border-gray-300 rounded px-3 py-2 text-xs font-mono text-gray-600 focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="auto-generated-if-blank">
                        </div>
                        
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Featured Image URL</label>
                            <input type="text" name="featured_image" value="<?php echo htmlspecialchars($post['featured_image']); ?>" class="w-full border border-gray-300 rounded px-3 py-2 text-sm text-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="https://...">
                        </div>
                        
                        <div>
                            <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Meta Description</label>
                            <textarea name="meta_desc" rows="3" class="w-full border border-gray-300 rounded px-3 py-2 text-sm text-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Brief SEO description..."><?php echo htmlspecialchars($post['meta_desc']); ?></textarea>
                            <p class="text-[10px] text-gray-400 mt-1 text-right">Max 160 characters</p>
                        </div>

                        <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg shadow-md transition-colors">
                            <i class="fa-solid fa-cloud-arrow-up mr-2"></i> Save Post
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
</body>
</html>
