<?php
// tools/audio/audio-cutter.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Online Audio Cutter - Trim MP3, WAV, OGG";
$meta_description = "Cut or trim your audio files online for free. Precise waveform editor for ringtones or clips.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Audio Cutter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Visually trim and cut your audio files directly in the browser. Perfect for ringtones.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200 p-6 md:p-10 text-center">
            
            <div id="upload-state" class="border-2 border-dashed border-pink-300 rounded-xl p-12 hover:bg-pink-50 transition cursor-pointer flex flex-col items-center justify-center min-h-[300px]" onclick="document.getElementById('file-input').click()">
                <i class="fa-solid fa-scissors text-6xl text-pink-400 mb-6 drop-shadow-sm"></i>
                <h3 class="text-2xl font-bold text-gray-800 mb-2">Upload Audio File</h3>
                <p class="text-gray-500 mb-6 font-medium">MP3, WAV, OGG, AAC (Max 50MB)</p>
                <button class="bg-pink-600 hover:bg-pink-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition transform hover:-translate-y-0.5" type="button">
                    Choose File
                </button>
            </div>

            <!-- Editor UI (Mock) -->
            <div id="editor-state" class="hidden">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="font-bold text-gray-800 text-lg" id="track-name">audio_track.mp3</h3>
                    <div class="text-sm font-medium text-pink-600 bg-pink-100 px-3 py-1 rounded-full">
                        Duration: 00:03:45
                    </div>
                </div>

                <!-- Fake Waveform -->
                <div class="relative w-full h-40 bg-gray-900 rounded-lg overflow-hidden mb-8 border border-gray-300 flex items-center justify-center">
                    <!-- Just a visual mockup of a waveform using repeating bars -->
                    <div class="flex items-end justify-between w-full px-2 h-32 gap-[2px] opacity-70" id="waveform-mock">
                        <?php for($i=0; $i<80; $i++): array_push($heights, rand(10, 100)); ?><?php endfor; ?>
                    </div>
                    <!-- Selection Overlay -->
                    <div class="absolute top-0 bottom-0 left-[20%] right-[30%] bg-pink-500/30 border-l-4 border-r-4 border-pink-500 cursor-ew-resize">
                        <div class="absolute -top-3 -left-3 w-6 h-6 bg-white border-2 border-pink-500 rounded-full shadow-sm cursor-grab"></div>
                        <div class="absolute -top-3 -right-3 w-6 h-6 bg-white border-2 border-pink-500 rounded-full shadow-sm cursor-grab"></div>
                        <div class="absolute bottom-2 left-2 text-white font-mono text-xs font-bold drop-shadow">00:00:45</div>
                        <div class="absolute bottom-2 right-2 text-white font-mono text-xs font-bold drop-shadow">00:02:15</div>
                    </div>
                </div>

                <div class="flex flex-wrap items-center justify-between gap-6">
                    <!-- Controls -->
                    <div class="flex gap-4">
                        <button class="w-12 h-12 rounded-full bg-gray-200 hover:bg-gray-300 text-gray-800 flex items-center justify-center transition focus:outline-none">
                            <i class="fa-solid fa-play ml-1"></i>
                        </button>
                        <div class="flex flex-col text-left">
                            <label class="text-xs font-bold text-gray-500 uppercase">Fade In</label>
                            <select class="form-select w-24 rounded border-gray-300 py-1 text-sm bg-gray-50">
                                <option>Off</option>
                                <option>1s</option>
                                <option>2s</option>
                            </select>
                        </div>
                        <div class="flex flex-col text-left">
                            <label class="text-xs font-bold text-gray-500 uppercase">Fade Out</label>
                            <select class="form-select w-24 rounded border-gray-300 py-1 text-sm bg-gray-50">
                                <option>Off</option>
                                <option selected>2s</option>
                                <option>3s</option>
                            </select>
                        </div>
                    </div>

                    <div class="flex gap-4">
                        <button class="text-gray-500 hover:text-gray-800 font-bold px-4" onclick="document.location.reload()">Cancel</button>
                        <button class="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition" onclick="cutAudio()">
                            <i class="fa-solid fa-scissors mr-2"></i> Cut & Download
                        </button>
                    </div>
                </div>
            </div>

            <input type="file" id="file-input" class="hidden" accept="audio/*">
        </div>
        
    </div>
</div>

<script>
    // Generate random waveform bars (JS instead of PHP because PHP random runs once on server)
    const waveContainer = document.getElementById('waveform-mock');
    let bars = '';
    for(let i=0; i<120; i++) {
        let h = Math.floor(Math.random() * 90) + 10;
        bars += `<div class="w-2 bg-green-400 rounded-t-sm" style="height: ${h}%"></div>`;
    }
    waveContainer.innerHTML = bars;

    const fileInput = document.getElementById('file-input');
    const stateUpload = document.getElementById('upload-state');
    const stateEditor = document.getElementById('editor-state');
    const trackName = document.getElementById('track-name');

    fileInput.addEventListener('change', function() {
        if(this.files.length) {
            let file = this.files[0];
            if(!file.type.match('audio.*')) {
                alert('Please select an audio file.');
                return;
            }
            trackName.textContent = file.name;
            stateUpload.classList.add('hidden');
            stateEditor.classList.remove('hidden');
        }
    });

    function cutAudio() {
        const btn = document.activeElement;
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Processing...';
        btn.disabled = true;

        setTimeout(() => {
            alert('UI Mockup: In a real app, this would send trim start/end timestamps to FFmpeg on the server, then prompt a download.');
            btn.innerHTML = '<i class="fa-solid fa-check mr-2"></i> Done';
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.disabled = false;
            }, 2000);
        }, 1500);
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
