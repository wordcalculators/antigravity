<?php
// tools/audio/mp3-converter.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Online MP3 Converter - Audio Formats";
$meta_description = "Convert audio files to and from MP3 online. Supports WAV, OGG, M4A, AAC, FLAC securely.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">MP3 Audio Converter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Convert WAV, OGG, FLAC, AAC, or M4A to high-quality MP3 securely in your browser.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
            
            <div class="p-8 pb-4">
                <div class="border-2 border-dashed border-teal-300 rounded-xl p-12 text-center hover:bg-teal-50 transition cursor-pointer flex flex-col items-center justify-center min-h-[300px]" id="drop-zone" onclick="document.getElementById('file-input').click()">
                    
                    <div id="upload-state">
                        <i class="fa-solid fa-file-audio text-6xl text-teal-400 mb-6 drop-shadow-sm"></i>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">Select Audio File</h3>
                        <p class="text-gray-500 mb-6 font-medium">Any Audio format to MP3 (Max 100MB)</p>
                        <button class="bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition transform hover:-translate-y-0.5" type="button">
                            Upload Audio
                        </button>
                    </div>

                    <div id="processing-state" class="hidden w-full max-w-md">
                        <i class="fa-solid fa-headphones fa-flip text-5xl text-teal-500 mb-4"></i>
                        <h3 class="text-xl font-bold text-gray-800 mb-2">Encoding Audio...</h3>
                        <div class="w-full bg-gray-200 rounded-full h-2.5 mt-4 mb-2">
                            <div class="bg-teal-600 h-2.5 rounded-full transition-all duration-300" id="progress-bar" style="width: 0%"></div>
                        </div>
                        <p class="text-sm font-bold text-teal-600" id="progress-text">0%</p>
                    </div>

                    <div id="success-state" class="hidden w-full">
                        <i class="fa-solid fa-circle-check text-6xl text-green-500 mb-4"></i>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">Converted Successfully!</h3>
                        <p class="text-gray-500 mb-6 font-mono" id="filename-display">track.mp3</p>
                        <div class="flex gap-4 justify-center">
                            <button class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition" onclick="downloadMock()">
                                <i class="fa-solid fa-download mr-2"></i> Download MP3
                            </button>
                            <button class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-8 rounded-full transition" onclick="resetUI()">
                                Convert Another
                            </button>
                        </div>
                    </div>

                    <input type="file" id="file-input" class="hidden" accept="audio/*">
                </div>
            </div>

            <!-- Settings -->
            <div class="bg-gray-50 border-t border-gray-200 p-6 flex justify-center gap-8 text-sm font-medium text-gray-600">
                <div class="flex items-center">
                    <label class="mr-2">Quality:</label>
                    <select class="form-select text-sm py-1 pl-2 pr-8 rounded border-gray-300">
                        <option>320 kbps (High)</option>
                        <option selected>192 kbps (Standard)</option>
                        <option>128 kbps (Economy)</option>
                    </select>
                </div>
                <div class="flex items-center">
                    <label class="mr-2">Channels:</label>
                    <select class="form-select text-sm py-1 pl-2 pr-8 rounded border-gray-300">
                        <option selected>Stereo</option>
                        <option>Mono</option>
                    </select>
                </div>
            </div>

        </div>
        
    </div>
</div>

<script>
    const fileInput = document.getElementById('file-input');
    const dropZone = document.getElementById('drop-zone');
    
    const stateUpload = document.getElementById('upload-state');
    const stateProcessing = document.getElementById('processing-state');
    const stateSuccess = document.getElementById('success-state');
    
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');
    const filenameDisplay = document.getElementById('filename-display');

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('border-teal-600', 'bg-teal-50');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('border-teal-600', 'bg-teal-50');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('border-teal-600', 'bg-teal-50');
        if(e.dataTransfer.files.length) {
            handleFile(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener('change', function() {
        if(this.files.length) {
            handleFile(this.files[0]);
        }
    });

    function handleFile(file) {
        if(!file.type.match('audio.*')) {
            alert('Please select a valid audio file.');
            return;
        }

        stateUpload.classList.add('hidden');
        stateProcessing.classList.remove('hidden');
        
        let originalName = file.name.split('.').slice(0, -1).join('.');
        filenameDisplay.textContent = originalName + '.mp3';

        let prog = 0;
        const interval = setInterval(() => {
            prog += Math.random() * 20;
            if(prog > 100) prog = 100;
            
            progressBar.style.width = prog + '%';
            progressText.textContent = Math.round(prog) + '%';
            
            if(prog === 100) {
                clearInterval(interval);
                setTimeout(() => {
                    stateProcessing.classList.add('hidden');
                    stateSuccess.classList.remove('hidden');
                }, 400);
            }
        }, 200);
    }

    function downloadMock() {
        alert("UI Demo. Download processed audio.");
    }

    function resetUI() {
        stateSuccess.classList.add('hidden');
        stateUpload.classList.remove('hidden');
        progressBar.style.width = '0%';
        progressText.textContent = '0%';
        fileInput.value = '';
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
