<?php
// tools/pdf/word-to-pdf.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Convert Word to PDF Online";
$meta_description = "Convert DOC and DOCX files to PDF easily. Create universally accessible documents with our free converter.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4" itemprop="name">Word to PDF</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto" itemprop="description">
                Make DOC and DOCX files easy to read by converting them to PDF.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden mb-12 border border-blue-100 p-8">
            <div id="drop-zone" class="border-2 border-dashed border-blue-300 rounded-xl p-12 text-center hover:bg-blue-50 transition-colors cursor-pointer relative group">
                <input type="file" id="file-input" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept=".doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" aria-label="Upload Word Document">
                <div class="text-blue-600 mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <i class="fa-solid fa-file-word text-6xl drop-shadow-sm"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Drop your Word file here</h3>
                <p class="text-gray-500 mb-6">or click to browse from your device</p>
                <div class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700">
                    Select DOC or DOCX
                </div>
            </div>

            <div id="settings-area" class="hidden mt-8 border-t border-gray-100 pt-8 max-w-md mx-auto text-center">
                <p id="file-name" class="font-semibold text-gray-700 mb-6"></p>

                <button id="process-btn" class="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg transform transition-all hover:scale-[1.02] flex items-center justify-center text-lg">
                    <span>Convert to PDF</span>
                    <i class="fa-solid fa-arrow-right-arrow-left ml-3"></i>
                </button>
            </div>
            
            <div id="loading-area" class="hidden mt-8 pt-8 border-t border-gray-100 text-center">
                <i class="fa-solid fa-spinner fa-spin text-4xl text-blue-500 mb-4"></i>
                <p class="text-gray-600 font-medium">Generating standard PDF...</p>
                <p class="text-xs text-gray-400 mt-2">Server processor running LibreOffice headless conversion</p>
            </div>

            <div id="result-area" class="hidden mt-8 pt-8 border-t border-gray-100 text-center">
                <div class="w-16 h-16 bg-red-100 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl"><i class="fa-solid fa-file-pdf"></i></div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Conversion Successful!</h3>
                <p class="text-gray-600 mb-6">Your universal PDF document is ready.</p>
                <a href="#" class="inline-flex items-center px-8 py-3 border border-transparent text-lg font-bold rounded-xl shadow-md text-white bg-red-600 hover:bg-red-700">
                    Download PDF <i class="fa-solid fa-download ml-2"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<script>
    const fileInput = document.getElementById('file-input');
    const settingsArea = document.getElementById('settings-area');
    const fileNameDisplay = document.getElementById('file-name');
    const processBtn = document.getElementById('process-btn');
    const loadingArea = document.getElementById('loading-area');
    const resultArea = document.getElementById('result-area');

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        fileNameDisplay.textContent = file.name;
        settingsArea.classList.remove('hidden');
        resultArea.classList.add('hidden');
    });

    processBtn.addEventListener('click', () => {
        settingsArea.classList.add('hidden');
        loadingArea.classList.remove('hidden');
        setTimeout(() => {
            loadingArea.classList.add('hidden');
            resultArea.classList.remove('hidden');
        }, 2200);
    });
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
