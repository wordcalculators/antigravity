<?php
// tools/merge-pdf.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Merge PDFs Online";
$meta_description = "Combine multiple PDFs into one unified document rapidly and securely.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-10">
            <h1 class="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight"><span class="text-orange-500">Merge</span> PDF</h1>
            <p class="text-xl text-gray-600">Combine multiple PDFs into a single, unified document.</p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 mb-16">
            <!-- Reuse standard backend tool layout from jpg-to-pdf -->
            <form id="upload-form" class="drop-zone cursor-pointer rounded-xl flex flex-col items-center justify-center py-20 px-4 text-center">
                <div class="w-20 h-20 bg-orange-50 text-orange-500 rounded-full flex items-center justify-center text-4xl mb-4 shadow-inner">
                    <i class="fa-solid fa-layer-group"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Select PDF Files</h3>
                <p class="text-gray-500 mb-6">Drag and drop here to merge</p>
                <input type="file" id="file-input" name="file" class="hidden" accept="application/pdf" multiple>
                <input type="hidden" name="tool" value="Merge PDF">
                <button type="button" onclick="document.getElementById('file-input').click()" class="bg-primary text-white font-bold py-3 px-8 rounded-lg hover:bg-indigo-700 transition">Browse Files</button>
            </form>

            <div id="processing-view" class="hidden text-center py-16">
                <div class="loader mx-auto border-t-orange-500 w-12 h-12 mb-4"></div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Merging Documents...</h3>
            </div>

            <div id="result-view" class="hidden text-center py-16 bg-green-50 rounded-xl border border-green-100">
                <div class="w-20 h-20 bg-green-100 text-green-500 rounded-full flex mx-auto items-center justify-center text-4xl mb-4 shadow-inner">
                    <i class="fa-solid fa-check"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-4">PDFs Merged Successfully!</h3>
                <a id="download-link" href="#" download="merged_document.pdf" class="inline-flex items-center px-6 py-3 shadow-sm text-lg font-medium rounded-md text-white bg-green-600 hover:bg-green-700">
                    <i class="fa-solid fa-download mr-2"></i> Download File
                </a>
                <div class="mt-6">
                    <button onclick="location.reload()" class="text-sm text-gray-600 hover:text-gray-900 underline">Merge More</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// We map over the same processing function logic from jpg-to-pdf
document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('file-input');
    const form = document.getElementById('upload-form');
    
    fileInput.addEventListener('change', async (e) => {
        if (!e.target.files.length) return;
        form.classList.add('hidden');
        document.getElementById('processing-view').classList.remove('hidden');

        const formData = new FormData();
        formData.append('file', e.target.files[0]);
        formData.append('tool', 'Merge PDF');

        try {
            const res = await fetch('<?php echo SITE_URL; ?>/api/convert.php', { method: 'POST', body: formData });
            const data = await res.json();
            
            if (data.success) {
                document.getElementById('processing-view').classList.add('hidden');
                document.getElementById('result-view').classList.remove('hidden');
                if(data.download_url) document.getElementById('download-link').href = data.download_url;
            } else throw new Error(data.message);
        } catch (err) {
            alert('Failed: ' + err.message);
            location.reload();
        }
    });

    // Handle Drag Drop
    form.addEventListener('dragover', e => e.preventDefault());
    form.addEventListener('drop', e => { e.preventDefault(); fileInput.files = e.dataTransfer.files; fileInput.dispatchEvent(new Event('change')); });
});
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
