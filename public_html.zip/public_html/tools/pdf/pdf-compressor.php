<?php
// tools/pdf/pdf-compressor.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Compress PDF Online";
$meta_description = "Reduce PDF file size quickly and securely. Free online PDF compressor.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4" itemprop="name">Compress PDF</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto" itemprop="description">
                Reduce the file size of your PDF documents while maintaining quality.
            </p>
        </div>

        <div class="w-full bg-gray-200 flex items-center justify-center h-24 mb-8 rounded text-gray-400 text-sm ad-slot">
            Advertisement - 728x90
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden mb-12 border border-red-100 p-8">
            <div id="drop-zone" class="border-2 border-dashed border-red-300 rounded-xl p-12 text-center hover:bg-red-50 transition-colors cursor-pointer relative group">
                <input type="file" id="file-input" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="application/pdf" aria-label="Upload PDF">
                <div class="text-red-500 mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <i class="fa-solid fa-file-arrow-down text-6xl drop-shadow-sm"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Drop your PDF here</h3>
                <p class="text-gray-500 mb-6">or click to browse from your device</p>
                <div class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                    Select PDF File
                </div>
            </div>

            <div id="settings-area" class="hidden mt-8 border-t border-gray-100 pt-8 max-w-md mx-auto text-center">
                <p id="file-name" class="font-semibold text-gray-700 mb-2"></p>
                <p id="file-size" class="text-sm text-gray-500 mb-6"></p>

                <h3 class="text-lg font-bold text-gray-800 mb-4">Compression Level</h3>
                <div class="flex items-center justify-center gap-4 mb-6">
                    <select id="compression-level" class="form-select w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 px-3 py-2 border">
                        <option value="recommended">Recommended (Good balance)</option>
                        <option value="extreme">Extreme (Low quality, smallest size)</option>
                        <option value="low">Less Compression (High quality)</option>
                    </select>
                </div>

                <button id="process-btn" class="w-full bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-700 hover:to-orange-600 text-white font-bold py-4 px-8 rounded-xl shadow-lg transform transition-all hover:scale-[1.02] flex items-center justify-center text-lg">
                    <span>Compress PDF</span>
                    <i class="fa-solid fa-compress ml-3"></i>
                </button>
            </div>
            
            <div id="loading-area" class="hidden mt-8 pt-8 border-t border-gray-100 text-center">
                <i class="fa-solid fa-spinner fa-spin text-4xl text-red-500 mb-4"></i>
                <p class="text-gray-600 font-medium tracking-wide">Compressing document on server...</p>
                <p class="text-xs text-gray-400 mt-2">This may take a moment depending on file size.</p>
            </div>

            <div id="result-area" class="hidden mt-8 pt-8 border-t border-gray-100 text-center">
                <div class="w-16 h-16 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                    <i class="fa-solid fa-check"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Compression Complete!</h3>
                <p class="text-gray-600 mb-6">Your file was reduced by <span class="font-bold text-green-600">45%</span>.</p>
                
                <a href="#" id="download-link" class="inline-flex items-center px-8 py-3 border border-transparent text-lg font-bold rounded-xl shadow-md text-white bg-green-600 hover:bg-green-700 transition">
                    Download Compressed PDF <i class="fa-solid fa-download ml-2"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<script>
    const fileInput = document.getElementById('file-input');
    const settingsArea = document.getElementById('settings-area');
    const fileNameDisplay = document.getElementById('file-name');
    const fileSizeDisplay = document.getElementById('file-size');
    const processBtn = document.getElementById('process-btn');
    const loadingArea = document.getElementById('loading-area');
    const resultArea = document.getElementById('result-area');

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file || file.type !== 'application/pdf') {
            alert('Please select a valid PDF file');
            return;
        }
        
        fileNameDisplay.textContent = file.name;
        fileSizeDisplay.textContent = 'Original Size: ' + (file.size / 1024 / 1024).toFixed(2) + ' MB';
        
        settingsArea.classList.remove('hidden');
        resultArea.classList.add('hidden');
    });

    processBtn.addEventListener('click', () => {
        settingsArea.classList.add('hidden');
        loadingArea.classList.remove('hidden');
        
        // Mock server processing delay
        setTimeout(() => {
            loadingArea.classList.add('hidden');
            resultArea.classList.remove('hidden');
        }, 2500);
    });
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
