<?php
// tools/pdf/pdf-to-word.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Convert PDF to Word Online";
$meta_description = "Convert your PDF files to editable Word Documents (.docx) accurately using smart OCR and text extraction.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4" itemprop="name">PDF to Word</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto" itemprop="description">
                Convert a PDF to an editable Word document flawlessly. Keeps formatting, tables, and images intact.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden mb-12 border border-blue-100 p-8">
            <div id="drop-zone" class="border-2 border-dashed border-blue-300 rounded-xl p-12 text-center hover:bg-blue-50 transition-colors cursor-pointer relative group">
                <input type="file" id="file-input" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="application/pdf" aria-label="Upload PDF">
                <div class="text-blue-500 mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <i class="fa-solid fa-file-word text-6xl drop-shadow-sm"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Drop your PDF here</h3>
                <p class="text-gray-500 mb-6">or click to browse from your device</p>
                <div class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700">
                    Select PDF File
                </div>
            </div>

            <div id="settings-area" class="hidden mt-8 border-t border-gray-100 pt-8 max-w-md mx-auto text-center">
                <p id="file-name" class="font-semibold text-gray-700 mb-6"></p>

                <div class="bg-blue-50 p-4 border border-blue-200 rounded-lg text-sm text-blue-800 mb-6 text-left">
                    <i class="fa-solid fa-wand-magic-sparkles mr-2"></i> Our AI-powered converter will attempt to recreate text, tables, and layouts accurately into DOCX format.
                </div>

                <button id="process-btn" class="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg transform transition-all hover:scale-[1.02] flex items-center justify-center text-lg">
                    <span>Convert to Word (.docx)</span>
                    <i class="fa-solid fa-arrow-right-arrow-left ml-3"></i>
                </button>
            </div>
            
            <div id="loading-area" class="hidden mt-8 pt-8 border-t border-gray-100 text-center">
                <i class="fa-solid fa-spinner fa-spin text-4xl text-blue-500 mb-4"></i>
                <p class="text-gray-600 font-medium">Extracting text & layouts...</p>
                <p class="text-xs text-gray-400 mt-2">Server processor running LibreOffice conversion</p>
            </div>

            <div id="result-area" class="hidden mt-8 pt-8 border-t border-gray-100 text-center">
                <div class="w-16 h-16 bg-blue-100 text-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl"><i class="fa-solid fa-file-word"></i></div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Conversion Successful!</h3>
                <p class="text-gray-600 mb-6">Your editable Word document is ready.</p>
                <a href="#" class="inline-flex items-center px-8 py-3 border border-transparent text-lg font-bold rounded-xl shadow-md text-white bg-blue-600 hover:bg-blue-700">
                    Download Word (.docx) <i class="fa-solid fa-download ml-2"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<script>
    const fileInput = document.getElementById('file-input');
    const settingsArea = document.getElementById('settings-area');
    const fileNameDisplay = document.getElementById('file-name');
    const processBtn = document.getElementById('process-btn');
    const loadingArea = document.getElementById('loading-area');
    const resultArea = document.getElementById('result-area');

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        fileNameDisplay.textContent = file.name;
        settingsArea.classList.remove('hidden');
        resultArea.classList.add('hidden');
    });

    processBtn.addEventListener('click', () => {
        settingsArea.classList.add('hidden');
        loadingArea.classList.remove('hidden');
        setTimeout(() => {
            loadingArea.classList.add('hidden');
            resultArea.classList.remove('hidden');
        }, 3000); // simulate server time for DOCX generation mock
    });
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
