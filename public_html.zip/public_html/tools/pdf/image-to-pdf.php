<?php
// tools/pdf/image-to-pdf.php
// Wrapper that acts similarly to jpg-to-pdf but heavily advertised for all formats.
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Convert Image to PDF Online";
$meta_description = "Convert JPG, PNG, WEBP, and TIFF images into a single PDF document. Secure and fast online converter.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4" itemprop="name">Image to PDF</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto" itemprop="description">
                Merge one or multiple images into a concise PDF document. completely free and secure.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden mb-12 border border-red-100 p-8">
            <div id="drop-zone" class="border-2 border-dashed border-red-300 rounded-xl p-12 text-center hover:bg-red-50 transition-colors cursor-pointer relative group">
                <input type="file" id="file-input" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="image/*" multiple aria-label="Upload Images">
                <div class="text-red-500 mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <i class="fa-solid fa-file-pdf text-6xl drop-shadow-sm"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Drop your images here</h3>
                <p class="text-gray-500 mb-6">or click to browse from your device</p>
                <div class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700">
                    Select Images
                </div>
            </div>

            <div id="preview-list" class="hidden mt-8 grid grid-cols-2 md:grid-cols-4 gap-4"></div>

            <div id="settings-area" class="hidden mt-8 border-t border-gray-100 pt-8 max-w-md mx-auto text-center">
                <button id="process-btn" class="w-full bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg transform transition-all hover:scale-[1.02] flex items-center justify-center text-lg">
                    <span>Create PDF</span>
                    <i class="fa-solid fa-wand-magic-sparkles ml-3"></i>
                </button>
            </div>
            
            <div id="loading-area" class="hidden mt-8 pt-8 border-t border-gray-100 text-center">
                <i class="fa-solid fa-spinner fa-spin text-4xl text-red-500 mb-4"></i>
                <p class="text-gray-600 font-medium">Generating PDF Client-side...</p>
            </div>

            <div id="result-area" class="hidden mt-8 pt-8 border-t border-gray-100 text-center">
                <div class="w-16 h-16 bg-red-100 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl"><i class="fa-solid fa-check"></i></div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Done!</h3>
                <p class="text-gray-600 mb-6">Your universal PDF document is ready to download.</p>
                <a id="download-btn" href="#" download="images_combined.pdf" class="inline-flex items-center px-8 py-3 border border-transparent text-lg font-bold rounded-xl shadow-md text-white bg-red-600 hover:bg-red-700">
                    Download PDF <i class="fa-solid fa-download ml-2"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Included jsPDF for client side generation -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script>
    const fileInput = document.getElementById('file-input');
    const previewList = document.getElementById('preview-list');
    const settingsArea = document.getElementById('settings-area');
    const processBtn = document.getElementById('process-btn');
    const loadingArea = document.getElementById('loading-area');
    const resultArea = document.getElementById('result-area');
    const downloadBtn = document.getElementById('download-btn');
    
    let images = [];

    fileInput.addEventListener('change', (e) => {
        const files = Array.from(e.target.files);
        if (files.length === 0) return;
        
        previewList.innerHTML = '';
        images = [];
        
        files.forEach((file) => {
            const reader = new FileReader();
            reader.onload = (event) => {
                images.push(event.target.result);
                
                const img = document.createElement('img');
                img.src = event.target.result;
                img.className = 'w-full h-32 object-cover rounded-lg border border-gray-200 shadow-sm';
                previewList.appendChild(img);
            };
            reader.readAsDataURL(file);
        });
        
        previewList.classList.remove('hidden');
        settingsArea.classList.remove('hidden');
        resultArea.classList.add('hidden');
    });

    processBtn.addEventListener('click', () => {
        settingsArea.classList.add('hidden');
        loadingArea.classList.remove('hidden');
        
        setTimeout(() => {
            try {
                const { jsPDF } = window.jspdf;
                const pdf = new jsPDF();
                
                images.forEach((imgData, index) => {
                    if (index > 0) pdf.addPage();
                    const imgProps = pdf.getImageProperties(imgData);
                    const pdfWidth = pdf.internal.pageSize.getWidth();
                    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
                    
                    pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
                });
                
                const pdfData = pdf.output('bloburl');
                downloadBtn.href = pdfData;
                
                loadingArea.classList.add('hidden');
                resultArea.classList.remove('hidden');
            } catch (err) {
                alert("Error generating PDF: " + err.message);
                loadingArea.classList.add('hidden');
                settingsArea.classList.remove('hidden');
            }
        }, 800);
    });
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
