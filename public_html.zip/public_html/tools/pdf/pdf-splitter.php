<?php
// tools/pdf/pdf-splitter.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Split PDF Online";
$meta_description = "Extract pages, split PDF documents, or cut a PDF into multiple files. Unbelievably easy to use.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4" itemprop="name">Split PDF</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto" itemprop="description">
                Extract pages from your PDF or split it into multiple smaller documents easily.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden mb-12 border border-red-100 p-8">
            <div id="drop-zone" class="border-2 border-dashed border-red-300 rounded-xl p-12 text-center hover:bg-red-50 transition-colors cursor-pointer relative group">
                <input type="file" id="file-input" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="application/pdf" aria-label="Upload PDF">
                <div class="text-red-500 mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <i class="fa-solid fa-scissors text-6xl drop-shadow-sm"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Drop your PDF here to split</h3>
                <p class="text-gray-500 mb-6">or click to browse from your device</p>
                <div class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700">
                    Select PDF File
                </div>
            </div>

            <div id="settings-area" class="hidden mt-8 border-t border-gray-100 pt-8 max-w-md mx-auto text-center">
                <p id="file-name" class="font-semibold text-gray-700 mb-6"></p>

                <h3 class="text-lg font-bold text-gray-800 mb-4">How do you want to split it?</h3>
                
                <div class="space-y-4 mb-6 text-left">
                    <label class="flex items-start">
                        <input type="radio" name="split_mode" value="all" class="mt-1 text-red-600 focus:ring-red-500" checked>
                        <span class="ml-2">
                            <span class="block font-semibold text-gray-800">Extract all pages</span>
                            <span class="block text-sm text-gray-500">Every page becomes its own PDF file</span>
                        </span>
                    </label>
                    <label class="flex items-start">
                        <input type="radio" name="split_mode" value="range" class="mt-1 text-red-600 focus:ring-red-500">
                        <span class="ml-2">
                            <span class="block font-semibold text-gray-800">Custom Ranges</span>
                            <span class="block text-sm text-gray-500 mb-2">Extract specific pages (e.g. 1-5, 8, 11-13)</span>
                            <input type="text" id="custom-range-input" class="form-input w-full rounded-md border-gray-300 shadow-sm px-3 py-2 border placeholder-gray-400" placeholder="1-5, 8, 11-13" disabled>
                        </span>
                    </label>
                </div>

                <button id="process-btn" class="w-full bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg transform transition-all hover:scale-[1.02] flex items-center justify-center text-lg">
                    <span>Split PDF</span>
                    <i class="fa-solid fa-cut ml-3"></i>
                </button>
            </div>
            
            <div id="loading-area" class="hidden mt-8 pt-8 border-t border-gray-100 text-center">
                <i class="fa-solid fa-spinner fa-spin text-4xl text-red-500 mb-4"></i>
                <p class="text-gray-600 font-medium">Splitting document...</p>
            </div>

            <div id="result-area" class="hidden mt-8 pt-8 border-t border-gray-100 text-center">
                <div class="w-16 h-16 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl"><i class="fa-solid fa-check"></i></div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Split Complete!</h3>
                <p class="text-gray-600 mb-6">Your PDF was successfully split into a ZIP archive.</p>
                <a href="#" class="inline-flex items-center px-8 py-3 border border-transparent text-lg font-bold rounded-xl shadow-md text-white bg-green-600 hover:bg-green-700">
                    Download ZIP <i class="fa-solid fa-file-zipper ml-2"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<script>
    const fileInput = document.getElementById('file-input');
    const settingsArea = document.getElementById('settings-area');
    const fileNameDisplay = document.getElementById('file-name');
    const processBtn = document.getElementById('process-btn');
    const loadingArea = document.getElementById('loading-area');
    const resultArea = document.getElementById('result-area');
    
    // Handle Radio toggle
    const radios = document.querySelectorAll('input[name="split_mode"]');
    const customRangeInput = document.getElementById('custom-range-input');
    
    radios.forEach(r => {
        r.addEventListener('change', (e) => {
            if (e.target.value === 'range') {
                customRangeInput.disabled = false;
                customRangeInput.focus();
            } else {
                customRangeInput.disabled = true;
                customRangeInput.value = '';
            }
        });
    });

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        fileNameDisplay.textContent = file.name;
        settingsArea.classList.remove('hidden');
        resultArea.classList.add('hidden');
    });

    processBtn.addEventListener('click', () => {
        settingsArea.classList.add('hidden');
        loadingArea.classList.remove('hidden');
        setTimeout(() => {
            loadingArea.classList.add('hidden');
            resultArea.classList.remove('hidden');
        }, 1500);
    });
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
