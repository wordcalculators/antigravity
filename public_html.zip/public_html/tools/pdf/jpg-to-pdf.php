<?php
// tools/jpg-to-pdf.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Convert JPG to PDF Online";
$meta_description = "Easily combine multiple JPG images into a single PDF document. Secure and fast online converter.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <meta itemprop="applicationCategory" content="Utility">
    <meta itemprop="operatingSystem" content="All">
    <meta itemprop="name" content="JPG to PDF Converter">

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-10">
            <h1 class="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight"><span class="text-red-500">JPG</span> to PDF</h1>
            <p class="text-xl text-gray-600">Convert your images to a single PDF document quickly and easily.</p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 mb-16">
            <!-- Drop Zone for Backend Processing -->
            <form id="upload-form" class="drop-zone cursor-pointer rounded-xl flex flex-col items-center justify-center py-20 px-4 text-center">
                <div class="w-20 h-20 bg-red-50 text-red-500 rounded-full flex items-center justify-center text-4xl mb-4 shadow-inner">
                    <i class="fa-solid fa-file-pdf"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Select JPG images</h3>
                <p class="text-gray-500 mb-6">Drag and drop files here</p>
                <input type="file" id="file-input" name="file" class="hidden" accept="image/jpeg, image/png" multiple>
                <input type="hidden" name="tool" value="JPG to PDF">
                <button type="button" onclick="document.getElementById('file-input').click()" class="bg-primary text-white font-bold py-3 px-8 rounded-lg mb-4 hover:bg-indigo-700 transition">Browse Files</button>
            </form>

            <div id="processing-view" class="hidden text-center py-16">
                <div class="loader mx-auto border-t-red-500 w-12 h-12 mb-4"></div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Generating PDF...</h3>
                <p class="text-gray-500">Please wait while our secure servers process your document.</p>
            </div>

            <div id="result-view" class="hidden text-center py-16 bg-green-50 rounded-xl border border-green-100">
                <div class="w-20 h-20 bg-green-100 text-green-500 rounded-full flex items-center justify-center text-4xl mb-4 mx-auto shadow-inner">
                    <i class="fa-solid fa-check"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-4">PDF Generated Successfully!</h3>
                <a id="download-link" href="#" download="converted_document.pdf" class="inline-flex items-center px-6 py-3 border border-transparent shadow-sm text-lg font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none">
                    <i class="fa-solid fa-download mr-2"></i> Download PDF
                </a>
                <div class="mt-6">
                    <button onclick="location.reload()" class="text-sm font-medium text-gray-600 hover:text-gray-900 underline">Convert More Files</button>
                </div>
            </div>
        </div>
        
        <!-- SEO Section -->
        <article class="prose max-w-none text-gray-600">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">Secure PDF Generation</h2>
            <p>Our JPG to PDF converter safely uploads your images over an encrypted HTTPS connection to our server, compiles them into a single high-quality PDF document, and then immediately deletes your images from our system to ensure complete privacy.</p>
        </article>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('file-input');
    const form = document.getElementById('upload-form');
    const processingView = document.getElementById('processing-view');
    const resultView = document.getElementById('result-view');
    const downloadLink = document.getElementById('download-link');

    fileInput.addEventListener('change', async (e) => {
        if (!e.target.files.length) return;
        
        form.classList.add('hidden');
        processingView.classList.remove('hidden');

        const formData = new FormData();
        formData.append('file', e.target.files[0]); // Simple implementation sending first file
        formData.append('tool', 'JPG to PDF');

        try {
            const res = await fetch('<?php echo SITE_URL; ?>/api/convert.php', {
                method: 'POST',
                body: formData
            });
            const data = await res.json();
            
            if (data.success) {
                processingView.classList.add('hidden');
                resultView.classList.remove('hidden');
                if(data.download_url) {
                    downloadLink.href = data.download_url;
                }
            } else {
                throw new Error(data.message || 'Error occurred');
            }
        } catch (err) {
            alert('Failed to process file: ' + err.message);
            location.reload();
        }
    });

    // Drag Drop events
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        form.addEventListener(eventName, e => {
            e.preventDefault();
            e.stopPropagation();
        }, false);
    });
    
    form.addEventListener('drop', (e) => {
        fileInput.files = e.dataTransfer.files;
        fileInput.dispatchEvent(new Event('change'));
    });
});
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
