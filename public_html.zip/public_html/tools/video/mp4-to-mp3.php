<?php
// tools/video/mp4-to-mp3.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Convert MP4 to MP3 Online";
$meta_description = "Extract audio from video. Convert MP4 to MP3 in high quality instantly and securely.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">MP4 to MP3 Converter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Extract high-quality audio from your video files securely in your browser.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
            
            <div class="p-8 pb-4">
                <div class="border-2 border-dashed border-indigo-300 rounded-xl p-12 text-center hover:bg-indigo-50 transition cursor-pointer flex flex-col items-center justify-center min-h-[300px]" id="drop-zone" onclick="document.getElementById('file-input').click()">
                    
                    <div id="upload-state">
                        <i class="fa-solid fa-file-video text-6xl text-indigo-400 mb-6 drop-shadow-sm"></i>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">Drop your MP4 file here</h3>
                        <p class="text-gray-500 mb-6 font-medium">or click to browse your device (Max 100MB)</p>
                        <button class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition transform hover:-translate-y-0.5" type="button">
                            Select MP4 File
                        </button>
                    </div>

                    <div id="processing-state" class="hidden w-full max-w-md">
                        <i class="fa-solid fa-cog fa-spin text-5xl text-indigo-500 mb-4"></i>
                        <h3 class="text-xl font-bold text-gray-800 mb-2">Extracting Audio...</h3>
                        <div class="w-full bg-gray-200 rounded-full h-2.5 mt-4 mb-2">
                            <div class="bg-indigo-600 h-2.5 rounded-full transition-all duration-300" id="progress-bar" style="width: 0%"></div>
                        </div>
                        <p class="text-sm font-bold text-indigo-600" id="progress-text">0%</p>
                    </div>

                    <div id="success-state" class="hidden w-full">
                        <i class="fa-solid fa-circle-check text-6xl text-green-500 mb-4"></i>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">Conversion Complete!</h3>
                        <p class="text-gray-500 mb-6" id="filename-display">audio.mp3</p>
                        <div class="flex gap-4 justify-center">
                            <button class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition" onclick="downloadMock()">
                                <i class="fa-solid fa-download mr-2"></i> Download MP3
                            </button>
                            <button class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-8 rounded-full transition" onclick="resetUI()">
                                Convert Another
                            </button>
                        </div>
                    </div>

                    <input type="file" id="file-input" class="hidden" accept="video/mp4,video/x-m4v,video/*">
                </div>
            </div>

            <!-- Settings -->
            <div class="bg-gray-50 border-t border-gray-200 p-6 flex justify-center gap-8 text-sm font-medium text-gray-600">
                <div class="flex items-center">
                    <label class="mr-2">Audio Bitrate:</label>
                    <select class="form-select text-sm py-1 pl-2 pr-8 rounded border-gray-300">
                        <option>320 kbps (Best)</option>
                        <option selected>192 kbps (Standard)</option>
                        <option>128 kbps</option>
                        <option>64 kbps</option>
                    </select>
                </div>
                <div class="flex items-center text-indigo-600">
                    <i class="fa-solid fa-shield-halved mr-1"></i> Files deleted after 2 hours
                </div>
            </div>

        </div>
        
    </div>
</div>

<script>
    const fileInput = document.getElementById('file-input');
    const dropZone = document.getElementById('drop-zone');
    
    const stateUpload = document.getElementById('upload-state');
    const stateProcessing = document.getElementById('processing-state');
    const stateSuccess = document.getElementById('success-state');
    
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');
    const filenameDisplay = document.getElementById('filename-display');

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('border-indigo-600', 'bg-indigo-50');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('border-indigo-600', 'bg-indigo-50');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('border-indigo-600', 'bg-indigo-50');
        if(e.dataTransfer.files.length) {
            handleFile(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener('change', function() {
        if(this.files.length) {
            handleFile(this.files[0]);
        }
    });

    function handleFile(file) {
        if(!file.type.match('video.*')) {
            alert('Please select a valid video file.');
            return;
        }

        // Setup UI for processing
        stateUpload.classList.add('hidden');
        stateProcessing.classList.remove('hidden');
        
        let originalName = file.name.split('.').slice(0, -1).join('.');
        filenameDisplay.textContent = originalName + '.mp3';

        // Mock Progress for demo/UI (Normally an AJAX call + polling FFmpeg task)
        let prog = 0;
        const interval = setInterval(() => {
            prog += Math.random() * 15;
            if(prog > 100) prog = 100;
            
            progressBar.style.width = prog + '%';
            progressText.textContent = Math.round(prog) + '%';
            
            if(prog === 100) {
                clearInterval(interval);
                setTimeout(() => {
                    stateProcessing.classList.add('hidden');
                    stateSuccess.classList.remove('hidden');
                }, 500);
            }
        }, 300);
    }

    function downloadMock() {
        alert("This is a UI demonstration. In production, this would trigger a download from the processed FFmpeg file on the server.");
    }

    function resetUI() {
        stateSuccess.classList.add('hidden');
        stateUpload.classList.remove('hidden');
        progressBar.style.width = '0%';
        progressText.textContent = '0%';
        fileInput.value = '';
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
