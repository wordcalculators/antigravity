<?php
// tools/video/video-compressor.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Online Video Compressor - Reduce MP4 Size";
$meta_description = "Compress video files online without losing quality. Reduce MP4, MOV, AVI file sizes quickly and securely.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Video Compressor</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Shrink your video files to make them easier to share via email or WhatsApp.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
            
            <div class="p-8 pb-4">
                <div class="border-2 border-dashed border-blue-300 rounded-xl p-12 text-center hover:bg-blue-50 transition cursor-pointer flex flex-col items-center justify-center min-h-[300px]" id="drop-zone" onclick="document.getElementById('file-input').click()">
                    
                    <div id="upload-state">
                        <i class="fa-solid fa-compress text-6xl text-blue-400 mb-6 drop-shadow-sm"></i>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">Upload Video to Compress</h3>
                        <p class="text-gray-500 mb-6 font-medium">Supports MP4, MOV, AVI (Max 200MB)</p>
                        <button class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition transform hover:-translate-y-0.5" type="button">
                            Select File
                        </button>
                    </div>

                    <div id="processing-state" class="hidden w-full max-w-md">
                        <i class="fa-solid fa-microchip fa-bounce text-5xl text-blue-500 mb-4"></i>
                        <h3 class="text-xl font-bold text-gray-800 mb-2">Compressing Video...</h3>
                        <p class="text-sm text-gray-500 mb-4">Applying advanced h264 encoding</p>
                        <div class="w-full bg-gray-200 rounded-full h-2.5 mt-2 mb-2">
                            <div class="bg-blue-600 h-2.5 rounded-full transition-all duration-300" id="progress-bar" style="width: 0%"></div>
                        </div>
                        <p class="text-sm font-bold text-blue-600" id="progress-text">0%</p>
                    </div>

                    <div id="success-state" class="hidden w-full">
                        <i class="fa-solid fa-ranking-star text-6xl text-green-500 mb-4"></i>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">Compression Successful!</h3>
                        <div class="flex flex-col items-center justify-center gap-2 mb-6">
                            <p class="text-gray-700 font-bold text-lg"><span class="line-through text-red-400">45.2 MB</span> <i class="fa-solid fa-arrow-right mx-2 text-gray-400"></i> <span class="text-green-600 text-xl">12.8 MB</span></p>
                            <p class="text-sm font-bold bg-green-100 text-green-800 px-3 py-1 rounded-full">-72% smaller</p>
                        </div>
                        <div class="flex gap-4 justify-center">
                            <button class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition" onclick="downloadMock()">
                                <i class="fa-solid fa-download mr-2"></i> Download Video
                            </button>
                            <button class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-8 rounded-full transition" onclick="resetUI()">
                                Compress Another
                            </button>
                        </div>
                    </div>

                    <input type="file" id="file-input" class="hidden" accept="video/*">
                </div>
            </div>

            <!-- Settings -->
            <div class="bg-gray-50 border-t border-gray-200 p-6 flex flex-wrap justify-center gap-8 text-sm font-medium text-gray-600">
                <div class="flex items-center">
                    <label class="mr-2">Compression Level:</label>
                    <select class="form-select text-sm py-1 pl-2 pr-8 rounded border-gray-300">
                        <option>Recommended (Good Quality/Size)</option>
                        <option>Extreme (Smallest File)</option>
                        <option>Light (Best Quality)</option>
                    </select>
                </div>
            </div>

        </div>
        
    </div>
</div>

<script>
    const fileInput = document.getElementById('file-input');
    const dropZone = document.getElementById('drop-zone');
    
    const stateUpload = document.getElementById('upload-state');
    const stateProcessing = document.getElementById('processing-state');
    const stateSuccess = document.getElementById('success-state');
    
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('border-blue-600', 'bg-blue-50');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('border-blue-600', 'bg-blue-50');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('border-blue-600', 'bg-blue-50');
        if(e.dataTransfer.files.length) {
            handleFile(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener('change', function() {
        if(this.files.length) {
            handleFile(this.files[0]);
        }
    });

    function handleFile(file) {
        if(!file.type.match('video.*')) {
            alert('Please select a valid video file.');
            return;
        }

        stateUpload.classList.add('hidden');
        stateProcessing.classList.remove('hidden');
        
        // Mock Progress
        let prog = 0;
        const interval = setInterval(() => {
            prog += Math.random() * 8; // Slower for feeling of extreme compression
            if(prog > 100) prog = 100;
            
            progressBar.style.width = prog + '%';
            progressText.textContent = Math.round(prog) + '%';
            
            if(prog === 100) {
                clearInterval(interval);
                setTimeout(() => {
                    stateProcessing.classList.add('hidden');
                    stateSuccess.classList.remove('hidden');
                }, 800);
            }
        }, 300);
    }

    function downloadMock() {
        alert("UI Demo. Processed file would download here.");
    }

    function resetUI() {
        stateSuccess.classList.add('hidden');
        stateUpload.classList.remove('hidden');
        progressBar.style.width = '0%';
        progressText.textContent = '0%';
        fileInput.value = '';
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
