<?php
// tools/video/video-to-gif.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Video to GIF Converter Online";
$meta_description = "Convert your MP4, AVI, or WebM videos to high-quality animated GIFs instantly.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Video to GIF</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Turn your favorite video clips into lightweight, shareable animated GIFs.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
            
            <div class="p-8 pb-4">
                <div class="border-2 border-dashed border-purple-300 rounded-xl p-12 text-center hover:bg-purple-50 transition cursor-pointer flex flex-col items-center justify-center min-h-[300px]" id="drop-zone" onclick="document.getElementById('file-input').click()">
                    
                    <div id="upload-state">
                        <i class="fa-solid fa-film text-6xl text-purple-400 mb-6 drop-shadow-sm"></i>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">Upload Video for GIF</h3>
                        <p class="text-gray-500 mb-6 font-medium">MP4, WebM, AVI (Max 100MB)</p>
                        <button class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition transform hover:-translate-y-0.5" type="button">
                            Select Video
                        </button>
                    </div>

                    <div id="processing-state" class="hidden w-full max-w-md">
                        <i class="fa-solid fa-circle-notch fa-spin text-5xl text-purple-500 mb-4"></i>
                        <h3 class="text-xl font-bold text-gray-800 mb-2">Generating GIF...</h3>
                        <p class="text-sm text-gray-500 mb-4">Rendering frames and optimizing palette</p>
                        <div class="w-full bg-gray-200 rounded-full h-2.5 mt-2 mb-2">
                            <div class="bg-purple-600 h-2.5 rounded-full transition-all duration-300" id="progress-bar" style="width: 0%"></div>
                        </div>
                        <p class="text-sm font-bold text-purple-600" id="progress-text">0%</p>
                    </div>

                    <div id="success-state" class="hidden w-full flex flex-col items-center">
                        <i class="fa-solid fa-gift text-6xl text-green-500 mb-4"></i>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">GIF Created!</h3>
                        <div class="w-48 h-32 bg-gray-100 border border-gray-300 rounded mb-6 flex items-center justify-center text-gray-400 font-bold overflow-hidden">
                            [GIF Preview Mockup]
                        </div>
                        <div class="flex gap-4 justify-center">
                            <button class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition" onclick="downloadMock()">
                                <i class="fa-solid fa-download mr-2"></i> Download GIF
                            </button>
                            <button class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-8 rounded-full transition" onclick="resetUI()">
                                Make Another
                            </button>
                        </div>
                    </div>

                    <input type="file" id="file-input" class="hidden" accept="video/*">
                </div>
            </div>

            <!-- Settings -->
            <div class="bg-gray-50 border-t border-gray-200 p-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-700">
                <div>
                    <label class="block font-bold mb-1">FPS</label>
                    <select class="w-full form-select text-sm py-1.5 rounded border-gray-300">
                        <option>10</option>
                        <option selected>15 (Standard)</option>
                        <option>24 (Smooth)</option>
                    </select>
                </div>
                <div>
                    <label class="block font-bold mb-1">Width</label>
                    <select class="w-full form-select text-sm py-1.5 rounded border-gray-300">
                        <option>320px</option>
                        <option selected>480px</option>
                        <option>640px</option>
                        <option>800px</option>
                    </select>
                </div>
                <!-- Start/End purely aesthetic for UI -->
                <div>
                    <label class="block font-bold mb-1">Start Time</label>
                    <input type="text" class="w-full form-input text-sm py-1.5 rounded border-gray-300" placeholder="00:00:00">
                </div>
                <div>
                    <label class="block font-bold mb-1">End Time</label>
                    <input type="text" class="w-full form-input text-sm py-1.5 rounded border-gray-300" placeholder="00:00:05">
                </div>
            </div>

        </div>
        
    </div>
</div>

<script>
    const fileInput = document.getElementById('file-input');
    const dropZone = document.getElementById('drop-zone');
    
    const stateUpload = document.getElementById('upload-state');
    const stateProcessing = document.getElementById('processing-state');
    const stateSuccess = document.getElementById('success-state');
    
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('border-purple-600', 'bg-purple-50');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('border-purple-600', 'bg-purple-50');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('border-purple-600', 'bg-purple-50');
        if(e.dataTransfer.files.length) {
            handleFile(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener('change', function() {
        if(this.files.length) {
            handleFile(this.files[0]);
        }
    });

    function handleFile(file) {
        if(!file.type.match('video.*')) {
            alert('Please select a video file.');
            return;
        }

        stateUpload.classList.add('hidden');
        stateProcessing.classList.remove('hidden');
        
        // Mock Progress
        let prog = 0;
        const interval = setInterval(() => {
            prog += Math.random() * 12; 
            if(prog > 100) prog = 100;
            
            progressBar.style.width = prog + '%';
            progressText.textContent = Math.round(prog) + '%';
            
            if(prog === 100) {
                clearInterval(interval);
                setTimeout(() => {
                    stateProcessing.classList.add('hidden');
                    stateSuccess.classList.remove('hidden');
                }, 500);
            }
        }, 300);
    }

    function downloadMock() {
        alert("UI Demo. Download triggers here.");
    }

    function resetUI() {
        stateSuccess.classList.add('hidden');
        stateUpload.classList.remove('hidden');
        progressBar.style.width = '0%';
        progressText.textContent = '0%';
        fileInput.value = '';
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
