<?php
// tools/math/temperature.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Temperature Converter - Celsius, Fahrenheit, Kelvin";
$meta_description = "Convert temperatures easily between Celsius, Fahrenheit, and Kelvin in real-time.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Temperature Converter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Convert units between Celsius, Fahrenheit, and Kelvin.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200 p-6 md:p-10 max-w-3xl mx-auto">
            
            <div class="grid md:grid-cols-3 gap-8 items-center">
                <!-- Celsius -->
                <div>
                    <label class="block font-bold text-gray-700 text-sm mb-2 text-center text-blue-600">Celsius (°C)</label>
                    <input type="number" id="val-c" class="w-full form-input block rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-4 py-4 font-mono text-gray-800 text-2xl text-center" value="0">
                </div>

                <!-- Fahrenheit -->
                <div>
                    <label class="block font-bold text-gray-700 text-sm mb-2 text-center text-red-600">Fahrenheit (°F)</label>
                    <input type="number" id="val-f" class="w-full form-input block rounded-lg border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 px-4 py-4 font-mono text-gray-800 text-2xl text-center" value="32">
                </div>
                
                <!-- Kelvin -->
                <div>
                    <label class="block font-bold text-gray-700 text-sm mb-2 text-center text-purple-600">Kelvin (K)</label>
                    <input type="number" id="val-k" class="w-full form-input block rounded-lg border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500 px-4 py-4 font-mono text-gray-800 text-2xl text-center" value="273.15">
                </div>
            </div>

            <div class="mt-8 pt-6 border-t border-gray-100 text-center">
                <p class="text-gray-500 font-medium text-sm">
                    <strong>Formulas:</strong><br>
                    °F = (°C × 9/5) + 32<br>
                    K = °C + 273.15
                </p>
            </div>

        </div>
        
    </div>
</div>

<script>
    const elC = document.getElementById('val-c');
    const elF = document.getElementById('val-f');
    const elK = document.getElementById('val-k');

    function round(val) {
        return Number(Math.round(val + 'e4') + 'e-4');
    }

    elC.addEventListener('input', (e) => {
        let c = parseFloat(e.target.value);
        if(isNaN(c)) return;
        elF.value = round((c * 9/5) + 32);
        elK.value = round(c + 273.15);
    });

    elF.addEventListener('input', (e) => {
        let f = parseFloat(e.target.value);
        if(isNaN(f)) return;
        let c = (f - 32) * 5/9;
        elC.value = round(c);
        elK.value = round(c + 273.15);
    });

    elK.addEventListener('input', (e) => {
        let k = parseFloat(e.target.value);
        if(isNaN(k)) return;
        let c = k - 273.15;
        elC.value = round(c);
        elF.value = round((c * 9/5) + 32);
    });
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
