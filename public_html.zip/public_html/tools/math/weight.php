<?php
// tools/math/weight.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Weight Converter - Convert kg, lbs, oz, grams";
$meta_description = "Accurate online weight converter. Easily convert between kilograms, grams, pounds, ounces, and stones.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Weight Converter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Accurately convert between metric and imperial weight mass units.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200 p-6 md:p-10 max-w-2xl mx-auto">
            
            <div class="grid md:grid-cols-5 gap-4 items-center">
                <!-- From -->
                <div class="md:col-span-2">
                    <label class="block font-bold text-gray-700 text-sm mb-2">From</label>
                    <input type="number" id="input-val" class="w-full form-input block rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 px-4 py-3 font-mono text-gray-800 text-lg mb-2" value="1">
                    <select id="input-unit" class="w-full form-select rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 px-4 py-2 text-gray-700 bg-white">
                        <option value="kg">Kilogram (kg)</option>
                        <option value="g">Gram (g)</option>
                        <option value="mg">Milligram (mg)</option>
                        <option value="lbs" selected>Pound (lbs)</option>
                        <option value="oz">Ounce (oz)</option>
                        <option value="st">Stone (st)</option>
                    </select>
                </div>

                <!-- Swap Button -->
                <div class="md:col-span-1 flex justify-center py-4 md:py-0">
                    <button class="bg-indigo-100 hover:bg-indigo-200 text-indigo-700 w-12 h-12 rounded-full flex items-center justify-center transition shadow-sm" onclick="swapUnits()">
                        <i class="fa-solid fa-right-left md:rotate-0 rotate-90 text-xl"></i>
                    </button>
                </div>

                <!-- To -->
                <div class="md:col-span-2">
                    <label class="block font-bold text-gray-700 text-sm mb-2">To</label>
                    <input type="text" id="output-val" class="w-full form-input block rounded-lg border border-indigo-200 bg-indigo-50 shadow-sm px-4 py-3 font-mono text-indigo-900 text-lg mb-2 outline-none" readonly>
                    <select id="output-unit" class="w-full form-select rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 px-4 py-2 text-gray-700 bg-white">
                        <option value="kg" selected>Kilogram (kg)</option>
                        <option value="g">Gram (g)</option>
                        <option value="mg">Milligram (mg)</option>
                        <option value="lbs">Pound (lbs)</option>
                        <option value="oz">Ounce (oz)</option>
                        <option value="st">Stone (st)</option>
                    </select>
                </div>
            </div>

            <div class="mt-8 pt-6 border-t border-gray-100 text-center">
                <p class="text-gray-500 font-medium" id="formula-text">1 Pound = 0.453592 Kilograms</p>
            </div>

        </div>
        
    </div>
</div>

<script>
    const inputVal = document.getElementById('input-val');
    const inputUnit = document.getElementById('input-unit');
    const outputVal = document.getElementById('output-val');
    const outputUnit = document.getElementById('output-unit');
    const formulaText = document.getElementById('formula-text');

    // Base unit is Kilogram
    const rates = {
        kg: 1,
        g: 0.001,
        mg: 0.000001,
        lbs: 0.45359237,
        oz: 0.02834952,
        st: 6.35029318
    };

    const names = {
        kg: "Kilograms", g: "Grams", mg: "Milligrams",
        lbs: "Pounds", oz: "Ounces", st: "Stones"
    };

    function calculate() {
        let val = parseFloat(inputVal.value);
        if(isNaN(val)) {
            outputVal.value = '';
            formulaText.textContent = '';
            return;
        }

        const fromToKg = val * rates[inputUnit.value];
        const kgToTarget = fromToKg / rates[outputUnit.value];
        
        outputVal.value = Number(Math.round(kgToTarget + 'e6') + 'e-6');

        const factor = rates[inputUnit.value] / rates[outputUnit.value];
        formulaText.textContent = `1 ${names[inputUnit.value].replace(/s$/, '')} = ${Number(Math.round(factor + 'e6') + 'e-6')} ${names[outputUnit.value]}`;
    }

    function swapUnits() {
        const temp = inputUnit.value;
        inputUnit.value = outputUnit.value;
        outputUnit.value = temp;
        calculate();
    }

    inputVal.addEventListener('input', calculate);
    inputUnit.addEventListener('change', calculate);
    outputUnit.addEventListener('change', calculate);

    calculate();
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
