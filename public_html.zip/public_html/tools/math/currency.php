<?php
// tools/math/currency.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Live Currency Converter / Exchange Rates";
$meta_description = "Convert currencies using live exchange rates. Compare USD, EUR, GBP, JPY, CAD, AUD and more.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Currency Converter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Convert between 150+ global currencies using latest exchange rates.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200 p-6 md:p-10 max-w-2xl mx-auto">
            
            <div id="error-msg" class="hidden bg-red-50 text-red-600 p-4 rounded mb-6 text-sm font-medium border border-red-200 text-center"></div>

            <div class="grid md:grid-cols-5 gap-4 items-center relative">
                <!-- From -->
                <div class="md:col-span-2">
                    <label class="block font-bold text-gray-700 text-sm mb-2">Amount</label>
                    <input type="number" id="input-val" class="w-full form-input block rounded-lg border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500 px-4 py-3 font-mono text-gray-800 text-lg mb-2" value="1">
                    <select id="input-currency" class="w-full form-select rounded-lg border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500 px-4 py-2 text-gray-700 bg-white font-medium">
                        <option value="USD">USD - US Dollar</option>
                        <option value="EUR" selected>EUR - Euro</option>
                        <option value="GBP">GBP - British Pound</option>
                        <option value="JPY">JPY - Japanese Yen</option>
                        <option value="CAD">CAD - Canadian Dollar</option>
                        <option value="AUD">AUD - Australian Dollar</option>
                        <option value="INR">INR - Indian Rupee</option>
                    </select>
                </div>

                <!-- Swap Button -->
                <div class="md:col-span-1 flex justify-center py-4 md:py-0 pt-6">
                    <button class="bg-green-100 hover:bg-green-200 text-green-700 w-12 h-12 rounded-full flex items-center justify-center transition shadow-sm" onclick="swapCurrencies()">
                        <i class="fa-solid fa-right-left md:rotate-0 rotate-90 text-xl"></i>
                    </button>
                </div>

                <!-- To -->
                <div class="md:col-span-2">
                    <label class="block font-bold text-gray-700 text-sm mb-2">Converted</label>
                    <input type="text" id="output-val" class="w-full form-input block rounded-lg border border-green-200 bg-green-50 shadow-sm px-4 py-3 font-mono text-green-900 text-lg mb-2 outline-none font-bold placeholder-green-300" placeholder="Loading..." readonly>
                    <select id="output-currency" class="w-full form-select rounded-lg border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500 px-4 py-2 text-gray-700 bg-white font-medium">
                        <option value="USD" selected>USD - US Dollar</option>
                        <option value="EUR">EUR - Euro</option>
                        <option value="GBP">GBP - British Pound</option>
                        <option value="JPY">JPY - Japanese Yen</option>
                        <option value="CAD">CAD - Canadian Dollar</option>
                        <option value="AUD">AUD - Australian Dollar</option>
                        <option value="INR">INR - Indian Rupee</option>
                    </select>
                </div>
            </div>

            <div class="mt-8 pt-6 border-t border-gray-100 text-center">
                <p class="text-sm text-gray-500 mb-2">Exchange rate: <span id="rate-display" class="font-bold text-gray-800">1 EUR = ? USD</span></p>
                <p class="text-[10px] text-gray-400">Rates provided by ExchangeRate-API (mocked/free tier). Not for financial trading.</p>
            </div>

        </div>
        
    </div>
</div>

<script>
    const inputVal = document.getElementById('input-val');
    const inputCurrency = document.getElementById('input-currency');
    const outputVal = document.getElementById('output-val');
    const outputCurrency = document.getElementById('output-currency');
    const rateDisplay = document.getElementById('rate-display');
    const errorMsg = document.getElementById('error-msg');

    let ratesCache = null;
    let baseCurrency = 'USD';

    async function fetchRates() {
        try {
            outputVal.placeholder = "Updating...";
            // Using a free open API to get USD base rates
            const response = await fetch('https://open.er-api.com/v6/latest/USD');
            const data = await response.json();
            
            if(data.result === 'success') {
                ratesCache = data.rates;
                calculate();
                errorMsg.classList.add('hidden');
            } else {
                throw new Error("Failed to load rates");
            }
        } catch(e) {
            errorMsg.textContent = "Could not fetch live exchange rates. Please check your connection.";
            errorMsg.classList.remove('hidden');
            outputVal.placeholder = "Error";
            outputVal.value = "";
        }
    }

    function calculate() {
        if(!ratesCache) return;
        
        const val = parseFloat(inputVal.value);
        if(isNaN(val)) {
            outputVal.value = '';
            return;
        }

        const fromCurrency = inputCurrency.value;
        const toCurrency = outputCurrency.value;

        // Convert FROM -> USD -> TO
        const rateFromToUSD = 1 / ratesCache[fromCurrency];
        const rateUSDToTarget = ratesCache[toCurrency];
        
        const converted = val * rateFromToUSD * rateUSDToTarget;
        outputVal.value = converted.toFixed(2);

        // Display unit rate
        const unitRate = 1 * rateFromToUSD * rateUSDToTarget;
        rateDisplay.textContent = `1 ${fromCurrency} = ${unitRate.toFixed(4)} ${toCurrency}`;
    }

    function swapCurrencies() {
        const temp = inputCurrency.value;
        inputCurrency.value = outputCurrency.value;
        outputCurrency.value = temp;
        calculate();
    }

    inputVal.addEventListener('input', calculate);
    inputCurrency.addEventListener('change', calculate);
    outputCurrency.addEventListener('change', calculate);

    // Initial fetch
    fetchRates();
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
