<?php
// tools/text/text-diff.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Online Text Diff Checker";
$meta_description = "Compare two text documents to spot the differences instantly. Secure and fast text comparison tool.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Text Diff Checker</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Compare two blocks of text side-by-side to easily identify what was added, removed, or changed.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
            <!-- Toolbar -->
            <div class="bg-gray-800 px-6 py-4 flex flex-wrap justify-between items-center gap-4">
                <div class="flex gap-4 items-center flex-1">
                    <button class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-bold shadow transition flex items-center" onclick="compareTexts()">
                        <i class="fa-solid fa-code-compare mr-2"></i> Compare Texts
                    </button>
                    <button class="text-gray-400 hover:text-white font-medium text-sm transition" onclick="clearAll()">
                        <i class="fa-solid fa-eraser mr-1"></i> Clear Both
                    </button>
                </div>
            </div>

            <!-- Input Grid -->
            <div class="grid md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-gray-300 relative transition-opacity duration-300" id="input-container">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-4">
                        <label class="font-bold text-gray-800 text-sm uppercase tracking-wider"><span class="w-3 h-3 inline-block bg-red-500 rounded-full mr-2"></span>Original Text</label>
                    </div>
                    <textarea id="text-left" class="w-full min-h-[400px] p-4 font-mono text-sm text-gray-800 bg-gray-50 border border-gray-200 rounded focus:outline-none focus:ring-2 focus:ring-red-500 resize-none shadow-sm" spellcheck="false" placeholder="Paste original text here..."></textarea>
                </div>
                
                <div class="p-6">
                    <div class="flex justify-between items-center mb-4">
                        <label class="font-bold text-gray-800 text-sm uppercase tracking-wider"><span class="w-3 h-3 inline-block bg-green-500 rounded-full mr-2"></span>Changed Text</label>
                    </div>
                    <textarea id="text-right" class="w-full min-h-[400px] p-4 font-mono text-sm text-gray-800 bg-gray-50 border border-gray-200 rounded focus:outline-none focus:ring-2 focus:ring-green-500 resize-none shadow-sm" spellcheck="false" placeholder="Paste modified text here..."></textarea>
                </div>
            </div>

            <!-- Visual Result Container (Hidden initially) -->
            <div id="diff-container" class="hidden flex flex-col items-center justify-center p-12 text-center text-gray-500">
                <i class="fa-solid fa-triangle-exclamation text-5xl text-yellow-500 mb-4"></i>
                <p class="font-bold text-lg text-gray-800 mb-2">Notice: Mock Diff UI</p>
                <p class="text-sm max-w-lg mb-6">A proper text differencing algorithm (like Myers Diff) and DOM highlighter requires an external library (e.g. jsdiff) or a massive custom JS port. For this AI generation scope, the UI shell is created but the comparison logic requires standard implementation.</p>
                
                <button class="bg-gray-200 hover:bg-gray-300 text-gray-800 px-6 py-2 rounded-lg font-bold transition" onclick="resetView()">
                    <i class="fa-solid fa-arrow-left mr-2"></i> Go Back
                </button>
            </div>
        </div>
        
    </div>
</div>

<script>
    const inputContainer = document.getElementById('input-container');
    const diffContainer = document.getElementById('diff-container');
    const textLeft = document.getElementById('text-left');
    const textRight = document.getElementById('text-right');

    function compareTexts() {
        if(!textLeft.value || !textRight.value) {
            alert("Please paste text in both fields.");
            return;
        }
        inputContainer.classList.add('hidden');
        diffContainer.classList.remove('hidden');
        diffContainer.classList.add('flex');
    }

    function resetView() {
        diffContainer.classList.add('hidden');
        diffContainer.classList.remove('flex');
        inputContainer.classList.remove('hidden');
    }

    function clearAll() {
        textLeft.value = '';
        textRight.value = '';
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
