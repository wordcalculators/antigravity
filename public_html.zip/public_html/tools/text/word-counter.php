<?php
// tools/text/word-counter.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Online Word & Character Counter";
$meta_description = "Count words, characters, sentences, and paragraphs in real-time. A free utility for writers and editors.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Word & Character Counter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Paste your text below to get comprehensive statistics instantly.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
            <!-- Stats Bar Top -->
            <div class="grid grid-cols-2 md:grid-cols-4 bg-indigo-600 divide-x divide-indigo-500 text-white">
                <div class="p-4 text-center">
                    <div class="text-3xl font-black font-mono tracking-tight" id="stat-words">0</div>
                    <div class="text-xs uppercase tracking-wider font-semibold text-indigo-200 mt-1">Words</div>
                </div>
                <div class="p-4 text-center">
                    <div class="text-3xl font-black font-mono tracking-tight" id="stat-chars">0</div>
                    <div class="text-xs uppercase tracking-wider font-semibold text-indigo-200 mt-1">Characters</div>
                </div>
                <div class="p-4 text-center">
                    <div class="text-3xl font-black font-mono tracking-tight" id="stat-sentences">0</div>
                    <div class="text-xs uppercase tracking-wider font-semibold text-indigo-200 mt-1">Sentences</div>
                </div>
                <div class="p-4 text-center">
                    <div class="text-3xl font-black font-mono tracking-tight" id="stat-paragraphs">0</div>
                    <div class="text-xs uppercase tracking-wider font-semibold text-indigo-200 mt-1">Paragraphs</div>
                </div>
            </div>

            <!-- Editor Grid -->
            <div class="p-1">
                <textarea id="text-input" class="w-full min-h-[400px] p-6 text-gray-800 bg-white focus:outline-none resize-y text-lg leading-relaxed" placeholder="Start typing or paste your text here..."></textarea>
            </div>
            
            <!-- Bottom Stats -->
            <div class="bg-gray-50 px-6 py-4 border-t border-gray-200 flex flex-wrap justify-between items-center text-sm text-gray-600 gap-4">
                <div class="flex gap-6">
                    <div>Characters (no spaces): <span id="stat-chars-nospace" class="font-bold">0</span></div>
                    <div>Reading Time: <span id="stat-read-time" class="font-bold">0 min</span></div>
                </div>
                <div>
                    <button id="btn-clear" class="text-red-500 hover:text-red-700 font-semibold"><i class="fa-solid fa-trash mr-1"></i> Clear Text</button>
                    <button class="ml-4 bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-1.5 rounded font-medium transition" onclick="copyText()"><i class="fa-regular fa-copy mr-1"></i> Copy</button>
                </div>
            </div>
        </div>
        
    </div>
</div>

<script>
    const inputArea = document.getElementById('text-input');
    
    const sWords = document.getElementById('stat-words');
    const sChars = document.getElementById('stat-chars');
    const sSentences = document.getElementById('stat-sentences');
    const sParagraphs = document.getElementById('stat-paragraphs');
    
    const sCharsNoSpace = document.getElementById('stat-chars-nospace');
    const sReadTime = document.getElementById('stat-read-time');

    function updateStats() {
        const text = inputArea.value;
        
        // Chars
        const charsMatch = text.length;
        // Chars excluding spaces
        const charsNoSpaceMatch = text.replace(/\s+/g, '').length;
        
        // Words
        const wordsMatch = text.match(/\S+/g);
        const wordCount = wordsMatch ? wordsMatch.length : 0;
        
        // Sentences
        const sentenceMatch = text.match(/[^\.!\?]+[\.!\?]+/g);
        const sentenceCount = sentenceMatch ? sentenceMatch.length : 0;
        
        // Paragraphs
        const paragraphMatch = text.replace(/\n$/gm, '').split(/\n/);
        const paragraphCount = text.trim() ? paragraphMatch.filter(p => p.trim().length > 0).length : 0;

        // Reading Time (Avg 200 WPM)
        const readingTimeMins = Math.ceil(wordCount / 200);

        sWords.textContent = wordCount.toLocaleString();
        sChars.textContent = charsMatch.toLocaleString();
        sSentences.textContent = sentenceCount.toLocaleString();
        sParagraphs.textContent = paragraphCount.toLocaleString();
        
        sCharsNoSpace.textContent = charsNoSpaceMatch.toLocaleString();
        sReadTime.textContent = readingTimeMins + (readingTimeMins === 1 ? ' min' : ' mins');
    }

    inputArea.addEventListener('input', updateStats);
    
    document.getElementById('btn-clear').addEventListener('click', () => {
        inputArea.value = '';
        updateStats();
        inputArea.focus();
    });

    function copyText() {
        if(inputArea.value) {
            navigator.clipboard.writeText(inputArea.value).then(() => {
                alert("Text copied to clipboard!");
            });
        }
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
