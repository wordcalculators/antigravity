<?php
// tools/text/case-converter.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Title Case, Lowercase & Uppercase Converter";
$meta_description = "Convert text between UPPERCASE, lowercase, Title Case, camelCase, and PascalCase instantly.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Case Converter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Transform your text into any casing format instantly.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl border border-gray-200 p-6 md:p-8">
            
            <div class="flex flex-wrap gap-3 mb-6">
                <button class="bg-indigo-100 text-indigo-800 hover:bg-indigo-600 hover:text-white px-4 py-2 rounded font-semibold transition text-sm" onclick="convertCase('sentence')">Sentence case</button>
                <button class="bg-indigo-100 text-indigo-800 hover:bg-indigo-600 hover:text-white px-4 py-2 rounded font-semibold transition text-sm lowercase" onclick="convertCase('lower')">lowercase</button>
                <button class="bg-indigo-100 text-indigo-800 hover:bg-indigo-600 hover:text-white px-4 py-2 rounded font-semibold transition text-sm uppercase" onclick="convertCase('upper')">UPPERCASE</button>
                <button class="bg-indigo-100 text-indigo-800 hover:bg-indigo-600 hover:text-white px-4 py-2 rounded font-semibold transition text-sm capitalize" onclick="convertCase('title')">Title Case</button>
                <button class="bg-indigo-100 text-indigo-800 hover:bg-indigo-600 hover:text-white px-4 py-2 rounded font-semibold transition text-sm" onclick="convertCase('camel')">camelCase</button>
                <button class="bg-indigo-100 text-indigo-800 hover:bg-indigo-600 hover:text-white px-4 py-2 rounded font-semibold transition text-sm" onclick="convertCase('pascal')">PascalCase</button>
                <button class="bg-indigo-100 text-indigo-800 hover:bg-indigo-600 hover:text-white px-4 py-2 rounded font-semibold transition text-sm" onclick="convertCase('snake')">snake_case</button>
                <button class="bg-indigo-100 text-indigo-800 hover:bg-indigo-600 hover:text-white px-4 py-2 rounded font-semibold transition text-sm" onclick="convertCase('kebab')">kebab-case</button>
            </div>

            <textarea id="text-input" class="w-full min-h-[300px] p-6 text-gray-800 bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-y text-lg" placeholder="Type or paste your text here to change its casing..."></textarea>
            
            <div class="flex justify-between items-center mt-4">
                <p id="char-count" class="text-sm text-gray-500 font-mono">0 characters</p>
                <div class="flex gap-4">
                    <button class="text-red-500 hover:text-red-700 font-medium text-sm" onclick="document.getElementById('text-input').value=''; updateCount();"><i class="fa-solid fa-trash mr-1"></i> Clear</button>
                    <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded font-bold shadow-sm transition" onclick="copyText()"><i class="fa-regular fa-copy mr-2"></i> Copy Text</button>
                </div>
            </div>
            
        </div>
        
    </div>
</div>

<script>
    const inputArea = document.getElementById('text-input');
    const charCount = document.getElementById('char-count');

    function updateCount() {
        charCount.textContent = `${inputArea.value.length} characters`;
    }
    inputArea.addEventListener('input', updateCount);

    function toTitleCase(str) {
        return str.toLowerCase().replace(/(?:^|\s|-|_)\w/g, function(match) {
            return match.toUpperCase();
        });
    }

    function toSentenceCase(str) {
        return str.toLowerCase().replace(/(^\s*\w|[\.\!\?]\s*\w)/g, function(c) {
            return c.toUpperCase();
        });
    }

    function convertCase(type) {
        let text = inputArea.value;
        if (!text) return;

        switch(type) {
            case 'lower': text = text.toLowerCase(); break;
            case 'upper': text = text.toUpperCase(); break;
            case 'title': text = toTitleCase(text); break;
            case 'sentence': text = toSentenceCase(text); break;
            case 'camel': 
                text = text.replace(/(?:^\w|[A-Z]|\b\w)/g, function(word, index) {
                    return index === 0 ? word.toLowerCase() : word.toUpperCase();
                }).replace(/\s+/g, '').replace(/[-_]+/g, '');
                break;
            case 'pascal':
                text = text.replace(/(?:^\w|[A-Z]|\b\w)/g, function(word) {
                    return word.toUpperCase();
                }).replace(/\s+/g, '').replace(/[-_]+/g, '');
                break;
            case 'snake':
                text = text.toLowerCase().replace(/[\s\-]+/g, '_'); break;
            case 'kebab':
                text = text.toLowerCase().replace(/[\s\_]+/g, '-'); break;
        }
        
        inputArea.value = text;
        updateCount();
    }

    function copyText() {
        if(inputArea.value) {
            navigator.clipboard.writeText(inputArea.value).then(() => {
                alert("Text copied successfully!");
            });
        }
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
