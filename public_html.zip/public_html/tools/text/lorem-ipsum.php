<?php
// tools/text/lorem-ipsum.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Lorem Ipsum Generator";
$meta_description = "Generate standard dummy text (Lorem Ipsum) quickly for your mockups, typography, and web designs.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Lorem Ipsum Generator</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Generate placeholder text in paragraphs, sentences, or words for your mockups.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl border border-gray-200 p-6 md:p-8">
            <div class="grid md:grid-cols-4 gap-8">
                
                <!-- Controls -->
                <div class="md:col-span-1 border-b md:border-b-0 md:border-r border-gray-200 pb-6 md:pb-0 md:pr-6">
                    <h3 class="font-bold text-gray-800 text-lg mb-6 border-b pb-2">Settings</h3>
                    
                    <div class="mb-5">
                        <label class="block font-bold text-gray-700 text-sm mb-2">Count</label>
                        <input type="number" id="gen-count" class="w-full form-input block rounded-lg border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 px-3 py-2 font-mono text-gray-800" value="5" min="1" max="100">
                    </div>

                    <div class="mb-6">
                        <label class="block font-bold text-gray-700 text-sm mb-2">Format</label>
                        <select id="gen-type" class="w-full form-select rounded-lg border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 px-3 py-2 text-gray-800 bg-white">
                            <option value="paragraphs">Paragraphs</option>
                            <option value="sentences">Sentences</option>
                            <option value="words">Words</option>
                            <option value="list">List Items</option>
                        </select>
                    </div>

                    <button class="w-full bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-bold py-3 px-4 rounded-xl shadow transform transition hover:scale-[1.02]" onclick="generateLorem()">
                        Generate <i class="fa-solid fa-arrows-rotate ml-2"></i>
                    </button>
                </div>

                <!-- Output Area -->
                <div class="md:col-span-3 flex flex-col items-end">
                    <button class="mb-3 text-indigo-600 text-sm font-bold hover:text-indigo-800" onclick="copyResult()">
                        <i class="fa-regular fa-copy"></i> Copy Output
                    </button>
                    <textarea id="output-area" class="w-full h-80 p-6 text-gray-800 bg-slate-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-lg leading-relaxed shadow-inner" readonly></textarea>
                </div>

            </div>
        </div>
        
    </div>
</div>

<script>
    const dictionary = [
        "lorem", "ipsum", "dolor", "sit", "amet", "consectetur", "adipiscing", "elit", 
        "sed", "do", "eiusmod", "tempor", "incididunt", "ut", "labore", "et", "dolore", 
        "magna", "aliqua", "enim", "ad", "minim", "veniam", "quis", "nostrud", "exercitation", 
        "ullamco", "laboris", "nisi", "aliquip", "ex", "ea", "commodo", "consequat", 
        "duis", "aute", "irure", "in", "reprehenderit", "voluptate", "velit", "esse", 
        "cillum", "fugiat", "nulla", "pariatur", "excepteur", "sint", "occaecat", "cupidatat", 
        "non", "proident", "sunt", "culpa", "qui", "officia", "deserunt", "mollit", "anim", "id", "est", "laborum"
    ];

    function getWord() {
        return dictionary[Math.floor(Math.random() * dictionary.length)];
    }

    function getSentence() {
        const length = Math.floor(Math.random() * 8) + 6; // 6 to 14 words
        let sentence = [];
        for (let i = 0; i < length; i++) sentence.push(getWord());
        let finalStr = sentence.join(" ") + ".";
        return finalStr.charAt(0).toUpperCase() + finalStr.slice(1);
    }

    function getParagraph() {
        const length = Math.floor(Math.random() * 4) + 4; // 4 to 8 sentences
        let p = [];
        for(let i=0; i<length; i++) p.push(getSentence());
        return p.join(" ");
    }

    function generateLorem() {
        const count = parseInt(document.getElementById('gen-count').value, 10);
        const type = document.getElementById('gen-type').value;
        const outputArea = document.getElementById('output-area');
        
        let result = [];
        
        // Start with standard text if generating first paragraph
        let startStandard = (type === 'paragraphs' && count > 0) ? "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. " : "";

        if(type === 'paragraphs') {
            for(let i=0; i<count; i++) result.push(getParagraph());
            result[0] = startStandard + result[0]; // prepend standard start to first p
            outputArea.value = result.join("\n\n");
        } 
        else if(type === 'sentences') {
            for(let i=0; i<count; i++) result.push(getSentence());
            outputArea.value = result.join(" ");
        }
        else if(type === 'words') {
            for(let i=0; i<count; i++) result.push(getWord());
            outputArea.value = result.join(" ");
        }
        else if(type === 'list') {
            for(let i=0; i<count; i++) result.push("• " + getSentence());
            outputArea.value = result.join("\n");
        }
    }

    function copyResult() {
        const el = document.getElementById('output-area');
        if(el.value) {
            navigator.clipboard.writeText(el.value).then(() => {
                alert("Lorem Ipsum copied to clipboard!");
            });
        }
    }

    // Auto-generate on load
    window.addEventListener('DOMContentLoaded', generateLorem);
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
