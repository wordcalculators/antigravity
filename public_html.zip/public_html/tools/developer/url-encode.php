<?php
// tools/developer/url-encode.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "URL Encoder / Decoder";
$meta_description = "Encode or Decode URLs safely and quickly online. 100% Free URL encoding tool.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">URL Encoder / Decoder</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Encode reserved characters into a URL-friendly format or Decode a URL-encoded string back to readable text.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200 p-6 md:p-8">
            <div class="grid md:grid-cols-2 gap-8">
                <!-- Encode Side -->
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <label class="block font-bold text-gray-800 text-sm">Text to Encode</label>
                        <button class="text-blue-600 text-xs font-bold hover:underline" onclick="document.getElementById('input-encode').value=''; document.getElementById('output-encoded').value='';">Clear</button>
                    </div>
                    <textarea id="input-encode" class="w-full h-32 p-3 text-sm text-gray-800 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none mb-4 shadow-sm" placeholder="Text to encode..."></textarea>
                    
                    <button class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded shadow mb-4" onclick="doEncode()">Encode <i class="fa-solid fa-arrow-down ml-1"></i></button>

                    <div class="flex justify-between items-center mb-2">
                        <label class="block font-bold text-gray-800 text-sm">Encoded Output</label>
                        <button class="text-gray-500 hover:text-gray-800 text-sm" onclick="copyToClipboard('output-encoded')"><i class="fa-regular fa-copy"></i> Copy</button>
                    </div>
                    <textarea id="output-encoded" class="w-full h-32 p-3 font-mono text-sm text-blue-900 bg-blue-50 border border-blue-200 rounded-lg focus:outline-none resize-none" readonly></textarea>
                </div>
                
                <!-- Decode Side -->
                <div class="border-t md:border-t-0 md:border-l border-gray-200 pt-8 md:pt-0 md:pl-8">
                    <div class="flex justify-between items-center mb-2">
                        <label class="block font-bold text-gray-800 text-sm">URL to Decode</label>
                        <button class="text-emerald-600 text-xs font-bold hover:underline" onclick="document.getElementById('input-decode').value=''; document.getElementById('output-decoded').value='';">Clear</button>
                    </div>
                    <textarea id="input-decode" class="w-full h-32 p-3 font-mono text-sm text-gray-800 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none mb-4 shadow-sm" placeholder="%E2%9C%93+URL+Encoded+String..."></textarea>
                    
                    <button class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded shadow mb-4" onclick="doDecode()">Decode <i class="fa-solid fa-arrow-down ml-1"></i></button>

                    <div class="flex justify-between items-center mb-2">
                        <label class="block font-bold text-gray-800 text-sm">Decoded Output</label>
                         <button class="text-gray-500 hover:text-gray-800 text-sm" onclick="copyToClipboard('output-decoded')"><i class="fa-regular fa-copy"></i> Copy</button>
                    </div>
                    <textarea id="output-decoded" class="w-full h-32 p-3 text-sm text-emerald-900 bg-emerald-50 border border-emerald-200 rounded-lg focus:outline-none resize-none" readonly></textarea>
                </div>
            </div>
        </div>
        
    </div>
</div>

<script>
    function doEncode() {
        const val = document.getElementById('input-encode').value;
        document.getElementById('output-encoded').value = encodeURIComponent(val).replace(/'/g,"%27").replace(/"/g,"%22");
    }

    function doDecode() {
        const val = document.getElementById('input-decode').value;
        try {
            document.getElementById('output-decoded').value = decodeURIComponent(val.replace(/\+/g,  " "));
        } catch(e) {
            document.getElementById('output-decoded').value = "Error: Malformed URI sequence.";
        }
    }

    function copyToClipboard(elementId) {
        const el = document.getElementById(elementId);
        if(el && el.value) {
            navigator.clipboard.writeText(el.value).then(() => {
                alert("Copied!");
            });
        }
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
