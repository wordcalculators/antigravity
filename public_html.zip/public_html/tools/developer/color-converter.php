<?php
// tools/developer/color-converter.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Color Converter (HEX, RGB, HSL)";
$meta_description = "Convert colors securely between HEX, RGB, and HSL formats. Essential tool for web developers.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Color Converter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Instantly convert between HEX, RGB, and HSL color profiles.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
            <div class="grid md:grid-cols-5">
                
                <!-- Color Preview Area -->
                <div class="md:col-span-2 bg-indigo-600 flex flex-col items-center justify-center p-8 transition-colors duration-300 relative" id="color-preview">
                    
                    <div class="absolute top-4 left-4 bg-white/20 backdrop-blur rounded px-3 py-1 text-white font-mono text-sm shadow-sm" id="preview-text">
                        #4F46E5
                    </div>

                    <!-- Add a color picker input overlay hidden for trigger -->
                    <input type="color" id="native-picker" value="#4f46e5" class="w-32 h-32 opacity-0 absolute cursor-pointer">
                    <div class="w-32 h-32 rounded-full border-4 border-white shadow-2xl flex items-center justify-center cursor-pointer pointer-events-none group">
                        <i class="fa-solid fa-eye-dropper text-3xl text-white opacity-50 group-hover:opacity-100 transition"></i>
                    </div>
                </div>

                <!-- Controls Area -->
                <div class="md:col-span-3 p-8">
                    
                    <div class="space-y-6">
                        <!-- HEX Input -->
                        <div>
                            <div class="flex justify-between items-center mb-2">
                                <label class="font-bold text-gray-800 tracking-wide text-sm">HEX Array</label>
                                <button class="text-gray-400 hover:text-indigo-600" onclick="copyValue('hex-input')"><i class="fa-regular fa-copy"></i></button>
                            </div>
                            <input type="text" id="hex-input" class="w-full form-input rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 px-4 py-3 font-mono text-gray-700 text-lg uppercase" value="#4F46E5">
                        </div>

                        <!-- RGB Input -->
                        <div>
                            <div class="flex justify-between items-center mb-2">
                                <label class="font-bold text-gray-800 tracking-wide text-sm">RGB(A)</label>
                                <button class="text-gray-400 hover:text-indigo-600" onclick="copyValue('rgb-input')"><i class="fa-regular fa-copy"></i></button>
                            </div>
                            <input type="text" id="rgb-input" class="w-full form-input rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 px-4 py-3 font-mono text-gray-700 text-lg" value="rgb(79, 70, 229)">
                        </div>

                        <!-- HSL Input -->
                        <div>
                            <div class="flex justify-between items-center mb-2">
                                <label class="font-bold text-gray-800 tracking-wide text-sm">HSL(A)</label>
                                <button class="text-gray-400 hover:text-indigo-600" onclick="copyValue('hsl-input')"><i class="fa-regular fa-copy"></i></button>
                            </div>
                            <input type="text" id="hsl-input" class="w-full form-input rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 px-4 py-3 font-mono text-gray-700 text-lg" value="hsl(243, 75%, 59%)">
                        </div>
                    </div>

                </div>

            </div>
        </div>
        
    </div>
</div>

<script>
    const nativePicker = document.getElementById('native-picker');
    const colorPreview = document.getElementById('color-preview');
    const previewText = document.getElementById('preview-text');
    
    const hexInput = document.getElementById('hex-input');
    const rgbInput = document.getElementById('rgb-input');
    const hslInput = document.getElementById('hsl-input');

    // Utility: HEX to RGB
    function hexToRgb(hex) {
        let r = 0, g = 0, b = 0;
        if (hex.length === 4) {
            r = parseInt(hex[1] + hex[1], 16);
            g = parseInt(hex[2] + hex[2], 16);
            b = parseInt(hex[3] + hex[3], 16);
        } else if (hex.length === 7) {
            r = parseInt(hex.substring(1, 3), 16);
            g = parseInt(hex.substring(3, 5), 16);
            b = parseInt(hex.substring(5, 7), 16);
        }
        return `rgb(${r}, ${g}, ${b})`;
    }

    // Utility: RGB to HEX
    function rgbToHex(r, g, b) {
        return "#" + (1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1).toUpperCase();
    }

    // Utility: RGB to HSL
    function rgbToHsl(r, g, b) {
        r /= 255; g /= 255; b /= 255;
        let max = Math.max(r, g, b), min = Math.min(r, g, b);
        let h, s, l = (max + min) / 2;

        if (max === min) {
            h = s = 0; // achromatic
        } else {
            let d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            switch (max) {
                case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                case g: h = (b - r) / d + 2; break;
                case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
        }

        return `hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`;
    }

    // Utility: HSL to RGB
    function hslToRgb(h, s, l) {
        h /= 360; s /= 100; l /= 100;
        let r, g, b;

        if (s === 0) {
            r = g = b = l; // achromatic
        } else {
            const hue2rgb = (p, q, t) => {
                if (t < 0) t += 1;
                if (t > 1) t -= 1;
                if (t < 1/6) return p + (q - p) * 6 * t;
                if (t < 1/2) return q;
                if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
                return p;
            };

            let q = l < 0.5 ? l * (1 + s) : l + s - l * s;
            let p = 2 * l - q;
            r = hue2rgb(p, q, h + 1/3);
            g = hue2rgb(p, q, h);
            b = hue2rgb(p, q, h - 1/3);
        }

        return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
    }

    function syncColors(source, value) {
        try {
            let hex = '#000000', rgb = 'rgb(0, 0, 0)', hsl = 'hsl(0, 0%, 0%)';

            if (source === 'hex') {
                if(!/^#([0-9A-F]{3}){1,2}$/i.test(value)) return;
                hex = value.toUpperCase();
                rgb = hexToRgb(hex);
                const rgbMatch = rgb.match(/\d+/g);
                hsl = rgbToHsl(parseInt(rgbMatch[0]), parseInt(rgbMatch[1]), parseInt(rgbMatch[2]));
            } 
            else if (source === 'rgb') {
                const match = value.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
                if(!match) return;
                rgb = value;
                hex = rgbToHex(parseInt(match[1]), parseInt(match[2]), parseInt(match[3]));
                hsl = rgbToHsl(parseInt(match[1]), parseInt(match[2]), parseInt(match[3]));
            }
            else if (source === 'hsl') {
                const match = value.match(/hsla?\((\d+),\s*(\d+)%?,\s*(\d+)%?/i);
                if(!match) return;
                hsl = value;
                const rgbArr = hslToRgb(parseInt(match[1]), parseInt(match[2]), parseInt(match[3]));
                rgb = `rgb(${rgbArr[0]}, ${rgbArr[1]}, ${rgbArr[2]})`;
                hex = rgbToHex(rgbArr[0], rgbArr[1], rgbArr[2]);
            }

            // Update UI
            if(source !== 'hex') hexInput.value = hex;
            if(source !== 'rgb') rgbInput.value = rgb;
            if(source !== 'hsl') hslInput.value = hsl;

            colorPreview.style.backgroundColor = hex;
            previewText.textContent = hex;
            nativePicker.value = hex.length === 7 ? hex : '#000000'; // fallback for shorthand hex in picker
        } catch(e) {}
    }

    hexInput.addEventListener('input', (e) => syncColors('hex', e.target.value));
    rgbInput.addEventListener('input', (e) => syncColors('rgb', e.target.value));
    hslInput.addEventListener('input', (e) => syncColors('hsl', e.target.value));
    nativePicker.addEventListener('input', (e) => syncColors('hex', e.target.value));

    function copyValue(id) {
        const val = document.getElementById(id).value;
        navigator.clipboard.writeText(val).then(() => {
            alert("Copied " + val);
        });
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
