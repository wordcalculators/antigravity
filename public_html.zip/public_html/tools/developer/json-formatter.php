<?php
// tools/developer/json-formatter.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "JSON Formatter & Validator";
$meta_description = "Format, validate, parse, and beautify JSON data. Free online JSON formatting tool.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">JSON Formatter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Clean, beautify, and validate JSON data instantly in your browser.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
            <!-- Toolbar -->
            <div class="bg-slate-800 px-4 py-3 border-b border-slate-700 flex flex-wrap items-center justify-between gap-3">
                <div class="flex gap-2">
                    <button id="btn-format" class="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-1.5 rounded text-sm font-medium transition"><i class="fa-solid fa-wand-magic-sparkles mr-1"></i> Format</button>
                    <button id="btn-minify" class="bg-slate-600 hover:bg-slate-500 text-white px-4 py-1.5 rounded text-sm font-medium transition"><i class="fa-solid fa-compress mr-1"></i> Minify</button>
                    <button id="btn-clear" class="bg-red-500 hover:bg-red-600 text-white px-4 py-1.5 rounded text-sm font-medium transition"><i class="fa-solid fa-trash mr-1"></i> Clear</button>
                </div>
                <div class="flex gap-2 items-center">
                    <span class="text-slate-400 text-xs font-mono mr-2" id="status-indicator">Ready</span>
                    <button id="btn-copy" class="text-slate-300 hover:text-white px-3 py-1.5 rounded text-sm font-medium transition" title="Copy to Clipboard"><i class="fa-regular fa-copy"></i></button>
                </div>
            </div>

            <!-- Editor Grid -->
            <div class="grid grid-cols-1">
                <textarea id="json-input" class="w-full h-96 p-4 font-mono text-sm text-gray-800 bg-slate-50 focus:outline-none focus:ring-inset focus:ring-2 focus:ring-indigo-500 resize-y" spellcheck="false" placeholder='{"paste": "your JSON here"}'></textarea>
            </div>
            
            <!-- Error Banner -->
            <div id="error-banner" class="hidden bg-red-100 border-t border-red-200 text-red-700 px-4 py-3 text-sm font-mono">
                <i class="fa-solid fa-circle-exclamation mr-2"></i> <span id="error-msg"></span>
            </div>
        </div>
        
    </div>
</div>

<script>
    const input = document.getElementById('json-input');
    const btnFormat = document.getElementById('btn-format');
    const btnMinify = document.getElementById('btn-minify');
    const btnClear = document.getElementById('btn-clear');
    const btnCopy = document.getElementById('btn-copy');
    const statusIndicator = document.getElementById('status-indicator');
    const errorBanner = document.getElementById('error-banner');
    const errorMsg = document.getElementById('error-msg');

    function validateJSON() {
        const val = input.value.trim();
        if(!val) return null;
        try {
            const parsed = JSON.parse(val);
            errorBanner.classList.add('hidden');
            statusIndicator.innerHTML = '<span class="text-green-400"><i class="fa-solid fa-check"></i> Valid JSON</span>';
            return parsed;
        } catch(e) {
            errorMsg.textContent = e.message;
            errorBanner.classList.remove('hidden');
            statusIndicator.innerHTML = '<span class="text-red-400"><i class="fa-solid fa-xmark"></i> Invalid JSON</span>';
            return null;
        }
    }

    btnFormat.addEventListener('click', () => {
        const parsed = validateJSON();
        if(parsed) {
            input.value = JSON.stringify(parsed, null, 4);
        }
    });

    btnMinify.addEventListener('click', () => {
        const parsed = validateJSON();
        if(parsed) {
            input.value = JSON.stringify(parsed);
        }
    });

    btnClear.addEventListener('click', () => {
        input.value = '';
        errorBanner.classList.add('hidden');
        statusIndicator.textContent = 'Ready';
        input.focus();
    });

    btnCopy.addEventListener('click', () => {
        navigator.clipboard.writeText(input.value).then(() => {
            const originalHtml = statusIndicator.innerHTML;
            statusIndicator.innerHTML = '<span class="text-blue-400"><i class="fa-solid fa-check-double"></i> Copied!</span>';
            setTimeout(() => { statusIndicator.innerHTML = originalHtml; }, 2000);
        });
    });

    input.addEventListener('input', () => {
        if(input.value.trim().length > 0) {
            // Debounce validation on type could be added here
        } else {
            errorBanner.classList.add('hidden');
            statusIndicator.textContent = 'Ready';
        }
    });
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
