<?php
// tools/developer/css-minifier.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "CSS Minifier & Compressor";
$meta_description = "Minify CSS code instantly in your browser to reduce file size and increase website speed.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">CSS Minifier</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Compress CSS by removing whitespace, comments, and empty lines to improve load times.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-lg border border-gray-200">
            <div class="grid md:grid-cols-2">
                <!-- Input Box -->
                <div class="p-6 border-b md:border-b-0 md:border-r border-gray-200 flex flex-col h-full">
                    <div class="flex justify-between items-center mb-3">
                        <label class="font-bold text-gray-800 text-sm">Original CSS</label>
                        <span id="input-stats" class="text-xs text-gray-500 font-mono">0 Bytes</span>
                    </div>
                    <textarea id="input-css" class="w-full flex-1 min-h-[400px] p-4 font-mono text-sm text-gray-800 bg-slate-50 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" spellcheck="false" placeholder="/* Paste your raw CSS here... */&#10;body {&#10;  background-color: #fff;&#10;  color: #333;&#10;}"></textarea>
                </div>
                
                <!-- Output Box -->
                <div class="p-6 bg-blue-50/30 flex flex-col h-full relative">
                    <div class="flex justify-between items-center mb-3">
                        <label class="font-bold text-blue-900 text-sm">Minified CSS</label>
                        <span id="output-stats" class="text-xs font-bold text-blue-600 font-mono">0 Bytes Saved</span>
                    </div>
                    <textarea id="output-css" class="w-full flex-1 min-h-[400px] p-4 font-mono text-sm text-blue-900 bg-white border border-blue-200 rounded focus:outline-none resize-none shadow-sm" readonly></textarea>
                    
                    <button class="absolute bottom-10 right-10 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-full shadow-lg transform transition hover:scale-105" onclick="copyResult()">
                        <i class="fa-regular fa-copy mr-2"></i> Copy Minified
                    </button>
                </div>
            </div>
        </div>
        
    </div>
</div>

<script>
    const inputCss = document.getElementById('input-css');
    const outputCss = document.getElementById('output-css');
    const inputStats = document.getElementById('input-stats');
    const outputStats = document.getElementById('output-stats');

    function minifyCSS(css) {
        if(!css) return '';
        return css
            .replace(/\/\*[\s\S]*?\*\//g, '') // remove block comments
            .replace(/\s+/g, ' ')             // collapse whitespace
            .replace(/ *([{}|~>+;,!:]) */g, '$1') // remove spaces around syntax
            .replace(/;}/g, '}')              // remove trailing semicolons
            .replace(/^ +/g, '')              // remove leading spaces
            .replace(/ +$/g, '')              // remove trailing spaces
            .trim();
    }

    function formatBytes(bytes) {
        if(bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    inputCss.addEventListener('input', () => {
        const raw = inputCss.value;
        const minified = minifyCSS(raw);
        
        outputCss.value = minified;
        
        const rawBytes = new Blob([raw]).size;
        const minBytes = new Blob([minified]).size;
        const saved = rawBytes - minBytes;
        const percent = rawBytes > 0 ? Math.round((saved / rawBytes) * 100) : 0;
        
        inputStats.textContent = formatBytes(rawBytes);
        outputStats.textContent = `${formatBytes(minBytes)} (${percent}% saved)`;
    });

    function copyResult() {
        if(outputCss.value) {
            navigator.clipboard.writeText(outputCss.value).then(() => {
                alert("Minified CSS copied to clipboard!");
            });
        }
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
