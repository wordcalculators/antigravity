<?php
// tools/developer/hash-generator.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Hash Generator Online (MD5, SHA)";
$meta_description = "Generate MD5, SHA-1, SHA-256, and SHA-512 cryptographic hashes securely in your browser.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Hash Generator</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Generate cryptographic hashes using MD5, SHA-1, SHA-256, and SHA-512 algorithms instantly.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200 p-8">
            <div class="mb-6">
                <label class="block font-bold text-gray-800 mb-2">String to Hash</label>
                <textarea id="input-str" class="w-full h-32 p-4 font-mono text-sm text-gray-800 bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none shadow-inner" placeholder="Enter text here..."></textarea>
            </div>

            <div class="space-y-4">
                <!-- SHA-256 -->
                <div>
                    <div class="flex justify-between mb-1">
                        <label class="text-xs font-bold uppercase tracking-wider text-green-600">SHA-256</label>
                        <button class="text-gray-400 hover:text-gray-800" onclick="copyResult('out-sha256')"><i class="fa-regular fa-copy"></i></button>
                    </div>
                    <input type="text" id="out-sha256" class="w-full px-3 py-2 bg-green-50 text-green-800 font-mono text-xs border border-green-200 rounded outline-none" readonly>
                </div>

                <!-- SHA-512 -->
                <div>
                    <div class="flex justify-between mb-1">
                        <label class="text-xs font-bold uppercase tracking-wider text-purple-600">SHA-512</label>
                        <button class="text-gray-400 hover:text-gray-800" onclick="copyResult('out-sha512')"><i class="fa-regular fa-copy"></i></button>
                    </div>
                    <input type="text" id="out-sha512" class="w-full px-3 py-2 bg-purple-50 text-purple-800 font-mono text-[10px] sm:text-xs border border-purple-200 rounded outline-none" readonly>
                </div>
                
                <!-- SHA-1 -->
                <div>
                    <div class="flex justify-between mb-1">
                        <label class="text-xs font-bold uppercase tracking-wider text-orange-600">SHA-1 <span class="text-[9px] font-normal text-gray-400 normal-case ml-1">(Not for passwords)</span></label>
                        <button class="text-gray-400 hover:text-gray-800" onclick="copyResult('out-sha1')"><i class="fa-regular fa-copy"></i></button>
                    </div>
                    <input type="text" id="out-sha1" class="w-full px-3 py-2 bg-orange-50 text-orange-800 font-mono text-xs border border-orange-200 rounded outline-none" readonly>
                </div>

                <!-- MD5 -->
                <div>
                    <div class="flex justify-between mb-1">
                        <label class="text-xs font-bold uppercase tracking-wider text-gray-600">MD5 <span class="text-[9px] font-normal text-gray-400 normal-case ml-1">(Not for passwords)</span></label>
                        <button class="text-gray-400 hover:text-gray-800" onclick="copyResult('out-md5')"><i class="fa-regular fa-copy"></i></button>
                    </div>
                    <input type="text" id="out-md5" class="w-full px-3 py-2 bg-gray-100 text-gray-600 font-mono text-xs border border-gray-200 rounded outline-none" readonly>
                </div>
            </div>
            
        </div>
    </div>
</div>

<!-- CryptoJS for fast client-side hashing -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>
<script>
    const inputElem = document.getElementById('input-str');
    const outSha256 = document.getElementById('out-sha256');
    const outSha512 = document.getElementById('out-sha512');
    const outSha1 = document.getElementById('out-sha1');
    const outMd5 = document.getElementById('out-md5');

    function updateHashes() {
        const val = inputElem.value;
        if (!val) {
            outSha256.value = '';
            outSha512.value = '';
            outSha1.value = '';
            outMd5.value = '';
            return;
        }

        // Calculate using CryptoJS
        outSha256.value = CryptoJS.SHA256(val).toString();
        outSha512.value = CryptoJS.SHA512(val).toString();
        outSha1.value = CryptoJS.SHA1(val).toString();
        outMd5.value = CryptoJS.MD5(val).toString();
    }

    inputElem.addEventListener('input', updateHashes);

    function copyResult(id) {
        const el = document.getElementById(id);
        if(el.value) {
            navigator.clipboard.writeText(el.value);
            // Flash color
            const origColor = el.style.backgroundColor;
            el.style.backgroundColor = '#bfdbfe'; // blue-200
            setTimeout(()=>{
                el.style.backgroundColor = origColor;
            }, 300);
        }
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
