<?php
// tools/developer/html-minifier.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "HTML Minifier & Compressor";
$meta_description = "Minify HTML code instantly in your browser to reduce file size and increase website speed.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">HTML Minifier</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Compress HTML by removing whitespace, comments, and empty lines to improve load times.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-lg border border-gray-200">
            <div class="grid md:grid-cols-2">
                <!-- Input Box -->
                <div class="p-6 border-b md:border-b-0 md:border-r border-gray-200 flex flex-col h-full">
                    <div class="flex justify-between items-center mb-3">
                        <label class="font-bold text-gray-800 text-sm">Original HTML</label>
                        <span id="input-stats" class="text-xs text-gray-500 font-mono">0 Bytes</span>
                    </div>
                    <textarea id="input-html" class="w-full flex-1 min-h-[400px] p-4 font-mono text-sm text-gray-800 bg-slate-50 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none" spellcheck="false" placeholder="Paste your raw HTML here..."></textarea>
                </div>
                
                <!-- Output Box -->
                <div class="p-6 bg-indigo-50/30 flex flex-col h-full relative">
                    <div class="flex justify-between items-center mb-3">
                        <label class="font-bold text-indigo-900 text-sm">Minified HTML</label>
                        <span id="output-stats" class="text-xs font-bold text-indigo-600 font-mono">0 Bytes Saved</span>
                    </div>
                    <textarea id="output-html" class="w-full flex-1 min-h-[400px] p-4 font-mono text-sm text-indigo-900 bg-white border border-indigo-200 rounded focus:outline-none resize-none shadow-sm" readonly></textarea>
                    
                    <button class="absolute bottom-10 right-10 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded-full shadow-lg transform transition hover:scale-105" onclick="copyResult()">
                        <i class="fa-regular fa-copy mr-2"></i> Copy Minified
                    </button>
                </div>
            </div>
        </div>
        
    </div>
</div>

<script>
    const inputHtml = document.getElementById('input-html');
    const outputHtml = document.getElementById('output-html');
    const inputStats = document.getElementById('input-stats');
    const outputStats = document.getElementById('output-stats');

    function minifyHTML(html) {
        if(!html) return '';
        return html
            .replace(/<!--[\s\S]*?-->/g, '') // Remove comments
            .replace(/\s+/g, ' ')           // Collapse whitespace to space
            .replace(/>\s+</g, '><')        // Strip spaces between tags
            .trim();
    }

    function formatBytes(bytes) {
        if(bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    inputHtml.addEventListener('input', () => {
        const raw = inputHtml.value;
        const minified = minifyHTML(raw);
        
        outputHtml.value = minified;
        
        const rawBytes = new Blob([raw]).size;
        const minBytes = new Blob([minified]).size;
        const saved = rawBytes - minBytes;
        const percent = rawBytes > 0 ? Math.round((saved / rawBytes) * 100) : 0;
        
        inputStats.textContent = formatBytes(rawBytes);
        outputStats.textContent = `${formatBytes(minBytes)} (${percent}% saved)`;
    });

    function copyResult() {
        if(outputHtml.value) {
            navigator.clipboard.writeText(outputHtml.value).then(() => {
                alert("Minified HTML copied to clipboard!");
            });
        }
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
