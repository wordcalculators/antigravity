<?php
// tools/developer/base64-encode.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Base64 Encoder / Decoder";
$meta_description = "Encode string to Base64 or Decode Base64 safely online in your browser.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Base64 Encode/Decode</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Convert text to Base64 format or Decode a Base64 string instantly. Everything is processed locally in your browser.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
            <div class="grid md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-gray-200">
                <!-- Encode Side -->
                <div class="p-6">
                    <div class="flex justify-between items-center mb-3">
                        <label class="block font-bold text-gray-800 uppercase tracking-wide text-xs">Text to Encode</label>
                        <button class="text-indigo-600 text-xs font-bold hover:text-indigo-800" onclick="document.getElementById('input-text').value=''; document.getElementById('input-text').focus(); updateEncode();">Clear</button>
                    </div>
                    <textarea id="input-text" class="w-full h-40 p-3 font-medium text-sm text-gray-800 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none mb-4" placeholder="Type or paste text to encode..."></textarea>
                    
                    <div class="flex justify-between items-center mb-2">
                        <label class="block font-bold text-gray-800 uppercase tracking-wide text-xs">Base64 Output</label>
                        <button class="text-gray-500 hover:text-gray-800 transition" onclick="copyToClipboard('output-encoded')"><i class="fa-regular fa-copy"></i> Copy</button>
                    </div>
                    <textarea id="output-encoded" class="w-full h-40 p-3 font-mono text-sm text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-lg focus:outline-none resize-none" readonly></textarea>
                </div>
                
                <!-- Decode Side -->
                <div class="p-6 bg-slate-50">
                    <div class="flex justify-between items-center mb-3">
                        <label class="block font-bold text-gray-800 uppercase tracking-wide text-xs">Base64 to Decode</label>
                        <button class="text-slate-600 text-xs font-bold hover:text-slate-800" onclick="document.getElementById('input-base64').value=''; document.getElementById('input-base64').focus(); updateDecode();">Clear</button>
                    </div>
                    <textarea id="input-base64" class="w-full h-40 p-3 font-mono text-sm text-gray-800 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500 resize-none mb-4" placeholder="Paste Base64 string here..."></textarea>
                    
                    <div class="flex justify-between items-center mb-2">
                        <label class="block font-bold text-gray-800 uppercase tracking-wide text-xs">Text Output</label>
                         <button class="text-gray-500 hover:text-gray-800 transition" onclick="copyToClipboard('output-decoded')"><i class="fa-regular fa-copy"></i> Copy</button>
                    </div>
                    <textarea id="output-decoded" class="w-full h-40 p-3 font-medium text-sm text-emerald-700 bg-emerald-50 border border-emerald-100 rounded-lg focus:outline-none resize-none" readonly></textarea>
                </div>
            </div>
        </div>
        
    </div>
</div>

<script>
    const inputText = document.getElementById('input-text');
    const outputEncoded = document.getElementById('output-encoded');
    
    const inputBase64 = document.getElementById('input-base64');
    const outputDecoded = document.getElementById('output-decoded');

    function updateEncode() {
        try {
            // btoa expects a byte string. For unicode we must escape/encodeURIComponent
            outputEncoded.value = btoa(unescape(encodeURIComponent(inputText.value)));
            outputEncoded.classList.remove('text-red-600', 'bg-red-50');
            outputEncoded.classList.add('text-indigo-700', 'bg-indigo-50');
        } catch(e) {
            outputEncoded.value = "Error encoding input string.";
            outputEncoded.classList.add('text-red-600', 'bg-red-50');
        }
    }

    function updateDecode() {
        if(!inputBase64.value.trim()) {
            outputDecoded.value = '';
            return;
        }
        try {
            outputDecoded.value = decodeURIComponent(escape(atob(inputBase64.value)));
            outputDecoded.classList.remove('text-red-700', 'bg-red-50');
            outputDecoded.classList.add('text-emerald-700', 'bg-emerald-50');
        } catch(e) {
            outputDecoded.value = "Invalid Base64 string.";
            outputDecoded.classList.add('text-red-700', 'bg-red-50');
            outputDecoded.classList.remove('text-emerald-700', 'bg-emerald-50');
        }
    }

    inputText.addEventListener('input', updateEncode);
    inputBase64.addEventListener('input', updateDecode);

    function copyToClipboard(elementId) {
        const el = document.getElementById(elementId);
        if(el && el.value) {
            navigator.clipboard.writeText(el.value).then(() => {
                alert("Copied to clipboard!");
            });
        }
    }
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
