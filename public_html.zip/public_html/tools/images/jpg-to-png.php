<?php
// tools/jpg-to-png.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Convert JPG to PNG Online";
$meta_description = "Free online tool to convert JPG images to PNG format instantly. Secure, browser-based conversion.";
include __DIR__ . '/../../includes/header.php';
?>

<!-- Reuse the identical layout from png-to-jpg, just changing the config/colors -->
<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <meta itemprop="applicationCategory" content="Utility">
    <meta itemprop="operatingSystem" content="All">
    <meta itemprop="name" content="JPG to PNG Converter">

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-10">
            <h1 class="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight"><span class="text-emerald-500">JPG</span> to PNG</h1>
            <p class="text-xl text-gray-600">Convert standard photos into PNG formatting reliably within your browser.</p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 mb-16">
            <script>
                window.ImageToolConfig = {
                    action: 'convert',
                    targetMime: 'image/png',
                    targetExt: 'png'
                };
            </script>

            <!-- Drop Zone -->
            <div id="drop-zone" class="drop-zone cursor-pointer rounded-xl flex flex-col items-center justify-center py-20 px-4 text-center">
                <div class="w-20 h-20 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center text-4xl mb-4 shadow-inner">
                    <i class="fa-solid fa-file-image"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Choose JPG file</h3>
                <p class="text-gray-500 mb-6">or drop it here</p>
                <input type="file" id="file-input" class="hidden" accept="image/jpeg">
            </div>

            <!-- Preview & Action Container -->
            <div id="preview-container" class="hidden">
                 <div class="flex flex-col md:flex-row gap-8 items-center">
                    <div class="w-full md:w-1/2 rounded-lg border border-gray-200 bg-gray-50 p-2 flex items-center justify-center min-h-[300px]">
                        <img id="preview-img" src="" alt="Preview" class="max-w-full max-h-[400px] object-contain rounded drop-shadow-md">
                    </div>
                    
                    <div class="w-full md:w-1/2 flex flex-col justify-center space-y-6">
                        <div class="bg-gray-50 rounded-xl p-6 border border-gray-200">
                            <h4 class="font-bold text-gray-900 mb-4 border-b border-gray-200 pb-2">Information</h4>
                            <p class="text-sm text-gray-600">JPGs converted to PNG will likely increase in file size due to lossless formatting.</p>
                        </div>

                        <div class="flex gap-4">
                            <button id="reset-btn" class="flex-1 py-3 px-4 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">Start Over</button>
                            <button id="action-btn" class="flex-1 py-3 px-4 bg-emerald-600 text-white rounded-lg font-bold hover:bg-emerald-700 shadow flex items-center justify-center transition">
                                <span>Convert to PNG</span>
                                <div id="processing-loader" class="loader ml-3 hidden border-white border-t-transparent w-5 h-5"></div>
                            </button>
                            <a id="download-btn" class="hidden flex-1 py-3 px-4 bg-primary text-white rounded-lg font-bold hover:bg-indigo-700 shadow flex items-center justify-center transition">
                                <i class="fa-solid fa-download mr-2"></i> Download File
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo SITE_URL; ?>/assets/js/image-tools.js"></script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
