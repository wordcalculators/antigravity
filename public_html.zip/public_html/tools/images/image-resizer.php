<?php
// tools/images/image-resizer.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Resize Image Online";
$meta_description = "Resize your images instantly. Change dimensions by pixels or percentage. 100% Free and Private browser-based tool.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Tool Header -->
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4" itemprop="name">Resize Image</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto" itemprop="description">
                Change the width and height of your images without losing quality. Completely secure and processed on your device.
            </p>
        </div>

        <!-- Ad Slot Top -->
        <div class="w-full bg-gray-200 flex items-center justify-center h-24 mb-8 rounded text-gray-400 text-sm ad-slot">
            Advertisement - 728x90 (Top)
        </div>

        <!-- Main Tool Area -->
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden mb-12 border border-gray-100 p-8">
            <div id="drop-zone" class="border-2 border-dashed border-indigo-300 rounded-xl p-12 text-center hover:bg-indigo-50 transition-colors cursor-pointer relative group">
                <input type="file" id="file-input" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="image/png, image/jpeg, image/webp" aria-label="Upload Image">
                <div class="text-indigo-500 mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <i class="fa-solid fa-expand text-6xl drop-shadow-sm"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Drop your image here</h3>
                <p class="text-gray-500 mb-6">or click to browse from your device</p>
                <div class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    Select File
                </div>
                <p class="text-xs text-gray-400 mt-4">JPG, PNG or WEBP.</p>
            </div>

            <div id="settings-area" class="hidden mt-8 border-t border-gray-100 pt-8 max-w-md mx-auto relative relative">
                <h3 class="text-lg font-bold text-gray-800 mb-4">Resize Settings</h3>
                
                <div class="flex items-center gap-4 mb-4">
                    <div class="w-1/2">
                        <label class="block text-sm font-semibold text-gray-700 mb-1">Width (px)</label>
                        <input type="number" id="resize-width" class="form-input w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 px-3 py-2 border" value="800">
                    </div>
                    <div class="w-1/2">
                        <label class="block text-sm font-semibold text-gray-700 mb-1">Height (px)</label>
                        <input type="number" id="resize-height" class="form-input w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 px-3 py-2 border" value="600">
                    </div>
                </div>
                
                <div class="flex items-center mb-6">
                    <input type="checkbox" id="maintain-ratio" checked class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                    <label for="maintain-ratio" class="ml-2 block text-sm text-gray-700 font-medium">Maintain Aspect Ratio</label>
                </div>

                <button id="process-btn" class="w-full bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg transform transition-all hover:scale-[1.02] focus:outline-none focus:ring-4 focus:ring-indigo-300 flex items-center justify-center text-lg">
                    <span>Resize Image</span>
                    <i class="fa-solid fa-arrows-to-dot ml-3"></i>
                </button>
            </div>

            <!-- Previews -->
            <div id="preview-area" class="hidden mt-8 pt-8 border-t border-gray-100 flex flex-col md:flex-row gap-8 items-center justify-center bg-gray-50 rounded-xl p-6 relative">
                 <div class="text-center hidden md:block w-5/12">
                    <p class="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">Original</p>
                    <img id="original-preview" class="max-h-48 mx-auto rounded-lg shadow-sm border border-gray-200">
                    <p id="original-size" class="text-xs text-gray-500 mt-2 font-mono"></p>
                </div>
                <div class="hidden md:flex flex-col items-center justify-center w-2/12 text-indigo-300">
                     <i class="fa-solid fa-angle-right text-4xl"></i>
                </div>
                <div class="text-center w-full md:w-5/12">
                    <p class="text-sm font-semibold text-indigo-600 uppercase tracking-wider mb-3">Resized</p>
                    <img id="result-preview" class="max-h-48 mx-auto rounded-lg shadow-md border-2 border-indigo-200">
                    <div class="mt-4 pb-2">
                        <a id="download-btn" href="#" download="resized_image.png" class="inline-flex items-center px-6 py-3 border border-transparent text-sm font-medium rounded-lg shadow-md text-white bg-indigo-600 hover:bg-indigo-700">
                            Download <i class="fa-solid fa-download ml-2 text-indigo-200"></i>
                        </a>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- Ad Slot Bottom -->
        <div class="w-full bg-gray-200 flex items-center justify-center h-24 mt-8 rounded text-gray-400 text-sm ad-slot">
            Advertisement - 728x90 (Bottom)
        </div>

    </div>
</div>

<script src="<?php echo SITE_URL; ?>/assets/js/image-tools.js"></script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
