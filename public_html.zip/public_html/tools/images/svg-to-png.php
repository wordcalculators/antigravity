<?php
// tools/images/svg-to-png.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Convert SVG to PNG Online";
$meta_description = "Convert your Scalable Vector Graphics (SVG) to Web-ready PNG images instantly. Free, secure, no uploads.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4" itemprop="name">SVG to PNG Converter</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto" itemprop="description">
                Convert vector graphics (SVG) into rasterized PNG images instantly inside your browser. High resolution output.
            </p>
        </div>

        <div class="w-full bg-gray-200 flex items-center justify-center h-24 mb-8 rounded text-gray-400 text-sm ad-slot">
            Advertisement - 728x90
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden mb-12 border border-blue-100 p-8">
            <div id="drop-zone" class="border-2 border-dashed border-blue-300 rounded-xl p-12 text-center hover:bg-blue-50 transition-colors cursor-pointer relative group">
                <input type="file" id="file-input" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="image/svg+xml" aria-label="Upload SVG">
                <div class="text-blue-500 mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <i class="fa-solid fa-bezier-curve text-6xl drop-shadow-sm"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Drop your SVG file here</h3>
                <p class="text-gray-500 mb-6">or click to browse from your device</p>
                <div class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Select SVG File
                </div>
            </div>

            <div id="settings-area" class="hidden mt-8 border-t border-gray-100 pt-8 max-w-md mx-auto">
                <h3 class="text-lg font-bold text-gray-800 mb-4 text-center">Output scale</h3>
                <div class="flex items-center justify-center gap-4 mb-6">
                    <select id="scale-factor" class="form-select w-full max-w-xs rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-3 py-2 border">
                        <option value="1">1x (Original Size)</option>
                        <option value="2">2x (High Res)</option>
                        <option value="4">4x (Ultra HD)</option>
                        <option value="8">8x (Print Quality)</option>
                    </select>
                </div>

                <button id="process-svg-btn" class="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg transform transition-all hover:scale-[1.02] flex items-center justify-center text-lg">
                    <span>Convert to PNG</span>
                    <i class="fa-solid fa-wand-magic-sparkles ml-3"></i>
                </button>
            </div>

            <div id="preview-area" class="hidden mt-8 pt-8 border-t border-gray-100 flex flex-col gap-6 items-center justify-center bg-gray-50 rounded-xl p-6">
                <div class="text-center w-full">
                    <p class="text-sm font-semibold text-blue-600 uppercase tracking-wider mb-3">Rendered PNG</p>
                    <img id="result-preview" class="max-h-64 mx-auto rounded-lg shadow-md border border-gray-200 bg-white" style="background-image: linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%); background-size: 20px 20px; background-position: 0 0, 0 10px, 10px -10px, -10px 0px;">
                    <div class="mt-6">
                        <a id="download-btn" href="#" download="converted.png" class="inline-flex items-center px-8 py-3 border border-transparent text-sm font-medium rounded-lg shadow-md text-white bg-blue-600 hover:bg-blue-700">
                            Download PNG <i class="fa-solid fa-download ml-2"></i>
                        </a>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>

<script>
    // Custom logic for SVG to PNG since it uses DOM Parsing
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const settingsArea = document.getElementById('settings-area');
    const processBtn = document.getElementById('process-svg-btn');
    const previewArea = document.getElementById('preview-area');
    const resultPreview = document.getElementById('result-preview');
    const downloadBtn = document.getElementById('download-btn');
    const scaleFactorInput = document.getElementById('scale-factor');
    
    let currentSvgText = null;
    let currentFilename = 'image.svg';

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file || file.type !== 'image/svg+xml') {
            alert('Please select a valid SVG file');
            return;
        }
        
        currentFilename = file.name;
        
        const reader = new FileReader();
        reader.onload = (event) => {
            currentSvgText = event.target.result;
            settingsArea.classList.remove('hidden');
            previewArea.classList.add('hidden');
        };
        reader.readAsText(file);
    });

    processBtn.addEventListener('click', () => {
        if (!currentSvgText) return;
        
        const scale = parseInt(scaleFactorInput.value, 10) || 1;
        
        // Render SVG to Canvas
        const parser = new DOMParser();
        const doc = parser.parseFromString(currentSvgText, 'image/svg+xml');
        const svgElement = doc.documentElement;
        
        // Ensure SVG has width/height
        let width = parseFloat(svgElement.getAttribute('width')) || parseFloat(svgElement.viewBox?.baseVal?.width) || 800;
        let height = parseFloat(svgElement.getAttribute('height')) || parseFloat(svgElement.viewBox?.baseVal?.height) || 600;
        
        width *= scale;
        height *= scale;
        
        svgElement.setAttribute('width', width);
        svgElement.setAttribute('height', height);
        
        const svgString = new XMLSerializer().serializeToString(svgElement);
        const svgBlob = new Blob([svgString], {type: 'image/svg+xml;charset=utf-8'});
        const url = URL.createObjectURL(svgBlob);
        
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);
            
            URL.revokeObjectURL(url);
            
            const pngDataUrl = canvas.toDataURL('image/png');
            resultPreview.src = pngDataUrl;
            
            const outName = currentFilename.replace(/\.svg$/i, '') + '.png';
            downloadBtn.download = outName;
            downloadBtn.href = pngDataUrl;
            
            previewArea.classList.remove('hidden');
            
            // Scroll to preview
            previewArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        };
        img.src = url;
    });
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
