<?php
// tools/png-to-jpg.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Convert PNG to JPG Online";
$meta_description = "Free online tool to convert PNG images to JPG format instantly. Secure, browser-based conversion with high quality.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <meta itemprop="applicationCategory" content="Utility">
    <meta itemprop="operatingSystem" content="All">
    <meta itemprop="name" content="PNG to JPG Converter">

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Tool Header -->
        <div class="text-center mb-10">
            <h1 class="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight"><span class="text-primary">PNG</span> to JPG</h1>
            <p class="text-xl text-gray-600">Convert your transparent PNG images into compressed JPG format safely within your browser.</p>
        </div>

        <!-- Tool Workspace -->
        <div class="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 mb-16">
            
            <!-- JS Config injection -->
            <script>
                window.ImageToolConfig = {
                    action: 'convert',
                    targetMime: 'image/jpeg',
                    targetExt: 'jpg'
                };
            </script>

            <!-- Drop Zone -->
            <div id="drop-zone" class="drop-zone cursor-pointer rounded-xl flex flex-col items-center justify-center py-20 px-4 text-center">
                <div class="w-20 h-20 bg-indigo-50 text-primary rounded-full flex items-center justify-center text-4xl mb-4 shadow-inner">
                    <i class="fa-solid fa-cloud-arrow-up"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Choose PNG file</h3>
                <p class="text-gray-500 mb-6">or drop it here</p>
                <div class="flex items-center gap-2 text-sm text-gray-400">
                    <i class="fa-solid fa-shield-halved text-secondary"></i> 100% Secure. Files are processed locally.
                </div>
                <input type="file" id="file-input" class="hidden" accept="image/png">
            </div>

            <!-- Preview & Action Container -->
            <div id="preview-container" class="hidden">
                <div class="flex flex-col md:flex-row gap-8 items-center">
                    <!-- Image Preview -->
                    <div class="w-full md:w-1/2 rounded-lg border border-gray-200 bg-gray-50 p-2 flex items-center justify-center min-h-[300px]">
                        <img id="preview-img" src="" alt="Preview" class="max-w-full max-h-[400px] object-contain rounded drop-shadow-md">
                    </div>
                    
                    <!-- Controls -->
                    <div class="w-full md:w-1/2 flex flex-col justify-center space-y-6">
                        <div class="bg-gray-50 rounded-xl p-6 border border-gray-200">
                            <h4 class="font-bold text-gray-900 mb-4 border-b border-gray-200 pb-2">Conversion Settings</h4>
                            
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">JPG Quality (<span id="quality-val">90</span>%)</label>
                                <input type="range" id="quality-slider" min="10" max="100" value="90" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" oninput="document.getElementById('quality-val').innerText = this.value">
                            </div>
                            
                            <div class="text-xs text-gray-500 mt-2 bg-yellow-50 p-2 rounded border border-yellow-100">
                                <i class="fa-solid fa-circle-info text-yellow-500 mr-1"></i> Transparent areas will be converted to white.
                            </div>
                        </div>

                        <div class="flex gap-4">
                            <button id="reset-btn" class="flex-1 py-3 px-4 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors">
                                Start Over
                            </button>
                            <button id="action-btn" class="flex-1 py-3 px-4 bg-primary text-white rounded-lg font-bold hover:bg-indigo-700 shadow flex items-center justify-center transition-colors">
                                <span>Convert to JPG</span>
                                <div id="processing-loader" class="loader ml-3 hidden border-white border-t-transparent w-5 h-5"></div>
                            </button>
                            <a id="download-btn" class="hidden flex-1 py-3 px-4 bg-secondary text-white rounded-lg font-bold hover:bg-emerald-600 shadow flex items-center justify-center transition-colors">
                                <i class="fa-solid fa-download mr-2"></i> Download File
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- SEO Content Section -->
        <article class="prose max-w-none text-gray-600">
            <h2 class="text-2xl font-bold text-gray-900 border-b border-gray-200 pb-2 mb-4">How to convert PNG to JPG</h2>
            <ol class="list-decimal pl-5 space-y-2 mb-8">
                <li>Click the upload area to select your PNG image from your device.</li>
                <li>Adjust the quality slider if you want to optimize the file size.</li>
                <li>Click the "Convert to JPG" button to process the image instantly.</li>
                <li>Your file will be converted locally in your browser. Click Download to save.</li>
            </ol>

            <h2 class="text-2xl font-bold text-gray-900 border-b border-gray-200 pb-2 mb-4">Why use our PNG to JPG converter?</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div>
                    <h3 class="font-bold text-gray-900"><i class="fa-solid fa-lock text-primary mr-2"></i> Total Privacy</h3>
                    <p class="text-sm mt-1">Our tool uses HTML5 Canvas technology to process your files entirely within your web browser. Your images are never uploaded to any server, guaranteeing 100% privacy and security.</p>
                </div>
                <div>
                    <h3 class="font-bold text-gray-900"><i class="fa-solid fa-gauge-high text-primary mr-2"></i> Unmatched Speed</h3>
                    <p class="text-sm mt-1">Because there's no waiting for uploads or downloads from a remote server, conversion is practically instantaneous, saving you valuable time.</p>
                </div>
            </div>

            <h2 class="text-2xl font-bold text-gray-900 border-b border-gray-200 pb-2 mb-4">Frequently Asked Questions</h2>
            <dl class="space-y-4">
                <div>
                    <dt class="font-bold text-gray-900">What happens to the transparent background of my PNG?</dt>
                    <dd class="mt-1 text-sm bg-gray-50 p-3 rounded">JPG format does not support transparency. When you convert a transparent PNG to JPG, the transparent areas will automatically become white.</dd>
                </div>
                <div>
                    <dt class="font-bold text-gray-900">Does converting PNG to JPG reduce file size?</dt>
                    <dd class="mt-1 text-sm bg-gray-50 p-3 rounded">Yes, generally JPG files are much smaller than PNG files because JPG uses lossy compression algorithms designed specifically for photographic images.</dd>
                </div>
            </dl>
        </article>
    </div>
</div>

<!-- Load Tool Logic -->
<script src="<?php echo SITE_URL; ?>/assets/js/image-tools.js"></script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
