<?php
// tools/image-compressor.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Compress Image Online";
$meta_description = "Free online image compressor. Reduce the file size of your JPG or PNG images without losing quality directly in your browser.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <meta itemprop="applicationCategory" content="Utility">
    <meta itemprop="operatingSystem" content="All">
    <meta itemprop="name" content="Image Compressor">

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Tool Header -->
        <div class="text-center mb-10">
            <h1 class="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">Image <span class="text-primary">Compressor</span></h1>
            <p class="text-xl text-gray-600">Reduce image file size by up to 80% without visible loss in quality.</p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 mb-16">
            <script>
                // Use the js script config to handle compression instead of strict conversion
                window.ImageToolConfig = {
                    action: 'compress',
                    targetExt: 'jpg'
                };
            </script>

            <!-- Drop Zone -->
            <div id="drop-zone" class="drop-zone cursor-pointer rounded-xl flex flex-col items-center justify-center py-20 px-4 text-center">
                <div class="w-20 h-20 bg-purple-50 text-purple-500 rounded-full flex items-center justify-center text-4xl mb-4 shadow-inner">
                    <i class="fa-solid fa-compress-arrows-alt"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Choose Image</h3>
                <p class="text-gray-500 mb-6">Supports JPG, PNG, WebP</p>
                <div class="flex items-center gap-2 text-sm text-gray-400">
                    <i class="fa-solid fa-shield-halved text-secondary"></i> Processed locally in browser
                </div>
                <input type="file" id="file-input" class="hidden" accept="image/jpeg, image/png, image/webp">
            </div>

            <!-- Preview Container -->
            <div id="preview-container" class="hidden">
                 <div class="flex flex-col md:flex-row gap-8 items-center">
                    <div class="w-full md:w-1/2 rounded-lg border border-gray-200 bg-gray-50 p-2 flex items-center justify-center min-h-[300px]">
                        <img id="preview-img" src="" alt="Preview" class="max-w-full max-h-[400px] object-contain rounded drop-shadow-md">
                    </div>
                    
                    <div class="w-full md:w-1/2 flex flex-col justify-center space-y-6">
                        <div class="bg-gray-50 rounded-xl p-6 border border-gray-200">
                            <h4 class="font-bold text-gray-900 mb-4 border-b border-gray-200 pb-2">Compression Level</h4>
                            
                            <div class="mb-2 flex justify-between text-xs font-bold text-gray-500 uppercase tracking-wide">
                                <span>High Compression</span>
                                <span>High Quality</span>
                            </div>
                            <div class="mb-4">
                                <input type="range" id="quality-slider" min="10" max="90" value="60" class="w-full h-2 bg-gradient-to-r from-red-400 via-yellow-400 to-green-400 rounded-lg appearance-none cursor-pointer" oninput="document.getElementById('quality-val').innerText = this.value">
                            </div>
                            <p class="text-center text-sm font-medium text-gray-700">Quality: <span id="quality-val" class="text-primary text-lg">60</span>%</p>
                            
                        </div>

                        <div class="flex gap-4">
                            <button id="reset-btn" class="flex-1 py-3 px-4 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors">Start Over</button>
                            <button id="action-btn" class="flex-1 py-3 px-4 bg-primary text-white rounded-lg font-bold hover:bg-indigo-700 shadow flex items-center justify-center transition-colors">
                                <span>Compress Image</span>
                                <div id="processing-loader" class="loader ml-3 hidden border-white border-t-transparent w-5 h-5"></div>
                            </button>
                            <a id="download-btn" class="hidden flex-1 py-3 px-4 bg-secondary text-white rounded-lg font-bold hover:bg-emerald-600 shadow flex items-center justify-center transition-colors">
                                <i class="fa-solid fa-download mr-2"></i> Download
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SEO Section -->
        <article class="prose max-w-none text-gray-600">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">Why compress images?</h2>
            <p>Large image files can significantly slow down your website loading speed, consume massive amounts of storage space on your device, and drain bandwidth when shared over mobile networks. Our image compressor uses smart lossy compression techniques to drastically reduce the file size of your photos.</p>
        </article>
    </div>
</div>

<script src="<?php echo SITE_URL; ?>/assets/js/image-tools.js"></script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
