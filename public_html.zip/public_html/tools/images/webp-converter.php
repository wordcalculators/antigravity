<?php
// tools/webp-converter.php (Handles PNG/JPG to WebP via url params or generic drop)
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Convert Image to WebP Online";
$meta_description = "Convert your images to next-generation WebP format for superior web compression.";
include __DIR__ . '/../../includes/header.php';
?>

<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-10">
            <h1 class="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">Convert to <span class="text-blue-500">WebP</span></h1>
            <p class="text-xl text-gray-600">Transform standard images into Google's highly optimized WebP format.</p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 mb-16">
            <script>
                window.ImageToolConfig = {
                    action: 'convert',
                    targetMime: 'image/webp',
                    targetExt: 'webp'
                };
            </script>

            <!-- Drop Zone -->
            <div id="drop-zone" class="drop-zone cursor-pointer rounded-xl flex flex-col items-center justify-center py-20 px-4 text-center">
                <div class="w-20 h-20 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center text-4xl mb-4 shadow-inner">
                    <i class="fa-brands fa-google"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Upload Image</h3>
                <p class="text-gray-500 mb-6">Supports JPG & PNG</p>
                <input type="file" id="file-input" class="hidden" accept="image/jpeg, image/png">
            </div>

            <!-- Preview Section -->
            <div id="preview-container" class="hidden">
                 <div class="flex flex-col md:flex-row gap-8 items-center">
                    <div class="w-full md:w-1/2 rounded-lg border border-gray-200 bg-gray-50 p-2 flex items-center justify-center min-h-[300px]">
                        <img id="preview-img" src="" class="max-w-full max-h-[400px] object-contain rounded drop-shadow-md">
                    </div>
                    
                    <div class="w-full md:w-1/2 flex flex-col justify-center space-y-6">
                        <div class="bg-gray-50 rounded-xl p-6 border border-gray-200">
                            <h4 class="font-bold text-gray-900 mb-4 border-b border-gray-200 pb-2">WebP Quality</h4>
                            <div class="mb-4">
                                <input type="range" id="quality-slider" min="10" max="100" value="85" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" oninput="document.getElementById('quality-val').innerText = this.value">
                                <p class="text-center text-sm mt-2 text-gray-600">Quality: <span id="quality-val" class="font-bold text-primary">85</span>%</p>
                            </div>
                        </div>

                        <div class="flex gap-4">
                            <button id="reset-btn" class="flex-1 py-3 px-4 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition">Reset</button>
                            <button id="action-btn" class="flex-1 py-3 px-4 bg-primary text-white rounded-lg font-bold hover:bg-indigo-700 shadow flex items-center justify-center transition">
                                <span>Compile WebP</span>
                                <div id="processing-loader" class="loader ml-3 hidden border-white border-t-transparent w-5 h-5"></div>
                            </button>
                            <a id="download-btn" class="hidden flex-1 py-3 px-4 bg-green-500 text-white rounded-lg font-bold hover:bg-green-600 shadow flex items-center justify-center transition">
                                Download
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo SITE_URL; ?>/assets/js/image-tools.js"></script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
