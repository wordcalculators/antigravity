<?php
// tools/images/gif-maker.php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/functions.php';

$page_title = "Image to GIF Maker Online";
$meta_description = "Create animated GIFs by uploading multiple image frames. Processed privately in your browser.";
include __DIR__ . '/../../includes/header.php';
// Note: Generating GIFs securely in pure JS can be done using libraries like gif.js, 
// For this AI structure, we'll build the UI shell with a stubbed JS or rely on standard implementations.
?>

<div class="bg-gray-50 min-h-screen py-10" itemscope itemtype="https://schema.org/SoftwareApplication">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4" itemprop="name">GIF Maker</h1>
            <p class="text-lg text-gray-600 max-w-2xl mx-auto" itemprop="description">
                Upload multiple images (JPG, PNG) and combine them into an animated GIF natively.
            </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden mb-12 border border-purple-100 p-8">
            <div id="drop-zone" class="border-2 border-dashed border-purple-300 rounded-xl p-12 text-center hover:bg-purple-50 transition-colors cursor-pointer relative group">
                <input type="file" id="file-input" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="image/png, image/jpeg, image/webp" multiple aria-label="Upload Images">
                <div class="text-purple-500 mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    <i class="fa-solid fa-film text-6xl drop-shadow-sm"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 mb-2">Drop image frames here</h3>
                <p class="text-gray-500 mb-6">Select 2 or more images to create a GIF</p>
                <div class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700">
                    Select Images
                </div>
            </div>

            <div id="frames-preview" class="hidden mt-8 grid grid-cols-4 md:grid-cols-6 gap-4">
                <!-- Frame thumbnails injected by JS -->
            </div>

            <div id="settings-area" class="hidden mt-8 border-t border-gray-100 pt-8 max-w-md mx-auto">
                <h3 class="text-lg font-bold text-gray-800 mb-4 text-center">Animation Settings</h3>
                
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-gray-700 mb-1">Delay per frame (ms)</label>
                    <input type="number" id="frame-delay" value="500" class="form-input w-full rounded-md border-gray-300 shadow-sm px-3 py-2 border focus:border-purple-500">
                    <p class="text-xs text-gray-400 mt-1">1000ms = 1 second</p>
                </div>

                <div class="bg-yellow-50 text-yellow-800 p-4 border border-yellow-200 rounded mb-6 text-sm">
                    <i class="fa-solid fa-triangle-exclamation mr-1"></i> Client-side GIF generation requires external libraries (like gif.js). This is a mock UI for the system implementation.
                </div>

                <button id="process-btn" class="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold py-4 px-8 rounded-xl shadow-lg transform transition-all flex items-center justify-center text-lg opacity-50 cursor-not-allowed" disabled>
                    <span>Generate GIF</span>
                    <i class="fa-solid fa-gear ml-3"></i>
                </button>
            </div>
        </div>
        
    </div>
</div>

<script>
    const fileInput = document.getElementById('file-input');
    const framesPreview = document.getElementById('frames-preview');
    const settingsArea = document.getElementById('settings-area');
    
    fileInput.addEventListener('change', (e) => {
        const files = Array.from(e.target.files);
        if (files.length < 2) {
            alert('Please select at least 2 images to create a GIF.');
            return;
        }
        
        framesPreview.innerHTML = '';
        files.forEach((file, index) => {
            const reader = new FileReader();
            reader.onload = (event) => {
                const imgWrap = document.createElement('div');
                imgWrap.className = 'relative border border-gray-200 rounded shadow-sm overflow-hidden aspect-square flex items-center justify-center bg-gray-100';
                
                const img = document.createElement('img');
                img.src = event.target.result;
                img.className = 'max-w-full max-h-full object-contain';
                
                const num = document.createElement('div');
                num.className = 'absolute top-1 left-1 bg-black bg-opacity-70 text-white text-xs px-1.5 py-0.5 rounded font-mono';
                num.textContent = index + 1;
                
                imgWrap.appendChild(img);
                imgWrap.appendChild(num);
                framesPreview.appendChild(imgWrap);
            };
            reader.readAsDataURL(file);
        });
        
        framesPreview.classList.remove('hidden');
        settingsArea.classList.remove('hidden');
    });
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
