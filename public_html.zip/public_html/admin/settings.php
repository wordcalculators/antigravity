<?php
// admin/settings.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
require_developer();

global $pdo;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $logo_opt = $_POST['logo_override'] ?? '';
    $ga_opt = $_POST['analytics_id'] ?? '';
    
    $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'logo_override'");
    $stmt->execute([$logo_opt]);
    
    $stmt2 = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'analytics_id'");
    $stmt2->execute([$ga_opt]);
    
    $success = "Settings updated successfully.";
}

// Fetch current
$settings = [];
$s = $pdo->query("SELECT * FROM settings")->fetchAll();
foreach($s as $row) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Global Settings - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden text-sm">
    <!-- Sidebar -->
    <aside class="w-64 bg-slate-900 text-white flex flex-col hidden md:flex">
        <div class="h-16 flex items-center px-6 border-b border-slate-800">
            <span class="font-bold text-lg tracking-tight"><?php echo SITE_NAME; ?> Admin</span>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-2">
            <a href="index.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-gauge w-5 text-center"></i> Dashboard
            </a>
            <a href="users.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                 <i class="fa-solid fa-users w-5 text-center"></i> Users
            </a>
            <a href="settings.php" class="flex items-center gap-3 px-3 py-2 bg-indigo-600 text-white rounded-lg">
                <i class="fa-solid fa-cog w-5 text-center"></i> Settings
            </a>
        </nav>
    </aside>

    <main class="flex-1 flex flex-col overflow-y-auto">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center px-8">
            <h1 class="text-xl font-semibold text-gray-800">Site Settings</h1>
        </header>

        <div class="p-8 max-w-2xl">
            <?php if(isset($success)): ?>
            <div class="bg-green-50 text-green-700 p-4 rounded-lg mb-6 shadow-sm border border-green-200 font-medium">
                <?php echo $success; ?>
            </div>
            <?php endif; ?>
        
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <form method="POST" class="p-6 space-y-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">Logo URL Override</label>
                        <input type="text" name="logo_override" value="<?php echo htmlspecialchars($settings['logo_override'] ?? ''); ?>" class="w-full border border-gray-300 rounded-md p-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none" placeholder="e.g. https://domain.to/logo.png">
                        <p class="text-xs text-gray-500 mt-1">Leave blank to use the dynamic First-Letter block logo.</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">Google Analytics ID</label>
                        <input type="text" name="analytics_id" value="<?php echo htmlspecialchars($settings['analytics_id'] ?? ''); ?>" class="w-full border border-gray-300 rounded-md p-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none" placeholder="e.g. G-XXXXXXX">
                        <p class="text-xs text-gray-500 mt-1">Automatically enables GA4 tracking if provided.</p>
                    </div>
                    
                    <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition">Save Configuration</button>
                </form>
            </div>
        </div>
    </main>
</body>
</html>
