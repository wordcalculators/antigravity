<?php
// admin/payments.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
require_developer();

global $pdo;

$stmt = $pdo->query("
    SELECT s.*, p.name as plan_name, p.price, u.email as user_email 
    FROM subscriptions s 
    JOIN plans p ON s.plan_id = p.id
    JOIN users u ON s.user_id = u.id 
    ORDER BY s.start_date DESC
");
$subs = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Subscriptions - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden text-sm">
    <aside class="w-64 bg-slate-900 text-white flex flex-col hidden md:flex">
        <div class="h-16 flex items-center px-6 border-b border-slate-800">
            <span class="font-bold text-lg tracking-tight"><?php echo SITE_NAME; ?> Admin</span>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-2">
            <a href="index.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg"><i class="fa-solid fa-gauge w-5"></i> Dashboard</a>
            <a href="users.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg"><i class="fa-solid fa-users w-5"></i> Users</a>
            <a href="payments.php" class="flex items-center gap-3 px-3 py-2 bg-indigo-600 text-white rounded-lg"><i class="fa-solid fa-crown w-5"></i> Subscriptions</a>
        </nav>
    </aside>

    <main class="flex-1 flex flex-col overflow-y-auto">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8">
            <h1 class="text-xl font-semibold text-gray-800">Active Subscriptions</h1>
        </header>
        <div class="p-8">
             <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">User Email</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Plan</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Amount</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Valid Until</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200 text-sm">
                        <?php if(empty($subs)): ?>
                            <tr><td colspan="5" class="px-6 py-4 text-center text-gray-500">No active subscriptions found.</td></tr>
                        <?php else: ?>
                            <?php foreach($subs as $s): ?>
                                <tr>
                                    <td class="px-6 py-4 font-medium text-gray-900"><?php echo htmlspecialchars($s['user_email']); ?></td>
                                    <td class="px-6 py-4"><span class="bg-purple-100 text-purple-800 px-2 py-1 rounded text-xs font-bold uppercase tracking-wider"><?php echo htmlspecialchars($s['plan_name']); ?></span></td>
                                    <td class="px-6 py-4 font-mono text-gray-500">$<?php echo $s['price']; ?>/mo</td>
                                    <td class="px-6 py-4">
                                        <?php if($s['status'] === 'active'): ?>
                                            <span class="px-2 py-1 bg-green-100 text-green-800 rounded text-xs font-semibold">Active</span>
                                        <?php else: ?>
                                            <span class="px-2 py-1 bg-red-100 text-red-800 rounded text-xs font-semibold"><?php echo ucfirst($s['status']); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-gray-500"><?php echo date('M j, Y', strtotime($s['end_date'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>
