<?php
// admin/conversions.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
require_developer();

global $pdo;

// Fetch Conversions
$stmt = $pdo->query("
    SELECT h.*, u.name as user_name, u.email 
    FROM history h 
    LEFT JOIN users u ON h.user_id = u.id 
    ORDER BY h.date DESC LIMIT 100
");
$conversions = $stmt->fetchAll();

$page_title = "Conversion Logs";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Conversion Logs - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden text-sm">

    <!-- Sidebar (Same as Index) -->
    <aside class="w-64 bg-slate-900 text-white flex flex-col hidden md:flex">
        <div class="h-16 flex items-center px-6 border-b border-slate-800">
            <span class="font-bold text-lg tracking-tight"><?php echo SITE_NAME; ?> Admin</span>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-2">
            <a href="index.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-gauge w-5 text-center"></i> Dashboard
            </a>
            <a href="users.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-users w-5 text-center"></i> Users
            </a>
            <a href="conversions.php" class="flex items-center gap-3 px-3 py-2 bg-indigo-600 text-white rounded-lg">
                <i class="fa-solid fa-bolt w-5 text-center"></i> Conversions Log
            </a>
            <a href="api-keys.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-key w-5 text-center"></i> API Keys
            </a>
            <a href="settings.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-cog w-5 text-center"></i> Settings
            </a>
            <a href="db-health.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-database w-5 text-center"></i> DB Health
            </a>
        </nav>
        <div class="p-4 border-t border-slate-800">
            <a href="<?php echo SITE_URL; ?>" class="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-white">
                <i class="fa-solid fa-arrow-left w-5 text-center"></i> Back to Site
            </a>
        </div>
    </aside>

    <main class="flex-1 flex flex-col overflow-y-auto">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8">
            <h1 class="text-xl font-semibold text-gray-800">Conversions Log</h1>
        </header>

        <div class="p-8">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
                    <h2 class="text-lg font-bold text-gray-800">Latest 100 Conversions</h2>
                    <button class="text-sm font-medium text-indigo-600 hover:text-indigo-800"><i class="fa-solid fa-download mr-1"></i> Export CSV</button>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">ID</th>
                                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">User</th>
                                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Tool</th>
                                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">File Output</th>
                                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Date</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200 text-sm">
                            <?php foreach($conversions as $c): ?>
                            <tr>
                                <td class="px-6 py-4 text-gray-500">#<?php echo $c['id']; ?></td>
                                <td class="px-6 py-4 font-medium text-gray-900"><?php echo htmlspecialchars($c['user_name'] ?? 'Guest System'); ?></td>
                                <td class="px-6 py-4"><span class="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs font-semibold tracking-wide"><?php echo htmlspecialchars($c['tool_name']); ?></span></td>
                                <td class="px-6 py-4 text-gray-500 truncate max-w-xs"><?php echo htmlspecialchars($c['file_name']); ?></td>
                                <td class="px-6 py-4 text-gray-400"><?php echo date('M j, Y H:i:s', strtotime($c['date'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
