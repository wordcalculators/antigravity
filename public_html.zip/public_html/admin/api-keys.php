<?php
// admin/api-keys.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
require_developer();

global $pdo;

$stmt = $pdo->query("
    SELECT a.*, u.email as user_email 
    FROM api_keys a 
    JOIN users u ON a.user_id = u.id 
    ORDER BY a.created_at DESC
");
$keys = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>API Keys - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden text-sm">
    <!-- Sidebar -->
    <aside class="w-64 bg-slate-900 text-white flex flex-col hidden md:flex">
        <div class="h-16 flex items-center px-6 border-b border-slate-800">
            <span class="font-bold text-lg tracking-tight"><?php echo SITE_NAME; ?> Admin</span>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-2">
            <a href="index.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-gauge w-5 text-center"></i> Dashboard
            </a>
            <a href="users.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-users w-5 text-center"></i> Users
            </a>
            <a href="conversions.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-bolt w-5 text-center"></i> Conversions Log
            </a>
            <a href="api-keys.php" class="flex items-center gap-3 px-3 py-2 bg-indigo-600 text-white rounded-lg">
                <i class="fa-solid fa-key w-5 text-center"></i> API Keys
            </a>
            <a href="settings.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-cog w-5 text-center"></i> Settings
            </a>
            <a href="db-health.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
                <i class="fa-solid fa-database w-5 text-center"></i> DB Health
            </a>
        </nav>
    </aside>

    <main class="flex-1 flex flex-col overflow-y-auto">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8">
            <h1 class="text-xl font-semibold text-gray-800">Manage API Keys</h1>
        </header>

        <div class="p-8">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">User Email</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Key Hash</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Rate Limit (per HR)</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200 text-sm">
                        <?php if(empty($keys)): ?>
                            <tr><td colspan="4" class="px-6 py-4 text-center text-gray-500">No active API keys found.</td></tr>
                        <?php else: ?>
                            <?php foreach($keys as $k): ?>
                                <tr>
                                    <td class="px-6 py-4 font-medium text-gray-900"><?php echo htmlspecialchars($k['user_email']); ?></td>
                                    <td class="px-6 py-4 font-mono text-xs text-gray-500"><?php echo substr($k['key_hash'], 0, 16); ?>...</td>
                                    <td class="px-6 py-4">
                                        <?php if($k['is_active']): ?>
                                            <span class="px-2 py-1 bg-green-100 text-green-800 rounded text-xs font-semibold">Active</span>
                                        <?php else: ?>
                                            <span class="px-2 py-1 bg-red-100 text-red-800 rounded text-xs font-semibold">Revoked</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-gray-500"><?php echo $k['rate_limit']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>
