<?php
// admin/index.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
require_developer();

global $pdo;

// Fetch stats
$users_count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$history_count = $pdo->query("SELECT COUNT(*) FROM history")->fetchColumn();
$subs_count = $pdo->query("SELECT COUNT(*) FROM subscriptions WHERE status = 'active'")->fetchColumn();

// Recent Activity
$stmt = $pdo->query("
    SELECT h.*, u.name as user_name 
    FROM history h 
    LEFT JOIN users u ON h.user_id = u.id 
    ORDER BY h.date DESC LIMIT 10
");
$recent_activity = $stmt->fetchAll();

$page_title = "Admin Dashboard";
// We don't use the standard header so we can have a custom admin layout
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden">

    <!-- Sidebar -->
    <aside class="w-64 bg-slate-900 text-white flex flex-col hidden md:flex">
        <div class="h-16 flex items-center px-6 border-b border-slate-800">
            <a href="<?php echo SITE_URL; ?>" class="flex items-center gap-2 text-white hover:text-indigo-400">
                <i class="fa-solid fa-arrows-rotate text-indigo-500"></i>
                <span class="font-bold text-lg tracking-tight"><?php echo SITE_NAME; ?></span>
            </a>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-2">
            <a href="<?php echo SITE_URL; ?>/admin/index.php" class="flex items-center gap-3 px-3 py-2 bg-indigo-600 text-white rounded-lg">
                <i class="fa-solid fa-gauge w-5 text-center"></i> Dashboard
            </a>
            <a href="<?php echo SITE_URL; ?>/admin/users.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors">
                <i class="fa-solid fa-users w-5 text-center"></i> Users
            </a>
            <a href="#" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors">
                <i class="fa-solid fa-crown w-5 text-center"></i> Subscriptions
            </a>
            <a href="#" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors">
                <i class="fa-solid fa-wrench w-5 text-center"></i> Tools Settings
            </a>
        </nav>
        <div class="p-4 border-t border-slate-800">
            <a href="<?php echo SITE_URL; ?>/account/logout.php" class="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-white transition-colors">
                <i class="fa-solid fa-sign-out-alt w-5 text-center"></i> Logout
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 flex flex-col overflow-y-auto">
        <!-- Top header -->
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8">
            <h1 class="text-xl font-semibold text-gray-800">Overview</h1>
            <div class="flex items-center gap-4 text-sm font-medium text-gray-600">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_name']); ?>&background=4F46E5&color=fff" class="w-8 h-8 rounded-full">
            </div>
        </header>

        <div class="p-8">
            <!-- Stats -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 flex items-center justify-between border-l-4 border-l-blue-500">
                    <div>
                        <p class="text-sm font-semibold text-gray-500 uppercase tracking-wider">Total Users</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo $users_count; ?></p>
                    </div>
                    <div class="p-3 bg-blue-50 text-blue-500 rounded-full text-xl"><i class="fa-solid fa-users"></i></div>
                </div>
                
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 flex items-center justify-between border-l-4 border-l-indigo-500">
                    <div>
                        <p class="text-sm font-semibold text-gray-500 uppercase tracking-wider">Conversions</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo $history_count; ?></p>
                    </div>
                    <div class="p-3 bg-indigo-50 text-indigo-500 rounded-full text-xl"><i class="fa-solid fa-bolt"></i></div>
                </div>

                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 flex items-center justify-between border-l-4 border-l-emerald-500">
                    <div>
                        <p class="text-sm font-semibold text-gray-500 uppercase tracking-wider">Active Subs</p>
                        <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo $subs_count; ?></p>
                    </div>
                    <div class="p-3 bg-emerald-50 text-emerald-500 rounded-full text-xl"><i class="fa-solid fa-money-bill-wave"></i></div>
                </div>
            </div>

            <!-- Recent Activity Table -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                    <h2 class="text-lg font-bold text-gray-800">Recent Platform Activity</h2>
                    <a href="#" class="text-sm text-indigo-600 hover:text-indigo-800 font-medium">View All</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">File</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php if(empty($recent_activity)): ?>
                            <tr><td colspan="4" class="px-6 py-4 text-center text-gray-500">No activity recorded yet in system.</td></tr>
                            <?php else: ?>
                                <?php foreach($recent_activity as $row): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo htmlspecialchars($row['user_name'] ?: 'Guest/Unknown'); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                            <?php echo htmlspecialchars($row['tool_name']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo htmlspecialchars($row['file_name'] ?: '-'); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                                        <?php echo date('M j, Y H:i', strtotime($row['date'])); ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
