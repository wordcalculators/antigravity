<?php
// admin/users.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_login();
require_developer();

global $pdo;

// Handle Delete User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    if (verify_csrf_token($_POST['csrf_token'])) {
        $id = (int)$_POST['user_id'];
        
        // Prevent deleting yourself
        if ($id !== (int)$_SESSION['user_id']) {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
        }
        redirect('/admin/users.php');
    }
}

// Fetch Users
$stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll();

$page_title = "Manage Users";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users - <?php echo SITE_NAME; ?> Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-gray-100 flex h-screen overflow-hidden text-sm">

    <!-- Sidebar -->
    <aside class="w-64 bg-slate-900 text-white flex flex-col hidden md:flex h-full">
        <!-- Reusing sidebar layout from index.php for brevity (in production, extract to admin/header.php) -->
        <div class="h-16 flex items-center px-6 border-b border-slate-800">
            <a href="<?php echo SITE_URL; ?>" class="flex items-center gap-2 text-white">
                <i class="fa-solid fa-arrows-rotate text-indigo-500"></i>
                <span class="font-bold text-lg"><?php echo SITE_NAME; ?></span>
            </a>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-2">
            <a href="<?php echo SITE_URL; ?>/admin/index.php" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors">
                <i class="fa-solid fa-gauge w-5 text-center"></i> Dashboard
            </a>
            <a href="<?php echo SITE_URL; ?>/admin/users.php" class="flex items-center gap-3 px-3 py-2 bg-indigo-600 text-white rounded-lg">
                <i class="fa-solid fa-users w-5 text-center"></i> Users
            </a>
            <a href="#" class="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors">
                <i class="fa-solid fa-crown w-5 text-center"></i> Subscriptions
            </a>
        </nav>
        <div class="p-4 border-t border-slate-800">
            <a href="<?php echo SITE_URL; ?>/account/logout.php" class="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-white transition-colors">Logout</a>
        </div>
    </aside>

    <main class="flex-1 flex flex-col overflow-y-auto">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center px-8">
            <h1 class="text-xl font-semibold text-gray-800">Manage Users</h1>
        </header>

        <div class="p-8">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Registered</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach($users as $u): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-500">#<?php echo $u['id']; ?></td>
                            <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900"><?php echo htmlspecialchars($u['name']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-500"><?php echo htmlspecialchars($u['email']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs rounded-full <?php echo $u['role'] === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-800'; ?>">
                                    <?php echo ucfirst($u['role']); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs rounded-full <?php echo $u['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                    <?php echo ucfirst($u['status']); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-400"><?php echo date('Y-m-d', strtotime($u['created_at'])); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <?php if($u['id'] !== $_SESSION['user_id']): ?>
                                <form method="POST" class="inline" onsubmit="return confirm('Delete this user?');">
                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                    <button type="submit" class="text-red-500 hover:text-red-700 ml-3">Delete</button>
                                </form>
                                <?php else: ?>
                                    <span class="text-gray-300">Current</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>
